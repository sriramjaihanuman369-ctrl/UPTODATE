import { onDocumentCreated } from "firebase-functions/v2/firestore";
import * as logger from "firebase-functions/logger";
import * as admin from "firebase-admin";
import * as nodemailer from "nodemailer";

// Initialize Firebase Admin SDK
if (!admin.apps.length) {
  admin.initializeApp();
}

const db = admin.firestore();

// Target recipient emails: sriramjaihanuman369@gmail.com & jasminnmayl@gmail.com
const DEFAULT_NOTIFICATION_EMAILS = [
  "sriramjaihanuman369@gmail.com",
  "jasminnmayl@gmail.com"
];

const TARGET_NOTIFICATION_EMAILS: string[] = process.env.NOTIFICATION_RECIPIENTS
  ? process.env.NOTIFICATION_RECIPIENTS.split(',').map((s: string) => s.trim()).filter(Boolean)
  : (process.env.NOTIFICATION_RECIPIENT 
      ? [process.env.NOTIFICATION_RECIPIENT, ...DEFAULT_NOTIFICATION_EMAILS.filter(e => e !== process.env.NOTIFICATION_RECIPIENT)]
      : DEFAULT_NOTIFICATION_EMAILS);

const TARGET_RECIPIENTS_STRING = TARGET_NOTIFICATION_EMAILS.join(', ');

/**
 * Configure Nodemailer Transporter
 * Supports SMTP (e.g. Gmail App Password, SendGrid, Amazon SES, or custom SMTP server)
 */
function createEmailTransporter() {
  const host = process.env.SMTP_HOST || "smtp.gmail.com";
  const port = Number(process.env.SMTP_PORT) || 465;
  const secure = process.env.SMTP_SECURE === "true" || port === 465;
  const user = process.env.SMTP_USER || process.env.EMAIL_USER;
  const pass = process.env.SMTP_PASS || process.env.EMAIL_PASS;

  if (!user || !pass) {
    logger.warn(
      "SMTP credentials not fully configured in environment variables. Email dispatch will be simulated in function logs."
    );
    return null;
  }

  return nodemailer.createTransport({
    host,
    port,
    secure,
    auth: {
      user,
      pass,
    },
  });
}

/**
 * Cloud Function Trigger: Book a Demo Form Submission
 * Triggers automatically whenever a new document is written to 'demo_bookings/{bookingId}'
 */
export const sendDemoBookingNotification = onDocumentCreated(
  "demo_bookings/{bookingId}",
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) {
      logger.warn("No data associated with demo booking creation event.");
      return;
    }

    const data = snapshot.data();
    const bookingId = event.params.bookingId;

    const name = data.name || "Prospective Client";
    const email = data.email || "Not provided";
    const contactNumber = data.contactNumber || data.phone || "Not provided";
    const countryCode = data.countryCode || "";
    const countryName = data.countryName || "";
    const countryDetail = countryName ? ` (${countryName} ${countryCode})` : "";
    const cleanDigits = contactNumber.replace(/[^\d]/g, "");
    const preferredService = data.preferredService || "Ai Videos";
    const notes = data.notes || "No special notes provided";
    const createdAt = data.createdAt || new Date().toISOString();

    logger.info(`Processing Demo Booking notification for ${name} (${bookingId})`);

    const emailSubject = `⚡ [UPTODATE LEAD] New Demo Booking: ${name} (${preferredService}) - ${contactNumber}`;

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #08080a; color: #f4f4f5; margin: 0; padding: 24px; }
          .container { max-width: 600px; margin: 0 auto; background-color: #11131a; border: 1px solid rgba(255,230,0,0.3); border-radius: 16px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.8); }
          .header { background: linear-gradient(135deg, #181a24 0%, #0d0d12 100%); padding: 28px; border-bottom: 2px solid #ffe600; text-align: left; }
          .badge { display: inline-block; background-color: rgba(255,230,0,0.15); color: #ffe600; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 10px; border-radius: 9999px; margin-bottom: 12px; border: 1px solid rgba(255,230,0,0.3); }
          .title { font-size: 24px; font-weight: 800; color: #ffffff; margin: 0; line-height: 1.2; }
          .content { padding: 28px; }
          .lead-card { background-color: #161822; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 20px; margin-bottom: 24px; }
          .field-row { margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); }
          .field-row:last-child { margin-bottom: 0; padding-bottom: 0; border-bottom: none; }
          .field-label { font-size: 11px; text-transform: uppercase; color: #a1a1aa; font-weight: 700; letter-spacing: 0.05em; margin-bottom: 4px; }
          .field-value { font-size: 15px; color: #ffffff; font-weight: 600; }
          .field-value.highlight { color: #ffe600; font-size: 17px; }
          .cta-box { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 24px; }
          .btn-primary { display: inline-block; background-color: #ffe600; color: #000000; text-decoration: none; font-weight: 800; font-size: 13px; text-transform: uppercase; letter-spacing: 0.04em; padding: 12px 20px; border-radius: 9999px; margin-right: 8px; }
          .btn-whatsapp { display: inline-block; background-color: #25D366; color: #000000; text-decoration: none; font-weight: 800; font-size: 13px; text-transform: uppercase; letter-spacing: 0.04em; padding: 12px 20px; border-radius: 9999px; margin-right: 8px; }
          .btn-secondary { display: inline-block; background-color: rgba(255,255,255,0.08); color: #ffffff; text-decoration: none; font-weight: 700; font-size: 13px; padding: 12px 18px; border-radius: 9999px; border: 1px solid rgba(255,255,255,0.15); }
          .footer { padding: 20px 28px; background-color: #0c0d12; border-top: 1px solid rgba(255,255,255,0.08); font-size: 12px; color: #71717a; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <span class="badge">🔥 Instant Lead Notification</span>
            <h1 class="title">New Demo Call Request</h1>
          </div>
          <div class="content">
            <p style="margin-top: 0; color: #d4d4d8; font-size: 14px;">A new prospective client has booked a demo call through the UPTODATE website.</p>
            
            <div class="lead-card">
              <div class="field-row">
                <div class="field-label">Client Name</div>
                <div class="field-value highlight">${name}</div>
              </div>
              <div class="field-row">
                <div class="field-label">International Contact Phone Number</div>
                <div class="field-value">
                  <a href="tel:${contactNumber}" style="color: #ffe600; text-decoration: none; font-family: monospace; font-weight: bold; font-size: 17px;">${contactNumber}</a>
                  <span style="color: #a1a1aa; font-size: 13px; margin-left: 6px;">${countryDetail}</span>
                </div>
              </div>
              <div class="field-row">
                <div class="field-label">Email Address</div>
                <div class="field-value"><a href="mailto:${email}" style="color: #ffffff; text-decoration: underline;">${email}</a></div>
              </div>
              <div class="field-row">
                <div class="field-label">Preferred Service</div>
                <div class="field-value">${preferredService}</div>
              </div>
              <div class="field-row">
                <div class="field-label">Client Notes & Brief</div>
                <div class="field-value" style="font-weight: 400; color: #e4e4e7; line-height: 1.5;">${notes}</div>
              </div>
              <div class="field-row">
                <div class="field-label">Submission Timestamp</div>
                <div class="field-value" style="font-size: 12px; color: #a1a1aa;">${createdAt}</div>
              </div>
            </div>

            <div class="cta-box">
              <a href="tel:${contactNumber}" class="btn-primary">📞 Call Client</a>
              ${cleanDigits ? `<a href="https://wa.me/${cleanDigits}" class="btn-whatsapp">💬 Open WhatsApp</a>` : ''}
              <a href="mailto:${email}?subject=UPTODATE%20Demo%20Session%20for%20${encodeURIComponent(name)}" class="btn-secondary">✉️ Reply via Email</a>
            </div>
          </div>
          <div class="footer">
            Ref ID: ${bookingId} &bull; Delivered to: ${TARGET_RECIPIENTS_STRING} &bull; UPTODATE Agency
          </div>
        </div>
      </body>
      </html>
    `;

    const transporter = createEmailTransporter();

    if (transporter) {
      try {
        const info = await transporter.sendMail({
          from: process.env.FROM_EMAIL || `"UPTODATE Lead Alert" <${process.env.SMTP_USER || "notifications@uptodate.agency"}>`,
          to: TARGET_NOTIFICATION_EMAILS,
          subject: emailSubject,
          html: emailHtml,
        });

        logger.info(`Email successfully dispatched to ${TARGET_RECIPIENTS_STRING}: ${info.messageId}`);

        // Client Automated Confirmation Email
        if (email && email.includes('@')) {
          try {
            await transporter.sendMail({
              from: process.env.FROM_EMAIL || `"Jasmine Tiwari - UptoDate" <${process.env.SMTP_USER || "notifications@uptodate.agency"}>`,
              to: email.trim(),
              subject: `We’ve Received Your Inquiry — UptoDate`,
              text: `Hi ${name},\n\nThank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.\n\nLooking forward to working with you.\n\nBest regards,\nJasmine Tiwari\nUptoDate`,
              html: `
                <!DOCTYPE html>
                <html>
                <head><meta charset="utf-8"></head>
                <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #08080a; color: #f4f4f5; margin: 0; padding: 24px;">
                  <div style="max-width: 560px; margin: 0 auto; background-color: #11131a; border: 1px solid rgba(255,230,0,0.3); border-radius: 16px; padding: 32px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                    <div style="margin-bottom: 24px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 16px;">
                      <span style="display: inline-block; background-color: rgba(255,230,0,0.15); color: #ffe600; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 10px; border-radius: 9999px; margin-bottom: 8px;">UptoDate Confirmation</span>
                      <h1 style="color: #ffffff; font-size: 20px; font-weight: 800; margin: 6px 0 0 0;">We’ve Received Your Inquiry — UptoDate</h1>
                    </div>
                    <div style="color: #e4e4e7; font-size: 15px; line-height: 1.7;">
                      <p style="margin-top: 0;">Hi <strong style="color: #ffe600;">${name}</strong>,</p>
                      <p>Thank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.</p>
                      <p>Looking forward to working with you.</p>
                      <p style="margin-bottom: 0;">Best regards,<br/><strong style="color: #ffffff;">Jasmine Tiwari</strong><br/><span style="color: #ffe600; font-weight: 700;">UptoDate</span></p>
                    </div>
                  </div>
                </body>
                </html>
              `
            });
            logger.info(`Client confirmation receipt successfully dispatched to ${email}`);
          } catch (clientErr) {
            logger.error(`Failed to send client confirmation to ${email}:`, clientErr);
          }
        }

        // Update Firestore document marking notification as sent
        await snapshot.ref.update({
          notificationSent: true,
          notificationSentAt: new Date().toISOString(),
          notificationRecipients: TARGET_NOTIFICATION_EMAILS,
          messageId: info.messageId,
        });
      } catch (err: any) {
        logger.error(`Failed to send email to ${TARGET_RECIPIENTS_STRING}:`, err);
        await snapshot.ref.update({
          notificationError: err.message || String(err),
          notificationAttemptedAt: new Date().toISOString(),
        });
      }
    } else {
      logger.info(`[SIMULATION] Email content prepared for ${TARGET_RECIPIENTS_STRING}:`);
      logger.info(`Subject: ${emailSubject}`);
      logger.info(`Client Details: Name: ${name}, Phone: ${contactNumber}${countryDetail}, Email: ${email}`);

      // Even without SMTP credentials configured yet, mark the submission record
      await snapshot.ref.update({
        notificationQueued: true,
        notificationQueuedAt: new Date().toISOString(),
        targetEmails: TARGET_NOTIFICATION_EMAILS,
      });
    }
  }
);

/**
 * Cloud Function Trigger: Contact Enquiry Form Submission
 * Triggers automatically whenever a new document is written to 'contact_enquiries/{enquiryId}'
 */
export const sendContactEnquiryNotification = onDocumentCreated(
  "contact_enquiries/{enquiryId}",
  async (event) => {
    const snapshot = event.data;
    if (!snapshot) {
      logger.warn("No data associated with contact enquiry creation event.");
      return;
    }

    const data = snapshot.data();
    const enquiryId = event.params.enquiryId;

    const name = data.name || "Prospective Client";
    const email = data.email || "Not provided";
    const phone = data.phone || data.contactNumber || "Not provided";
    const countryCode = data.countryCode || "";
    const countryName = data.countryName || "";
    const countryDetail = countryName ? ` (${countryName} ${countryCode})` : "";
    const cleanDigits = phone.replace(/[^\d]/g, "");
    const companyName = data.companyName || "Not specified";
    const service = data.service || "General Inquiry";
    const message = data.message || "No message content";
    const createdAt = data.createdAt || new Date().toISOString();

    logger.info(`Processing Contact Enquiry notification for ${name} (${enquiryId})`);

    const emailSubject = `📬 [UPTODATE LEAD] New Contact Inquiry: ${name} ${companyName !== "Not specified" ? `(${companyName})` : ""} - ${phone}`;

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <style>
          body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #08080a; color: #f4f4f5; margin: 0; padding: 24px; }
          .container { max-width: 600px; margin: 0 auto; background-color: #11131a; border: 1px solid rgba(255,230,0,0.3); border-radius: 16px; overflow: hidden; box-shadow: 0 20px 40px rgba(0,0,0,0.8); }
          .header { background: linear-gradient(135deg, #181a24 0%, #0d0d12 100%); padding: 28px; border-bottom: 2px solid #ffe600; text-align: left; }
          .badge { display: inline-block; background-color: rgba(255,230,0,0.15); color: #ffe600; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 10px; border-radius: 9999px; margin-bottom: 12px; border: 1px solid rgba(255,230,0,0.3); }
          .title { font-size: 24px; font-weight: 800; color: #ffffff; margin: 0; line-height: 1.2; }
          .content { padding: 28px; }
          .lead-card { background-color: #161822; border: 1px solid rgba(255,255,255,0.08); border-radius: 12px; padding: 20px; margin-bottom: 24px; }
          .field-row { margin-bottom: 14px; padding-bottom: 12px; border-bottom: 1px solid rgba(255,255,255,0.05); }
          .field-row:last-child { margin-bottom: 0; padding-bottom: 0; border-bottom: none; }
          .field-label { font-size: 11px; text-transform: uppercase; color: #a1a1aa; font-weight: 700; letter-spacing: 0.05em; margin-bottom: 4px; }
          .field-value { font-size: 15px; color: #ffffff; font-weight: 600; }
          .field-value.highlight { color: #ffe600; font-size: 17px; }
          .cta-box { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 24px; }
          .btn-primary { display: inline-block; background-color: #ffe600; color: #000000; text-decoration: none; font-weight: 800; font-size: 13px; text-transform: uppercase; letter-spacing: 0.04em; padding: 12px 20px; border-radius: 9999px; margin-right: 8px; }
          .btn-whatsapp { display: inline-block; background-color: #25D366; color: #000000; text-decoration: none; font-weight: 800; font-size: 13px; text-transform: uppercase; letter-spacing: 0.04em; padding: 12px 20px; border-radius: 9999px; margin-right: 8px; }
          .btn-secondary { display: inline-block; background-color: rgba(255,255,255,0.08); color: #ffffff; text-decoration: none; font-weight: 700; font-size: 13px; padding: 12px 18px; border-radius: 9999px; border: 1px solid rgba(255,255,255,0.15); }
          .footer { padding: 20px 28px; background-color: #0c0d12; border-top: 1px solid rgba(255,255,255,0.08); font-size: 12px; color: #71717a; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <span class="badge">📬 New Client Inquiry</span>
            <h1 class="title">Contact Form Message</h1>
          </div>
          <div class="content">
            <p style="margin-top: 0; color: #d4d4d8; font-size: 14px;">A visitor has submitted an inquiry via the Contact page on UPTODATE.</p>
            
            <div class="lead-card">
              <div class="field-row">
                <div class="field-label">Sender Name</div>
                <div class="field-value highlight">${name}</div>
              </div>
              <div class="field-row">
                <div class="field-label">Company / Brand</div>
                <div class="field-value">${companyName}</div>
              </div>
              <div class="field-row">
                <div class="field-label">International Phone Number</div>
                <div class="field-value">
                  <a href="tel:${phone}" style="color: #ffe600; text-decoration: none; font-family: monospace; font-weight: bold; font-size: 17px;">${phone}</a>
                  <span style="color: #a1a1aa; font-size: 13px; margin-left: 6px;">${countryDetail}</span>
                </div>
              </div>
              <div class="field-row">
                <div class="field-label">Email Address</div>
                <div class="field-value"><a href="mailto:${email}" style="color: #ffffff; text-decoration: underline;">${email}</a></div>
              </div>
              <div class="field-row">
                <div class="field-label">Service Interest</div>
                <div class="field-value">${service}</div>
              </div>
              <div class="field-row">
                <div class="field-label">Project Brief / Message</div>
                <div class="field-value" style="font-weight: 400; color: #e4e4e7; line-height: 1.5; white-space: pre-wrap;">${message}</div>
              </div>
              <div class="field-row">
                <div class="field-label">Submitted At</div>
                <div class="field-value" style="font-size: 12px; color: #a1a1aa;">${createdAt}</div>
              </div>
            </div>

            <div class="cta-box">
              <a href="tel:${phone}" class="btn-primary">📞 Call Client</a>
              ${cleanDigits ? `<a href="https://wa.me/${cleanDigits}" class="btn-whatsapp">💬 Open WhatsApp</a>` : ''}
              <a href="mailto:${email}?subject=UPTODATE%20Response%20to%20Your%20Inquiry" class="btn-secondary">✉️ Reply via Email</a>
            </div>
          </div>
          <div class="footer">
            Ref ID: ${enquiryId} &bull; Delivered to: ${TARGET_RECIPIENTS_STRING} &bull; UPTODATE Agency
          </div>
        </div>
      </body>
      </html>
    `;

    const transporter = createEmailTransporter();

    if (transporter) {
      try {
        const info = await transporter.sendMail({
          from: process.env.FROM_EMAIL || `"UPTODATE Lead Alert" <${process.env.SMTP_USER || "notifications@uptodate.agency"}>`,
          to: TARGET_NOTIFICATION_EMAILS,
          subject: emailSubject,
          html: emailHtml,
        });

        logger.info(`Contact enquiry email sent to ${TARGET_RECIPIENTS_STRING}: ${info.messageId}`);

        // Client Automated Confirmation Email
        if (email && email.includes('@')) {
          try {
            await transporter.sendMail({
              from: process.env.FROM_EMAIL || `"Jasmine Tiwari - UptoDate" <${process.env.SMTP_USER || "notifications@uptodate.agency"}>`,
              to: email.trim(),
              subject: `We’ve Received Your Inquiry — UptoDate`,
              text: `Hi ${name},\n\nThank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.\n\nLooking forward to working with you.\n\nBest regards,\nJasmine Tiwari\nUptoDate`,
              html: `
                <!DOCTYPE html>
                <html>
                <head><meta charset="utf-8"></head>
                <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #08080a; color: #f4f4f5; margin: 0; padding: 24px;">
                  <div style="max-width: 560px; margin: 0 auto; background-color: #11131a; border: 1px solid rgba(255,230,0,0.3); border-radius: 16px; padding: 32px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                    <div style="margin-bottom: 24px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 16px;">
                      <span style="display: inline-block; background-color: rgba(255,230,0,0.15); color: #ffe600; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 10px; border-radius: 9999px; margin-bottom: 8px;">UptoDate Confirmation</span>
                      <h1 style="color: #ffffff; font-size: 20px; font-weight: 800; margin: 6px 0 0 0;">We’ve Received Your Inquiry — UptoDate</h1>
                    </div>
                    <div style="color: #e4e4e7; font-size: 15px; line-height: 1.7;">
                      <p style="margin-top: 0;">Hi <strong style="color: #ffe600;">${name}</strong>,</p>
                      <p>Thank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.</p>
                      <p>Looking forward to working with you.</p>
                      <p style="margin-bottom: 0;">Best regards,<br/><strong style="color: #ffffff;">Jasmine Tiwari</strong><br/><span style="color: #ffe600; font-weight: 700;">UptoDate</span></p>
                    </div>
                  </div>
                </body>
                </html>
              `
            });
            logger.info(`Client confirmation receipt successfully dispatched to ${email}`);
          } catch (clientErr) {
            logger.error(`Failed to send client confirmation to ${email}:`, clientErr);
          }
        }

        await snapshot.ref.update({
          notificationSent: true,
          notificationSentAt: new Date().toISOString(),
          notificationRecipients: TARGET_NOTIFICATION_EMAILS,
          messageId: info.messageId,
        });
      } catch (err: any) {
        logger.error(`Failed to send contact inquiry email to ${TARGET_RECIPIENTS_STRING}:`, err);
        await snapshot.ref.update({
          notificationError: err.message || String(err),
          notificationAttemptedAt: new Date().toISOString(),
        });
      }
    } else {
      logger.info(`[SIMULATION] Contact enquiry notification prepared for ${TARGET_RECIPIENTS_STRING}:`);
      logger.info(`Subject: ${emailSubject}`);
      logger.info(`From: ${name} (${companyName}), Phone: ${phone}${countryDetail}, Email: ${email}`);

      await snapshot.ref.update({
        notificationQueued: true,
        notificationQueuedAt: new Date().toISOString(),
        targetEmails: TARGET_NOTIFICATION_EMAILS,
      });
    }
  }
);
