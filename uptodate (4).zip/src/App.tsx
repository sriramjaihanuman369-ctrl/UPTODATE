import React, { useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { WhatsAppButton } from './components/WhatsAppButton';
import { DemoModal } from './components/DemoModal';
import { ServicesModal } from './components/ServicesModal';
import { AuthModal } from './components/AuthModal';
import { ProjectModal } from './components/ProjectModal';
import { ScrollProgressBar } from './components/ScrollProgressBar';

import { HomeView } from './views/HomeView';
import { ProjectsView } from './views/ProjectsView';
import { ServicesView } from './views/ServicesView';
import { AboutView } from './views/AboutView';
import { ContactView } from './views/ContactView';
import { MyListingsView } from './views/MyListingsView';
import { AdminView } from './views/AdminView';

const MainLayout: React.FC = () => {
  const { currentPage, setCurrentPage } = useApp();

  // Listen for hash changes if any
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash.replace('#', '');
      if (['home', 'projects', 'services', 'about', 'contact', 'my-listings', 'admin'].includes(hash)) {
        setCurrentPage(hash as any);
      }
    };
    window.addEventListener('hashchange', handleHash);
    handleHash();
    return () => window.removeEventListener('hashchange', handleHash);
  }, [setCurrentPage]);

  // Keep hash in sync
  useEffect(() => {
    if (window.location.hash.replace('#', '') !== currentPage) {
      window.location.hash = currentPage;
    }
  }, [currentPage]);

  return (
    <div className="min-h-screen bg-[#0D0704] text-[#B8ACA3] flex flex-col selection:bg-[#FF6A00] selection:text-white relative overflow-x-hidden">
      {/* Ambient background glows for molten orange atmosphere */}
      <div className="fixed top-0 left-1/4 w-[500px] h-[500px] bg-[#FF6A00]/[0.04] rounded-full blur-[140px] pointer-events-none z-0" />
      <div className="fixed bottom-1/3 right-10 w-[600px] h-[600px] bg-[#FF851A]/[0.03] rounded-full blur-[160px] pointer-events-none z-0" />

      {/* Top Scroll Indicator */}
      <ScrollProgressBar />

      {/* Sticky Navigation Bar */}
      <Navbar />

      {/* Main Page Content */}
      <main className="flex-1">
        {currentPage === 'home' && <HomeView />}
        {currentPage === 'projects' && <ProjectsView />}
        {currentPage === 'services' && <ServicesView />}
        {currentPage === 'about' && <AboutView />}
        {currentPage === 'contact' && <ContactView />}
        {currentPage === 'my-listings' && <MyListingsView />}
        {currentPage === 'admin' && <AdminView />}
      </main>

      {/* Footer */}
      <Footer />

      {/* Sticky WhatsApp Direct Button (962511181) */}
      <WhatsAppButton />

      {/* Global Modals */}
      <DemoModal />
      <ServicesModal />
      <AuthModal />
      <ProjectModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
