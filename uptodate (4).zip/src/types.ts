export interface Project {
  id: string;
  title: string;
  category: 'ai video' | 'website' | 'branding' | 'ugc video' | 'digital marketing';
  description: string;
  thumbnail: string;
  videoUrl?: string;
  driveUrl?: string;
  videoType?: 'mp4' | 'youtube' | 'vimeo' | 'drive';
  aspectRatio?: '16:9' | '9:16' | '1:1' | 'auto';
  galleryImages?: string[];
  websiteUrl?: string;
  tags?: string[];
  results?: string;
  featured?: boolean;
  createdBy: string;
  authorEmail?: string;
  authorName?: string;
  createdAt: string;
}

export interface DemoBooking {
  id?: string;
  name: string;
  email: string;
  contactNumber: string;
  countryCode?: string;
  countryName?: string;
  preferredService?: string;
  notes?: string;
  status: 'pending' | 'confirmed' | 'completed';
  createdAt: string;
}

export interface ContactEnquiry {
  id?: string;
  name: string;
  email: string;
  phone: string;
  countryCode?: string;
  countryName?: string;
  companyName?: string;
  message: string;
  service?: string;
  status: 'new' | 'reviewed' | 'replied';
  createdAt: string;
}

export interface AboutSectionData {
  whyWeStarted: string;
  coreValues: Array<{
    title: string;
    description: string;
    icon?: string;
  }>;
  stats?: Array<{
    value: string;
    label: string;
  }>;
  updatedAt?: string;
  updatedBy?: string;
}

export type PageView = 'home' | 'about' | 'services' | 'projects' | 'contact' | 'my-listings' | 'admin';
