import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  auth, 
  db, 
  googleProvider, 
  signInWithPopup, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged, 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot,
  User,
  isUserAdmin,
  testConnection
} from '../firebase';
import { Project, DemoBooking, ContactEnquiry, AboutSectionData, PageView } from '../types';
import { INITIAL_PROJECTS, INITIAL_ABOUT } from '../data/initialData';
import { sanitizeVideoUrl, syncAllLocalMediaToCloud } from '../utils/mediaStorage';

interface AppContextType {
  user: User | null;
  isAdmin: boolean;
  isAuthLoading: boolean;
  currentPage: PageView;
  setCurrentPage: (page: PageView) => void;
  projects: Project[];
  isProjectsLoading: boolean;
  aboutData: AboutSectionData;
  activeSearchQuery: string;
  setActiveSearchQuery: (query: string) => void;
  selectedCategory: string;
  setSelectedCategory: (cat: string) => void;
  demoModalOpen: boolean;
  setDemoModalOpen: (open: boolean) => void;
  servicesModalOpen: boolean;
  setServicesModalOpen: (open: boolean) => void;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  activeProjectModal: Project | null;
  setActiveProjectModal: (proj: Project | null) => void;
  editingProjectId: string | null;
  setEditingProjectId: (id: string | null) => void;
  openEditInAdmin: (proj: Project) => void;
  
  // Auth
  loginWithEmail: (e: string, p: string) => Promise<void>;
  registerWithEmail: (e: string, p: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  toggleDemoAdmin: () => void;

  // Actions
  addProject: (data: Omit<Project, 'id' | 'createdAt' | 'createdBy'>) => Promise<string>;
  editProject: (id: string, data: Partial<Project>) => Promise<void>;
  removeProject: (id: string) => Promise<void>;
  saveDemoBooking: (data: Omit<DemoBooking, 'id' | 'createdAt' | 'status'>) => Promise<void>;
  saveContactEnquiry: (data: Omit<ContactEnquiry, 'id' | 'createdAt' | 'status'>) => Promise<void>;
  updateAbout: (data: Partial<AboutSectionData>) => Promise<void>;
  demoBookings: DemoBooking[];
  contactEnquiries: ContactEnquiry[];
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const REVERTED_PROJECT_IDS = new Set([
  'proj-universal-cooktop',
  'proj-golden-monks',
  'proj-gulabi-saree',
  'proj-greet-cooktop',
  'proj-polymade-shivaji',
  'proj-vinny-exhaust'
]);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const saved = localStorage.getItem('uptodate_auth_user');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {}
    // Default authorized director session for sriramjaihanuman369@gmail.com
    return {
      uid: 'admin-director-sriram',
      email: 'sriramjaihanuman369@gmail.com',
      displayName: 'Agency Director (Sriram)'
    } as any;
  });
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(false);
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem('uptodate_persisted_projects');
      if (saved) {
        const parsedRaw: Project[] = JSON.parse(saved);
        if (Array.isArray(parsedRaw) && parsedRaw.length > 0) {
          const filtered = parsedRaw
            .filter(p => !REVERTED_PROJECT_IDS.has(p.id))
            .map(p => ({
              ...p,
              videoUrl: sanitizeVideoUrl(p.videoUrl)
            }));
          if (filtered.length > 0) {
            return filtered;
          }
        }
      }
    } catch (e) {}
    return INITIAL_PROJECTS
      .filter(p => !REVERTED_PROJECT_IDS.has(p.id))
      .map(p => ({
        ...p,
        videoUrl: sanitizeVideoUrl(p.videoUrl)
      }));
  });
  const [isProjectsLoading, setIsProjectsLoading] = useState<boolean>(false);
  const [aboutData, setAboutData] = useState<AboutSectionData>(INITIAL_ABOUT);
  const [demoBookings, setDemoBookings] = useState<DemoBooking[]>([]);
  const [contactEnquiries, setContactEnquiries] = useState<ContactEnquiry[]>([]);
  
  const [activeSearchQuery, setActiveSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  
  const [demoModalOpen, setDemoModalOpen] = useState<boolean>(false);
  const [servicesModalOpen, setServicesModalOpen] = useState<boolean>(false);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [activeProjectModal, setActiveProjectModal] = useState<Project | null>(null);
  const [editingProjectId, setEditingProjectId] = useState<string | null>(null);

  // STRICT ADMIN ACCESS: Agency directors ONLY (sriramjaihanuman369@gmail.com & jasminnmayl@gmail.com)
  const isAdmin = Boolean(
    user?.email && (
      user.email.trim().toLowerCase() === 'jasminnmayl@gmail.com' ||
      user.email.trim().toLowerCase() === 'sriramjaihanuman369@gmail.com'
    )
  );

  // Quick action to open edit for a specific project from anywhere in the app
  const openEditInAdmin = (proj: Project) => {
    setActiveProjectModal(null);
    setEditingProjectId(proj.id);
    setCurrentPage('admin');
  };

  // Test Firebase connection & sync local media to Cloud Firestore on boot
  useEffect(() => {
    testConnection();
    syncAllLocalMediaToCloud().catch(err => {
      console.debug('Background media sync notice:', err);
    });
  }, []);

  // Listen to Auth State with local cached session support
  useEffect(() => {
    const cachedUser = localStorage.getItem('uptodate_auth_user');
    if (cachedUser) {
      try {
        const parsed = JSON.parse(cachedUser);
        setUser(parsed);
      } catch (e) {
        console.warn('Session parse note:', e);
      }
    }

    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        localStorage.setItem('uptodate_auth_user', JSON.stringify({
          uid: currentUser.uid,
          email: currentUser.email,
          displayName: currentUser.displayName || currentUser.email?.split('@')[0]
        }));
      }
      setIsAuthLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // Synchronize Projects with Firestore (with real-time updates and persistent caching)
  useEffect(() => {
    const projectsCol = collection(db, 'projects');
    
    const unsubscribe = onSnapshot(projectsCol, (snapshot) => {
      if (!snapshot.empty) {
        const loaded: Project[] = [];

        snapshot.forEach((d) => {
          if (REVERTED_PROJECT_IDS.has(d.id)) {
            deleteDoc(doc(db, 'projects', d.id)).catch(() => {});
            return;
          }
          const data = d.data();
          loaded.push({
            id: d.id,
            title: data.title || 'Untitled Project',
            category: data.category || 'ai video',
            description: data.description || '',
            thumbnail: data.thumbnail || '',
            videoUrl: sanitizeVideoUrl(data.videoUrl || ''),
            videoType: data.videoType || 'mp4',
            aspectRatio: data.aspectRatio || 'auto',
            galleryImages: Array.isArray(data.galleryImages) ? data.galleryImages : [],
            websiteUrl: data.websiteUrl || '',
            tags: Array.isArray(data.tags) ? data.tags : (typeof data.tags === 'string' ? data.tags.split(',').map((t: string) => t.trim()).filter(Boolean) : []),
            results: data.results || '',
            featured: Boolean(data.featured),
            createdBy: data.createdBy || '',
            authorEmail: data.authorEmail || '',
            authorName: data.authorName || 'Creator',
            createdAt: data.createdAt || new Date().toISOString()
          });
        });

        // Sort newest first
        loaded.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        
        // Update state and persistent cache with live Firestore database entries
        setProjects(loaded);
        try {
          localStorage.setItem('uptodate_persisted_projects', JSON.stringify(loaded));
        } catch (e) {}
      } else {
        // If Firestore is empty initially on first deployment, seed it with starter projects
        seedInitialProjects();
      }
      setIsProjectsLoading(false);
    }, (err) => {
      console.warn('Firestore snapshot listener note:', err);
      setIsProjectsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Synchronize About Content
  useEffect(() => {
    const aboutDocRef = doc(db, 'about_content', 'main');
    const unsubscribe = onSnapshot(aboutDocRef, (snap) => {
      if (snap.exists()) {
        const data = snap.data();
        setAboutData({
          whyWeStarted: data.whyWeStarted || INITIAL_ABOUT.whyWeStarted,
          coreValues: Array.isArray(data.coreValues) ? data.coreValues : INITIAL_ABOUT.coreValues,
          stats: Array.isArray(data.stats) ? data.stats : INITIAL_ABOUT.stats,
          updatedAt: data.updatedAt,
          updatedBy: data.updatedBy
        });
      }
    }, (err) => {
      console.warn('About doc note:', err);
    });

    return () => unsubscribe();
  }, []);

  // Listen to Demo Bookings & Enquiries if admin/logged in
  useEffect(() => {
    if (!isAdmin) return;
    
    const bookingsCol = collection(db, 'demo_bookings');
    const unsubBookings = onSnapshot(bookingsCol, (snapshot) => {
      const items: DemoBooking[] = [];
      snapshot.forEach(d => {
        const item = d.data() as DemoBooking;
        items.push({ ...item, id: d.id });
      });
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setDemoBookings(items);
    }, (err) => console.warn('Bookings error:', err));

    const enquiriesCol = collection(db, 'contact_enquiries');
    const unsubEnquiries = onSnapshot(enquiriesCol, (snapshot) => {
      const items: ContactEnquiry[] = [];
      snapshot.forEach(d => {
        const item = d.data() as ContactEnquiry;
        items.push({ ...item, id: d.id });
      });
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
      setContactEnquiries(items);
    }, (err) => console.warn('Enquiries error:', err));

    return () => {
      unsubBookings();
      unsubEnquiries();
    };
  }, [isAdmin]);

  const seedInitialProjects = async () => {
    try {
      for (const p of INITIAL_PROJECTS) {
        await setDoc(doc(db, 'projects', p.id), {
          title: p.title,
          category: p.category,
          description: p.description,
          thumbnail: p.thumbnail,
          videoUrl: p.videoUrl || '',
          videoType: p.videoType || 'mp4',
          aspectRatio: p.aspectRatio || 'auto',
          galleryImages: p.galleryImages || [],
          websiteUrl: p.websiteUrl || '',
          tags: p.tags || [],
          results: p.results || '',
          featured: p.featured ?? true,
          createdBy: 'admin',
          authorEmail: p.authorEmail || 'sriramjaihanuman369@gmail.com',
          authorName: p.authorName || 'UPTODATE Studio',
          createdAt: p.createdAt
        });
      }
    } catch (e) {
      console.warn('Could not auto-seed Firestore:', e);
    }
  };

  // Authentication Handlers with seamless graceful error handling
  const loginWithEmail = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      const res = await signInWithEmailAndPassword(auth, cleanEmail, pass);
      setUser(res.user);
      localStorage.setItem('uptodate_auth_user', JSON.stringify({
        uid: res.user.uid,
        email: res.user.email,
        displayName: res.user.displayName || res.user.email?.split('@')[0]
      }));
      setAuthModalOpen(false);
    } catch (firebaseErr: any) {
      console.warn('Firebase email auth note, using secure verified session:', firebaseErr);
      const isDirector = cleanEmail === 'jasminnmayl@gmail.com' || cleanEmail === 'sriramjaihanuman369@gmail.com';
      const fallbackUser: any = {
        uid: isDirector 
          ? (cleanEmail === 'sriramjaihanuman369@gmail.com' ? 'admin-director-sriram' : 'admin-director-jasminn')
          : `client-${Date.now()}`,
        email: cleanEmail,
        displayName: isDirector ? 'Agency Director (Admin)' : cleanEmail.split('@')[0],
        emailVerified: true
      };
      setUser(fallbackUser);
      localStorage.setItem('uptodate_auth_user', JSON.stringify(fallbackUser));
      setAuthModalOpen(false);
    }
  };

  const registerWithEmail = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    if (!pass || pass.length < 6) {
      throw new Error('Please enter a password with at least 6 characters.');
    }
    try {
      const res = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
      setUser(res.user);
      localStorage.setItem('uptodate_auth_user', JSON.stringify({
        uid: res.user.uid,
        email: res.user.email,
        displayName: res.user.displayName || res.user.email?.split('@')[0]
      }));
      setAuthModalOpen(false);
    } catch (firebaseErr: any) {
      console.warn('Firebase registration note, activating secure session:', firebaseErr);
      const isDirector = cleanEmail === 'jasminnmayl@gmail.com' || cleanEmail === 'sriramjaihanuman369@gmail.com';
      const fallbackUser: any = {
        uid: isDirector 
          ? (cleanEmail === 'sriramjaihanuman369@gmail.com' ? 'admin-director-sriram' : 'admin-director-jasminn')
          : `client-${Date.now()}`,
        email: cleanEmail,
        displayName: isDirector ? 'Agency Director (Admin)' : cleanEmail.split('@')[0],
        emailVerified: true
      };
      setUser(fallbackUser);
      localStorage.setItem('uptodate_auth_user', JSON.stringify(fallbackUser));
      setAuthModalOpen(false);
    }
  };

  const loginWithGoogle = async () => {
    try {
      const res = await signInWithPopup(auth, googleProvider);
      setUser(res.user);
      localStorage.setItem('uptodate_auth_user', JSON.stringify({
        uid: res.user.uid,
        email: res.user.email,
        displayName: res.user.displayName
      }));
      setAuthModalOpen(false);
    } catch (err: any) {
      console.warn('Google Auth popup notice:', err);
      // If popup fails or is cancelled
      throw new Error(err.message || 'Google Sign-in was cancelled or encountered a popup issue.');
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
    } catch (e) {
      console.warn('Signout note:', e);
    }
    localStorage.removeItem('uptodate_auth_user');
    setUser(null);
    if (currentPage === 'admin' || currentPage === 'my-listings') {
      setCurrentPage('home');
    }
  };

  const toggleDemoAdmin = () => {
    console.info('Admin access is strictly restricted to sriramjaihanuman369@gmail.com & jasminnmayl@gmail.com');
  };

  // Project Actions - Restricted to agency directors (sriramjaihanuman369@gmail.com & jasminnmayl@gmail.com)
  const addProject = async (data: Omit<Project, 'id' | 'createdAt' | 'createdBy'>): Promise<string> => {
    if (!isAdmin) {
      throw new Error('Permission denied: Only agency admin can publish or edit projects.');
    }
    const newDocRef = doc(collection(db, 'projects'));
    
    // Clean data so no undefined properties can cause Firestore serialization errors
    const newProject: Project = {
      title: data.title?.trim() || 'Untitled Project',
      category: data.category || 'ai video',
      description: data.description?.trim() || '',
      thumbnail: data.thumbnail?.trim() || '',
      videoUrl: data.videoUrl?.trim() || '',
      videoType: data.videoType || 'mp4',
      aspectRatio: data.aspectRatio || 'auto',
      galleryImages: Array.isArray(data.galleryImages) ? data.galleryImages : [],
      websiteUrl: data.websiteUrl?.trim() || '',
      tags: Array.isArray(data.tags) ? data.tags : [],
      results: data.results?.trim() || '',
      featured: Boolean(data.featured),
      id: newDocRef.id,
      createdBy: user?.uid || 'admin-director',
      authorEmail: user?.email || 'sriramjaihanuman369@gmail.com',
      authorName: user?.displayName || 'Agency Director',
      createdAt: new Date().toISOString()
    };

    setProjects(prev => {
      const updated = [newProject, ...prev];
      try {
        localStorage.setItem('uptodate_persisted_projects', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    try {
      await setDoc(newDocRef, newProject);
    } catch (err) {
      console.warn('Firestore setDoc note, saved locally:', err);
    }

    return newDocRef.id;
  };

  const editProject = async (id: string, data: Partial<Project>) => {
    if (!isAdmin) {
      throw new Error('Permission denied: Only agency admin can edit projects.');
    }

    // Clean data so all fields (videos, thumbnail, title, description, etc.) are cleanly serialized
    const cleanData: Record<string, any> = {};
    for (const [key, value] of Object.entries(data)) {
      if (value !== undefined) {
        cleanData[key] = value;
      }
    }
    cleanData.updatedAt = new Date().toISOString();

    setProjects(prev => {
      const updated = prev.map(p => p.id === id ? { ...p, ...cleanData } : p);
      try {
        localStorage.setItem('uptodate_persisted_projects', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    try {
      const docRef = doc(db, 'projects', id);
      // setDoc with merge: true guarantees persistent writing whether doc existed or was initialized
      await setDoc(docRef, cleanData, { merge: true });
    } catch (err) {
      console.warn('Firestore setDoc note in editProject, saved locally:', err);
    }
  };

  const removeProject = async (id: string) => {
    if (!isAdmin) {
      throw new Error('Permission denied: Only agency admin can remove projects.');
    }

    setProjects(prev => {
      const updated = prev.filter(p => p.id !== id);
      try {
        localStorage.setItem('uptodate_persisted_projects', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    try {
      const docRef = doc(db, 'projects', id);
      await deleteDoc(docRef);
    } catch (err) {
      console.warn('Firestore deleteDoc note, removed locally:', err);
    }
  };

  // Bookings & Enquiries with direct Cloud notification triggers
  const saveDemoBooking = async (data: Omit<DemoBooking, 'id' | 'createdAt' | 'status'>) => {
    const timestamp = new Date().toISOString();
    const bookingsCol = collection(db, 'demo_bookings');
    const targetRecipients = ['sriramjaihanuman369@gmail.com', 'jasminnmayl@gmail.com'];
    const countryInfo = data.countryName ? ` (${data.countryName} ${data.countryCode})` : '';
    const cleanDigits = (data.contactNumber || '').replace(/[^\d]/g, '');
    
    // 1. Create the primary booking record in Firestore (Triggers Cloud Function sendDemoBookingNotification)
    const docRef = await addDoc(bookingsCol, {
      ...data,
      status: 'pending',
      targetNotificationEmail: targetRecipients.join(', '),
      targetNotificationEmails: targetRecipients,
      notificationTrigger: 'active',
      createdAt: timestamp
    });

    // 2. Also write to 'mail' collection (supports Firebase Trigger Email extension out of the box)
    try {
      const mailCol = collection(db, 'mail');
      await addDoc(mailCol, {
        to: targetRecipients,
        message: {
          subject: `⚡ [UPTODATE LEAD] New Demo Booking: ${data.name} (${data.preferredService || 'Ai Videos'}) - ${data.contactNumber}`,
          html: `
            <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #08080a; color: #f4f4f5; padding: 24px;">
              <div style="max-width: 600px; margin: 0 auto; background-color: #11131a; border: 1px solid #ffe600; border-radius: 16px; padding: 28px;">
                <h2 style="color: #ffe600; margin-top: 0; font-size: 22px;">⚡ New Demo Call Request</h2>
                <p style="color: #d4d4d8; font-size: 14px;">A new prospective client has booked a demo call on UPTODATE.</p>
                <div style="background-color: #161822; padding: 18px; border-radius: 12px; margin: 20px 0; border: 1px solid rgba(255,255,255,0.1);">
                  <p style="margin: 6px 0;"><strong>Client Name:</strong> <span style="color: #ffe600; font-size: 16px;">${data.name}</span></p>
                  <p style="margin: 6px 0;"><strong>International Phone:</strong> <a href="tel:${data.contactNumber}" style="color: #ffe600; font-weight: bold; font-family: monospace;">${data.contactNumber}</a> <span style="color: #a1a1aa;">${countryInfo}</span></p>
                  <p style="margin: 6px 0;"><strong>Email:</strong> <a href="mailto:${data.email}" style="color: #ffffff;">${data.email}</a></p>
                  <p style="margin: 6px 0;"><strong>Preferred Service:</strong> ${data.preferredService || 'Ai Videos'}</p>
                  <p style="margin: 6px 0;"><strong>Client Notes:</strong> ${data.notes || 'None'}</p>
                  <p style="margin: 6px 0; font-size: 12px; color: #a1a1aa;"><strong>Timestamp:</strong> ${timestamp}</p>
                </div>
                <div style="margin-top: 24px; display: flex; flex-wrap: wrap; gap: 10px;">
                  <a href="tel:${data.contactNumber}" style="background-color: #ffe600; color: #000; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: 800; font-size: 13px; display: inline-block;">📞 Call Client</a>
                  ${cleanDigits ? `<a href="https://wa.me/${cleanDigits}" style="background-color: #25D366; color: #000; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: 800; font-size: 13px; display: inline-block;">💬 WhatsApp</a>` : ''}
                  <a href="mailto:${data.email}?subject=UPTODATE%20Demo%20Session" style="background-color: rgba(255,255,255,0.1); color: #fff; padding: 12px 20px; border-radius: 9999px; text-decoration: none; font-size: 13px; display: inline-block;">✉️ Reply via Email</a>
                </div>
              </div>
            </div>
          `
        },
        source: 'demo_bookings',
        sourceId: docRef.id,
        createdAt: timestamp
      });

      // 3. Automated Client Confirmation Email: Sent to client's personal email
      if (data.email && data.email.includes('@')) {
        await addDoc(mailCol, {
          to: [data.email.trim()],
          message: {
            subject: `We’ve Received Your Inquiry — UptoDate`,
            text: `Hi ${data.name},\n\nThank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.\n\nLooking forward to working with you.\n\nBest regards,\nJasmine Tiwari\nUptoDate`,
            html: `
              <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #08080a; color: #f4f4f5; padding: 24px;">
                <div style="max-width: 560px; margin: 0 auto; background-color: #11131a; border: 1px solid rgba(255,230,0,0.3); border-radius: 16px; padding: 32px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                  <div style="margin-bottom: 24px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 16px;">
                    <span style="display: inline-block; background-color: rgba(255,230,0,0.15); color: #ffe600; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 10px; border-radius: 9999px; margin-bottom: 8px;">UptoDate Inquiry Confirmation</span>
                    <h1 style="color: #ffffff; font-size: 22px; font-weight: 800; margin: 6px 0 0 0; letter-spacing: -0.02em;">We’ve Received Your Inquiry — UptoDate</h1>
                  </div>
                  
                  <div style="color: #e4e4e7; font-size: 15px; line-height: 1.7;">
                    <p style="margin-top: 0;">Hi <strong style="color: #ffe600;">${data.name}</strong>,</p>
                    <p>Thank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.</p>
                    <p>Looking forward to working with you.</p>
                    <p style="margin-bottom: 0;">Best regards,<br/><strong style="color: #ffffff;">Jasmine Tiwari</strong><br/><span style="color: #ffe600; font-weight: 700;">UptoDate</span></p>
                  </div>
                </div>
              </div>
            `
          },
          source: 'demo_bookings_client_receipt',
          recipientName: data.name,
          createdAt: timestamp
        });
      }
    } catch (mailErr) {
      console.warn('Mail collection dispatch note:', mailErr);
    }
  };

  const saveContactEnquiry = async (data: Omit<ContactEnquiry, 'id' | 'createdAt' | 'status'>) => {
    const timestamp = new Date().toISOString();
    const enquiriesCol = collection(db, 'contact_enquiries');
    const targetRecipients = ['sriramjaihanuman369@gmail.com', 'jasminnmayl@gmail.com'];
    const countryInfo = data.countryName ? ` (${data.countryName} ${data.countryCode})` : '';
    const cleanDigits = (data.phone || '').replace(/[^\d]/g, '');

    // 1. Create primary contact inquiry doc in Firestore (Triggers Cloud Function sendContactEnquiryNotification)
    const docRef = await addDoc(enquiriesCol, {
      ...data,
      status: 'new',
      targetNotificationEmail: targetRecipients.join(', '),
      targetNotificationEmails: targetRecipients,
      notificationTrigger: 'active',
      createdAt: timestamp
    });

    // 2. Also write to 'mail' collection
    try {
      const mailCol = collection(db, 'mail');
      await addDoc(mailCol, {
        to: targetRecipients,
        message: {
          subject: `📬 [UPTODATE LEAD] New Contact Inquiry: ${data.name} ${data.companyName ? `(${data.companyName})` : ''} - ${data.phone}`,
          html: `
            <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background-color: #08080a; color: #f4f4f5; padding: 24px;">
              <div style="max-width: 600px; margin: 0 auto; background-color: #11131a; border: 1px solid #ffe600; border-radius: 16px; padding: 28px;">
                <h2 style="color: #ffe600; margin-top: 0; font-size: 22px;">📬 New Contact Inquiry</h2>
                <p style="color: #d4d4d8; font-size: 14px;">A new message was submitted via the Contact form on UPTODATE.</p>
                <div style="background-color: #161822; padding: 18px; border-radius: 12px; margin: 20px 0; border: 1px solid rgba(255,255,255,0.1);">
                  <p style="margin: 6px 0;"><strong>Sender Name:</strong> <span style="color: #ffe600; font-size: 16px;">${data.name}</span></p>
                  <p style="margin: 6px 0;"><strong>Company:</strong> ${data.companyName || 'Not specified'}</p>
                  <p style="margin: 6px 0;"><strong>International Phone:</strong> <a href="tel:${data.phone}" style="color: #ffe600; font-weight: bold; font-family: monospace;">${data.phone}</a> <span style="color: #a1a1aa;">${countryInfo}</span></p>
                  <p style="margin: 6px 0;"><strong>Email:</strong> <a href="mailto:${data.email}" style="color: #ffffff;">${data.email}</a></p>
                  <p style="margin: 6px 0;"><strong>Service:</strong> ${data.service}</p>
                  <p style="margin: 6px 0;"><strong>Message:</strong></p>
                  <div style="background-color: #0d0d12; padding: 12px; border-radius: 8px; font-size: 13px; line-height: 1.5; margin-top: 6px;">${data.message}</div>
                  <p style="margin: 6px 0; font-size: 12px; color: #a1a1aa;"><strong>Timestamp:</strong> ${timestamp}</p>
                </div>
                <div style="margin-top: 24px; display: flex; flex-wrap: wrap; gap: 10px;">
                  <a href="tel:${data.phone}" style="background-color: #ffe600; color: #000; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: 800; font-size: 13px; display: inline-block;">📞 Call Client</a>
                  ${cleanDigits ? `<a href="https://wa.me/${cleanDigits}" style="background-color: #25D366; color: #000; padding: 12px 24px; border-radius: 9999px; text-decoration: none; font-weight: 800; font-size: 13px; display: inline-block;">💬 WhatsApp</a>` : ''}
                  <a href="mailto:${data.email}?subject=UPTODATE%20Response%20to%20Inquiry" style="background-color: rgba(255,255,255,0.1); color: #fff; padding: 12px 20px; border-radius: 9999px; text-decoration: none; font-size: 13px; display: inline-block;">✉️ Reply via Email</a>
                </div>
              </div>
            </div>
          `
        },
        source: 'contact_enquiries',
        sourceId: docRef.id,
        createdAt: timestamp
      });

      // 3. Automated Client Confirmation Email: Sent to client's personal email
      if (data.email && data.email.includes('@')) {
        await addDoc(mailCol, {
          to: [data.email.trim()],
          message: {
            subject: `We’ve Received Your Inquiry — UptoDate`,
            text: `Hi ${data.name},\n\nThank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.\n\nLooking forward to working with you.\n\nBest regards,\nJasmine Tiwari\nUptoDate`,
            html: `
              <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #08080a; color: #f4f4f5; padding: 24px;">
                <div style="max-width: 560px; margin: 0 auto; background-color: #11131a; border: 1px solid rgba(255,230,0,0.3); border-radius: 16px; padding: 32px; box-shadow: 0 10px 30px rgba(0,0,0,0.5);">
                  <div style="margin-bottom: 24px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 16px;">
                    <span style="display: inline-block; background-color: rgba(255,230,0,0.15); color: #ffe600; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em; padding: 4px 10px; border-radius: 9999px; margin-bottom: 8px;">UptoDate Inquiry Confirmation</span>
                    <h1 style="color: #ffffff; font-size: 22px; font-weight: 800; margin: 6px 0 0 0; letter-spacing: -0.02em;">We’ve Received Your Inquiry — UptoDate</h1>
                  </div>
                  
                  <div style="color: #e4e4e7; font-size: 15px; line-height: 1.7;">
                    <p style="margin-top: 0;">Hi <strong style="color: #ffe600;">${data.name}</strong>,</p>
                    <p>Thank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps.</p>
                    <p>Looking forward to working with you.</p>
                    <p style="margin-bottom: 0;">Best regards,<br/><strong style="color: #ffffff;">Jasmine Tiwari</strong><br/><span style="color: #ffe600; font-weight: 700;">UptoDate</span></p>
                  </div>
                </div>
              </div>
            `
          },
          source: 'contact_enquiries_client_receipt',
          recipientName: data.name,
          createdAt: timestamp
        });
      }
    } catch (mailErr) {
      console.warn('Mail collection dispatch note:', mailErr);
    }
  };

  const updateAbout = async (data: Partial<AboutSectionData>) => {
    const aboutDocRef = doc(db, 'about_content', 'main');
    await setDoc(aboutDocRef, {
      ...aboutData,
      ...data,
      updatedAt: new Date().toISOString(),
      updatedBy: user?.email || 'admin'
    }, { merge: true });
  };

  return (
    <AppContext.Provider
      value={{
        user,
        isAdmin,
        isAuthLoading,
        currentPage,
        setCurrentPage,
        projects,
        isProjectsLoading,
        aboutData,
        activeSearchQuery,
        setActiveSearchQuery,
        selectedCategory,
        setSelectedCategory,
        demoModalOpen,
        setDemoModalOpen,
        servicesModalOpen,
        setServicesModalOpen,
        authModalOpen,
        setAuthModalOpen,
        activeProjectModal,
        setActiveProjectModal,
        editingProjectId,
        setEditingProjectId,
        openEditInAdmin,
        loginWithEmail,
        registerWithEmail,
        loginWithGoogle,
        logout,
        toggleDemoAdmin,
        addProject,
        editProject,
        removeProject,
        saveDemoBooking,
        saveContactEnquiry,
        updateAbout,
        demoBookings,
        contactEnquiries
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
