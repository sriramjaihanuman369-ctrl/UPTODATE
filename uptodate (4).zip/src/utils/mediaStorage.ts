import { useState, useEffect } from 'react';
import { db } from '../firebase';
import { doc, getDoc, setDoc, collection, getDocs } from 'firebase/firestore';

/**
 * Media Storage Utility using IndexedDB, Cloud Firestore Chunks & Object URLs
 * Enables uploading full-fidelity video and image files directly from the local file explorer
 * without size restrictions, persisting them permanently across sessions and to the cloud
 * so that videos play on the published site, across devices, and for all public visitors.
 */

const DB_NAME = 'uptodate_media_db';
const DB_VERSION = 1;
const STORE_NAME = 'media_files';
const CHUNK_SIZE = 500000; // 500KB binary chunks (~667KB base64), comfortably below Firestore's 1MB limit

// In-memory cache for created Object URLs to prevent redundant network/IDB calls and memory leaks
const objectUrlCache = new Map<string, string>();
// In-flight download promises deduplication
const inFlightDownloads = new Map<string, Promise<string>>();

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported in this environment'));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        database.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };

    request.onsuccess = () => {
      resolve(request.result);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

export interface StoredMediaRecord {
  id: string;
  name: string;
  type: string;
  size: number;
  blob: Blob;
  createdAt: number;
  cloudSynced?: boolean;
}

/**
 * Helper to convert ArrayBuffer to Base64 efficiently without call-stack overflow
 */
function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  const chunkSize = 0x8000; // 32KB
  for (let i = 0; i < len; i += chunkSize) {
    const end = Math.min(i + chunkSize, len);
    binary += String.fromCharCode.apply(null, Array.from(bytes.subarray(i, end)));
  }
  return btoa(binary);
}

/**
 * Helper to convert Base64 string to Uint8Array
 */
function base64ToUint8Array(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Uploads a media file/blob to persistent Cloud Firestore in sequential chunks
 * Ensures the video is stored permanently in the database, NOT as a temporary local file.
 */
export async function uploadMediaToCloud(
  fileOrBlob: Blob,
  mediaId: string,
  metadata?: { name?: string; type?: string }
): Promise<boolean> {
  try {
    const metaRef = doc(db, 'uploaded_videos', mediaId);
    
    // Check if metadata already exists in Firestore
    const existingSnap = await getDoc(metaRef).catch(() => null);
    if (existingSnap && existingSnap.exists()) {
      const data = existingSnap.data();
      if (data && data.totalChunks && data.totalChunks > 0) {
        return true; // Already safely backed up
      }
    }

    const name = metadata?.name || (fileOrBlob instanceof File ? fileOrBlob.name : `${mediaId}.mp4`);
    const type = metadata?.type || fileOrBlob.type || 'video/mp4';
    const buffer = await fileOrBlob.arrayBuffer();
    const totalBytes = buffer.byteLength;
    const totalChunks = Math.ceil(totalBytes / CHUNK_SIZE);

    // Save individual chunks to subcollection
    for (let i = 0; i < totalChunks; i++) {
      const start = i * CHUNK_SIZE;
      const end = Math.min(start + CHUNK_SIZE, totalBytes);
      const slice = buffer.slice(start, end);
      const base64Data = arrayBufferToBase64(slice);

      const chunkRef = doc(db, 'uploaded_videos', mediaId, 'chunks', String(i));
      await setDoc(chunkRef, {
        index: i,
        data: base64Data
      });
    }

    // Save metadata record
    await setDoc(metaRef, {
      id: mediaId,
      name,
      type,
      size: totalBytes,
      totalChunks,
      createdAt: Date.now()
    });

    console.log(`[MediaStorage] Video ${mediaId} (${totalBytes} bytes, ${totalChunks} chunks) permanently saved to Firestore.`);
    return true;
  } catch (err) {
    console.warn('[MediaStorage] uploadMediaToCloud error:', err);
    return false;
  }
}

/**
 * Downloads a media file/blob from Cloud Firestore chunks and reconstructs the Blob
 */
export async function downloadMediaFromCloud(mediaId: string): Promise<Blob | null> {
  try {
    const metaRef = doc(db, 'uploaded_videos', mediaId);
    const metaSnap = await getDoc(metaRef);
    if (!metaSnap.exists()) {
      return null;
    }

    const meta = metaSnap.data();
    const chunksSnap = await getDocs(collection(db, 'uploaded_videos', mediaId, 'chunks'));
    if (chunksSnap.empty) {
      return null;
    }

    const chunkDocs = chunksSnap.docs.map(d => d.data() as { index: number; data: string });
    chunkDocs.sort((a, b) => a.index - b.index);

    const byteArrays: Uint8Array[] = [];
    for (const chunk of chunkDocs) {
      byteArrays.push(base64ToUint8Array(chunk.data));
    }

    const reconstructedBlob = new Blob(byteArrays as BlobPart[], { type: meta.type || 'video/mp4' });

    // Cache into local IndexedDB for lightning-fast subsequent loads
    try {
      const database = await openDatabase();
      const transaction = database.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      store.put({
        id: mediaId,
        name: meta.name || `${mediaId}.mp4`,
        type: meta.type || 'video/mp4',
        size: reconstructedBlob.size,
        blob: reconstructedBlob,
        createdAt: Date.now(),
        cloudSynced: true
      });
    } catch (e) {
      console.warn('[MediaStorage] Failed to cache reconstructed blob to IDB:', e);
    }

    return reconstructedBlob;
  } catch (err) {
    console.warn('[MediaStorage] downloadMediaFromCloud error:', err);
    return null;
  }
}

/**
 * Save a media file (video or image) to IndexedDB, caches URL, and kicks off cloud sync
 */
export async function saveMediaToStorage(
  file: File | Blob, 
  customId?: string, 
  fileName?: string
): Promise<{ id: string; blobUrl: string }> {
  const id = customId || `media_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const name = fileName || (file instanceof File ? file.name : 'media_file');
  const type = file.type || (name.endsWith('.mp4') ? 'video/mp4' : 'application/octet-stream');

  try {
    const database = await openDatabase();
    await new Promise<void>((resolve, reject) => {
      const transaction = database.transaction(STORE_NAME, 'readwrite');
      const store = transaction.objectStore(STORE_NAME);
      const record: StoredMediaRecord = {
        id,
        name,
        type,
        size: file.size,
        blob: file,
        createdAt: Date.now(),
        cloudSynced: false
      };
      const req = store.put(record);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });

    // Create and cache an Object URL for instantaneous playback
    const blobUrl = URL.createObjectURL(file);
    objectUrlCache.set(id, blobUrl);

    // Asynchronously sync to permanent cloud Firestore in the background
    uploadMediaToCloud(file, id, { name, type }).then(synced => {
      if (synced) {
        openDatabase().then(dbase => {
          const tx = dbase.transaction(STORE_NAME, 'readwrite');
          const store = tx.objectStore(STORE_NAME);
          store.get(id).onsuccess = (ev: any) => {
            const rec = ev.target.result;
            if (rec) {
              rec.cloudSynced = true;
              store.put(rec);
            }
          };
        }).catch(() => {});
      }
    });

    // Also attempt server sync if running in node/vite dev environment
    uploadMediaToServer(file, id, name).catch(() => {});

    return { id, blobUrl };
  } catch (error) {
    console.warn('IndexedDB save note, falling back to session blob URL:', error);
    const blobUrl = URL.createObjectURL(file);
    objectUrlCache.set(id, blobUrl);
    // Still backup to cloud!
    uploadMediaToCloud(file, id, { name, type }).catch(() => {});
    return { id, blobUrl };
  }
}

/**
 * Retrieve a media blob from IndexedDB by ID
 */
export async function getMediaFromStorage(id: string): Promise<Blob | null> {
  try {
    const database = await openDatabase();
    return new Promise((resolve) => {
      const transaction = database.transaction(STORE_NAME, 'readonly');
      const store = transaction.objectStore(STORE_NAME);
      const req = store.get(id);
      req.onsuccess = () => {
        const record = req.result as StoredMediaRecord | undefined;
        resolve(record ? record.blob : null);
      };
      req.onerror = () => resolve(null);
    });
  } catch (err) {
    return null;
  }
}

/**
 * Uploads a media file/blob to the server's /videos directory for local hosting
 */
export async function uploadMediaToServer(
  fileOrBlob: File | Blob, 
  customId?: string, 
  fileName?: string
): Promise<string | null> {
  try {
    const name = fileName || (fileOrBlob instanceof File ? fileOrBlob.name : 'video.mp4');
    const id = customId || `media_${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    
    const response = await fetch('/api/upload', {
      method: 'POST',
      headers: {
        'x-file-id': id,
        'x-file-name': name,
        'content-type': fileOrBlob.type || 'video/mp4'
      },
      body: fileOrBlob
    });

    if (response.ok) {
      const data = await response.json();
      if (data.url) {
        return data.url;
      }
    }
  } catch (err) {
    // Non-blocking fallback
  }
  return null;
}

/**
 * Extracts pure media ID from any url/key format
 * (e.g. "idb:media_123" -> "media_123", "/videos/media_123.mp4" -> "media_123", "media_123" -> "media_123")
 */
export function extractMediaId(urlOrKey: string): string | null {
  if (!urlOrKey) return null;
  const trimmed = urlOrKey.trim();
  if (trimmed.startsWith('idb:')) {
    return trimmed.replace('idb:', '');
  }
  const match = trimmed.match(/(?:^|\/)(media_[a-zA-Z0-9_-]+)(?:\.[a-zA-Z0-9]+)?$/);
  if (match) {
    return match[1];
  }
  return null;
}

/**
 * Sanitizes video URLs without modifying original user intent
 */
export function sanitizeVideoUrl(urlOrKey?: string): string {
  if (!urlOrKey) return '';
  return urlOrKey.trim();
}

/**
 * Resolve any media URL:
 * - If it's an IndexedDB key or media ID (`idb:media_...` or `/videos/media_...`):
 *   1. Returns from memory cache if active
 *   2. Retrieves the blob from browser IndexedDB and returns Object URL
 *   3. If not in local browser (e.g. published site or another device), fetches the persistent
 *      video from Cloud Firestore chunks, caches it locally, and plays seamlessly!
 *   4. Checks static file fallback `/videos/${id}.mp4`
 * - If it's a regular /videos/, http, https, data, or blob URL, returns it directly.
 */
export async function resolveMediaUrl(urlOrKey: string): Promise<string> {
  if (!urlOrKey) return '';
  const trimmed = urlOrKey.trim();

  const mediaId = extractMediaId(trimmed);

  if (mediaId) {
    // 1. Check in-memory URL cache
    if (objectUrlCache.has(mediaId)) {
      return objectUrlCache.get(mediaId)!;
    }

    // Deduplicate concurrent requests for the same media ID
    if (inFlightDownloads.has(mediaId)) {
      return inFlightDownloads.get(mediaId)!;
    }

    const downloadPromise = (async () => {
      // 2. Check local IndexedDB
      const localBlob = await getMediaFromStorage(mediaId);
      if (localBlob) {
        const blobUrl = URL.createObjectURL(localBlob);
        objectUrlCache.set(mediaId, blobUrl);

        // Ensure cloud backup is complete in the background
        uploadMediaToCloud(localBlob, mediaId).catch(() => {});
        return blobUrl;
      }

      // 3. Check permanent Cloud Firestore chunks (for published website and all public visitors)
      const cloudBlob = await downloadMediaFromCloud(mediaId);
      if (cloudBlob) {
        const blobUrl = URL.createObjectURL(cloudBlob);
        objectUrlCache.set(mediaId, blobUrl);
        return blobUrl;
      }

      // 4. Fallback to server static file
      return `/videos/${mediaId}.mp4`;
    })();

    inFlightDownloads.set(mediaId, downloadPromise);
    try {
      const result = await downloadPromise;
      return result;
    } finally {
      inFlightDownloads.delete(mediaId);
    }
  }

  return trimmed;
}

/**
 * Synchronous resolver for instant initial renders using in-memory cache
 */
export function getCachedMediaUrl(urlOrKey: string): string {
  if (!urlOrKey) return '';
  const trimmed = urlOrKey.trim();
  const mediaId = extractMediaId(trimmed);
  if (mediaId) {
    return objectUrlCache.get(mediaId) || `/videos/${mediaId}.mp4`;
  }
  return trimmed;
}

/**
 * Synchronizes all local media records stored in this browser's IndexedDB to Cloud Firestore
 * Ensures that previously uploaded videos (from earlier turns/sessions) are permanently available
 * on the published site for all visitors.
 */
export async function syncAllLocalMediaToCloud(): Promise<void> {
  try {
    const database = await openDatabase();
    const records: StoredMediaRecord[] = await new Promise((resolve) => {
      const tx = database.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.getAll();
      req.onsuccess = () => resolve(req.result || []);
      req.onerror = () => resolve([]);
    });

    for (const record of records) {
      if (record && record.blob && record.id) {
        uploadMediaToCloud(record.blob, record.id, { name: record.name, type: record.type })
          .catch(() => {});
      }
    }
  } catch (err) {
    console.debug('[MediaStorage] syncAllLocalMediaToCloud notice:', err);
  }
}

/**
 * Optimizes an image File into a web-ready Data URL (resizing if oversized, converting to high-quality JPEG)
 * Ensures the thumbnail can be stored in Firestore and local state safely (<300KB)
 */
export function optimizeImageFile(
  file: File, 
  maxWidth = 1600, 
  maxHeight = 1000, 
  quality = 0.85
): Promise<{ dataUrl: string; width: number; height: number; size: number }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth) {
          height = Math.round((height * maxWidth) / width);
          width = maxWidth;
        }
        if (height > maxHeight) {
          width = Math.round((width * maxHeight) / height);
          height = maxHeight;
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve({ dataUrl: event.target?.result as string, width, height, size: file.size });
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        const approxSize = Math.round((dataUrl.length * 3) / 4);

        resolve({
          dataUrl,
          width,
          height,
          size: approxSize
        });
      };
      img.onerror = () => reject(new Error('Failed to decode image file.'));
      img.src = event.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read image file.'));
    reader.readAsDataURL(file);
  });
}

/**
 * Format bytes to readable human size (e.g. 2.4 MB)
 */
export function formatFileSize(bytes: number): string {
  if (!bytes || bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

/**
 * React hook to transparently resolve any media URL (whether idb:, cloud:, blob:, or http:)
 */
export function useMediaUrl(urlOrKey?: string): string {
  const sanitized = sanitizeVideoUrl(urlOrKey);
  const [resolved, setResolved] = useState<string>(() => getCachedMediaUrl(sanitized || ''));

  useEffect(() => {
    let mounted = true;
    if (!sanitized) {
      setResolved('');
      return;
    }

    resolveMediaUrl(sanitized).then((res) => {
      if (mounted && res) {
        setResolved(res);
      }
    });

    return () => {
      mounted = false;
    };
  }, [sanitized]);

  return resolved;
}
