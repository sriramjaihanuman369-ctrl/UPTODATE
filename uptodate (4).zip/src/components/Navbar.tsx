import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Menu, 
  X, 
  PhoneCall, 
  User as UserIcon, 
  LogOut, 
  Shield, 
  Layers, 
  ArrowUpRight, 
  ChevronDown,
  FolderGit2
} from 'lucide-react';
import { PageView } from '../types';
import { UptodateLogo } from './UptodateLogo';

export const Navbar: React.FC = () => {
  const { 
    currentPage, 
    setCurrentPage, 
    user, 
    isAdmin, 
    logout, 
    setDemoModalOpen, 
    setServicesModalOpen, 
    setAuthModalOpen 
  } = useApp();

  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems: { label: string; page: PageView; isServicePopup?: boolean }[] = [
    { label: 'Home', page: 'home' },
    { label: 'About', page: 'about' },
    { label: 'Services', page: 'services', isServicePopup: true },
    { label: 'Projects', page: 'projects' },
    { label: 'Contact', page: 'contact' },
  ];

  const handleNavClick = (page: PageView, isServicePopup?: boolean) => {
    if (isServicePopup) {
      setServicesModalOpen(true);
    } else {
      setCurrentPage(page);
    }
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header 
      id="main-header"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-[#0D0704]/90 backdrop-blur-xl border-b border-[#FF6A00]/20 shadow-[0_10px_35px_rgba(0,0,0,0.8),0_1px_15px_rgba(255,106,0,0.08)] py-3.5' 
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        
        {/* LOGO: UPTODATE */}
        <button 
          id="brand-logo-btn"
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-3 group text-left focus:outline-none cursor-pointer"
        >
          <UptodateLogo variant="full" theme="white" size="md" />
        </button>

        {/* Desktop Navigation Links */}
        <nav id="desktop-nav" className="hidden md:flex items-center gap-1 bg-[#140C08]/85 backdrop-blur-md px-4 py-1.5 rounded-full border border-[#FF6A00]/20 shadow-[0_4px_25px_rgba(0,0,0,0.6)]">
          {navItems.map((item) => {
            const isActive = currentPage === item.page;
            return (
              <button
                key={item.label}
                id={`nav-${item.label.toLowerCase()}`}
                onClick={() => handleNavClick(item.page, item.isServicePopup)}
                className={`relative px-4 py-2 text-sm font-medium rounded-full transition-all duration-200 flex items-center gap-1.5 ${
                  isActive && !item.isServicePopup
                    ? 'text-[#F5F1EC] bg-[#FF6A00]/20 border border-[#FF6A00]/30 shadow-sm font-semibold' 
                    : 'text-[#B8ACA3] hover:text-[#F5F1EC] hover:bg-[#FF6A00]/10'
                }`}
              >
                <span>{item.label}</span>
                {item.isServicePopup && (
                  <ChevronDown className="w-3.5 h-3.5 text-[#FFB347] group-hover:translate-y-0.5 transition-transform" />
                )}
                {isActive && !item.isServicePopup && (
                  <span className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1.5 h-1.5 rounded-full bg-[#FF6A00]"></span>
                )}
              </button>
            );
          })}

          {isAdmin && (
            <button
              id="nav-my-listings"
              onClick={() => handleNavClick('my-listings')}
              className={`px-3.5 py-2 text-sm font-medium rounded-full transition-all duration-200 flex items-center gap-1.5 ${
                currentPage === 'my-listings'
                  ? 'text-[#FFB347] bg-[#FF6A00]/20 border border-[#FF6A00]/30 font-semibold'
                  : 'text-[#B8ACA3] hover:text-[#F5F1EC] hover:bg-[#FF6A00]/10'
              }`}
            >
              <FolderGit2 className="w-3.5 h-3.5 text-[#FFB347]" />
              <span>Manage Projects</span>
            </button>
          )}

          {isAdmin && (
            <button
              id="nav-admin-dashboard"
              onClick={() => handleNavClick('admin')}
              className={`px-3 py-2 text-xs uppercase tracking-wider font-mono font-bold rounded-full transition-all duration-200 flex items-center gap-1.5 ${
                currentPage === 'admin'
                  ? 'text-[#FFB347] bg-[#FF6A00]/25 border border-[#FF6A00]/40'
                  : 'text-[#FFB347]/90 hover:text-[#FFB347] hover:bg-[#FF6A00]/10'
              }`}
            >
              <Shield className="w-3 h-3 text-[#FFB347]" />
              <span>Admin</span>
            </button>
          )}
        </nav>

        {/* Right Action Controls: Book Call (Highlighted) & User Profile */}
        <div className="hidden md:flex items-center gap-3">
          
          {/* User Sign In / Profile dropdown */}
          {user ? (
            <div className="relative">
              <button
                id="user-profile-btn"
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#140C08] hover:bg-[#1C120C] border border-[#FF6A00]/25 text-xs font-medium text-[#F5F1EC] transition-colors"
              >
                <div className="w-6 h-6 rounded-full bg-gradient-to-r from-[#FF6A00] to-[#FFB347] flex items-center justify-center text-[#0D0704] font-bold text-[11px]">
                  {user.email ? user.email[0].toUpperCase() : 'U'}
                </div>
                <span className="max-w-[90px] truncate">{user.displayName || user.email?.split('@')[0]}</span>
                <ChevronDown className="w-3 h-3 text-[#B8ACA3]" />
              </button>

              {userDropdownOpen && (
                <div 
                  id="user-dropdown-menu"
                  className="absolute right-0 mt-2 w-56 bg-[#140C08] border border-[#FF6A00]/30 rounded-2xl p-2 shadow-[0_15px_40px_rgba(0,0,0,0.85),0_0_20px_rgba(255,106,0,0.15)] z-50"
                >
                  <div className="px-3 py-2 border-b border-[#FF6A00]/15 mb-1">
                    <p className="text-xs text-[#B8ACA3]">Signed in as</p>
                    <p className="text-xs font-semibold text-[#F5F1EC] truncate">{user.email}</p>
                    {isAdmin && (
                      <span className="inline-block mt-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/30">
                        ADMIN PRIVILEGES
                      </span>
                    )}
                  </div>
                  {isAdmin && (
                    <>
                      <button
                        id="dropdown-my-listings"
                        onClick={() => {
                          setUserDropdownOpen(false);
                          setCurrentPage('my-listings');
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs text-[#B8ACA3] hover:text-[#F5F1EC] hover:bg-[#FF6A00]/10 rounded-lg text-left"
                      >
                        <FolderGit2 className="w-3.5 h-3.5 text-[#FFB347]" />
                        Manage Project Listings
                      </button>
                      <button
                        id="dropdown-admin-link"
                        onClick={() => {
                          setUserDropdownOpen(false);
                          setCurrentPage('admin');
                        }}
                        className="w-full flex items-center gap-2 px-3 py-2 text-xs text-[#FFB347] hover:text-white hover:bg-[#FF6A00]/15 rounded-lg text-left"
                      >
                        <Shield className="w-3.5 h-3.5 text-[#FFB347]" />
                        Admin Control Panel
                      </button>
                    </>
                  )}
                  <button
                    id="dropdown-logout-btn"
                    onClick={() => {
                      setUserDropdownOpen(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg text-left mt-1 border-t border-[#FF6A00]/15"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <button
              id="auth-sign-in-btn"
              onClick={() => setAuthModalOpen(true)}
              className="px-3.5 py-2 rounded-full text-xs font-medium text-[#F5F1EC] bg-[#140C08]/70 hover:bg-[#FF6A00]/15 border border-[#FF6A00]/30 hover:border-[#FF6A00]/60 transition-all flex items-center gap-1.5"
            >
              <UserIcon className="w-3.5 h-3.5 text-[#FFB347]" />
              <span>Sign In</span>
            </button>
          )}

          {/* Highlighted Book a Call Button on EXTREME RIGHT */}
          <button
            id="nav-book-call-btn"
            onClick={() => setDemoModalOpen(true)}
            className="yellow-btn text-[#0D0704] px-5 py-2.5 rounded-full font-black text-xs tracking-wider uppercase flex items-center gap-2 group cursor-pointer shadow-lg"
          >
            <PhoneCall className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform" />
            <span>Book a Call</span>
            <span className="text-[10px] bg-black/15 px-1.5 py-0.5 rounded font-mono hidden lg:inline">962511181</span>
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <div className="flex items-center gap-2 md:hidden">
          <button
            id="mobile-book-call-quick"
            onClick={() => setDemoModalOpen(true)}
            className="yellow-btn text-[#0D0704] px-3.5 py-1.5 rounded-full text-xs font-black uppercase tracking-wider flex items-center gap-1.5"
          >
            <PhoneCall className="w-3 h-3" />
            <span>Call</span>
          </button>
          <button
            id="mobile-menu-toggle"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 text-[#F5F1EC] hover:text-white bg-[#140C08] rounded-xl border border-[#FF6A00]/25 cursor-pointer"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div id="mobile-menu-drawer" className="md:hidden bg-[#120A06] border-b border-[#FF6A00]/30 px-6 py-6 space-y-4 shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
          <div className="flex flex-col gap-2">
            {navItems.map((item) => (
              <button
                key={item.label}
                id={`mobile-nav-${item.label.toLowerCase()}`}
                onClick={() => handleNavClick(item.page, item.isServicePopup)}
                className={`w-full py-3 px-4 rounded-xl text-left text-sm font-extrabold uppercase tracking-wider flex items-center justify-between cursor-pointer ${
                  currentPage === item.page && !item.isServicePopup
                    ? 'text-[#0D0704] bg-gradient-to-r from-[#FF6A00] to-[#FFB347] font-black'
                    : 'text-[#B8ACA3] hover:text-[#F5F1EC] hover:bg-[#FF6A00]/10'
                }`}
              >
                <span>{item.label}</span>
                {item.isServicePopup ? (
                  <span className="text-xs text-[#FFB347] font-mono">EXPLORE</span>
                ) : (
                  <ArrowUpRight className="w-4 h-4 text-[#B8ACA3]" />
                )}
              </button>
            ))}

            {isAdmin && (
              <button
                id="mobile-nav-my-listings"
                onClick={() => handleNavClick('my-listings')}
                className="w-full py-3 px-4 rounded-xl text-left text-sm font-bold uppercase tracking-wider flex items-center justify-between text-[#FFB347] bg-[#140C08] border border-[#FF6A00]/20 cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <FolderGit2 className="w-4 h-4" />
                  <span>Manage Listings (Admin)</span>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#B8ACA3]" />
              </button>
            )}

            {isAdmin && (
              <button
                id="mobile-nav-admin"
                onClick={() => handleNavClick('admin')}
                className="w-full py-3 px-4 rounded-xl text-left text-sm font-black uppercase tracking-wider flex items-center justify-between text-[#0D0704] bg-gradient-to-r from-[#FF6A00] to-[#FFB347] cursor-pointer"
              >
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[#0D0704]" />
                  <span>Admin Control Panel</span>
                </div>
                <ArrowUpRight className="w-4 h-4 text-[#0D0704]" />
              </button>
            )}
          </div>

          <div className="pt-4 border-t border-[#FF6A00]/20 flex flex-col gap-3">
            {user ? (
              <div className="flex items-center justify-between p-3 rounded-xl bg-[#140C08] border border-[#FF6A00]/25">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#FF6A00] to-[#FFB347] flex items-center justify-center text-[#0D0704] font-extrabold text-xs">
                    {user.email ? user.email[0].toUpperCase() : 'U'}
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#F5F1EC] truncate max-w-[170px]">{user.email}</p>
                    <p className="text-[10px] text-[#B8ACA3] uppercase font-mono">{isAdmin ? 'DIRECTOR (ADMIN)' : 'CLIENT (VIEWER)'}</p>
                  </div>
                </div>
                <button
                  id="mobile-logout-btn"
                  onClick={logout}
                  className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-lg cursor-pointer"
                  title="Sign Out"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                id="mobile-sign-in-btn"
                onClick={() => {
                  setMobileMenuOpen(false);
                  setAuthModalOpen(true);
                }}
                className="w-full py-3 rounded-xl bg-[#140C08] border border-[#FF6A00]/30 text-[#F5F1EC] font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
              >
                <UserIcon className="w-4 h-4 text-[#FFB347]" />
                <span>Sign In / Sign Up</span>
              </button>
            )}

            <button
              id="mobile-book-call-main"
              onClick={() => {
                setMobileMenuOpen(false);
                setDemoModalOpen(true);
              }}
              className="yellow-btn w-full py-3.5 rounded-xl text-[#0D0704] font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Book a Call (Direct: 962511181)</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
