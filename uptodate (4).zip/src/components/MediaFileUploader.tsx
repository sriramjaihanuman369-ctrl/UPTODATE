import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  Film, 
  Image as ImageIcon, 
  Trash2, 
  RefreshCw, 
  CheckCircle2, 
  AlertCircle, 
  Play, 
  Link as LinkIcon,
  FolderOpen,
  FileText
} from 'lucide-react';
import { 
  optimizeImageFile, 
  saveMediaToStorage, 
  uploadMediaToServer,
  resolveMediaUrl, 
  formatFileSize 
} from '../utils/mediaStorage';

interface ThumbnailUploaderProps {
  value: string;
  onChange: (value: string) => void;
  required?: boolean;
}

export const ThumbnailFileUploader: React.FC<ThumbnailUploaderProps> = ({
  value,
  onChange,
  required = false
}) => {
  const [mode, setMode] = useState<'file' | 'url'>('file');
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please select a valid image file (PNG, JPG, WEBP, GIF, etc.)');
      return;
    }

    try {
      setIsProcessing(true);
      setError('');
      setFileName(file.name);
      setFileSize(formatFileSize(file.size));

      // Optimize image for performance and reliable persistence
      const optimized = await optimizeImageFile(file, 1600, 1000, 0.85);
      onChange(optimized.dataUrl);
      setIsProcessing(false);
    } catch (err: any) {
      console.error('Image processing error:', err);
      setError('Failed to process image file. Please try another image.');
      setIsProcessing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleClear = () => {
    onChange('');
    setFileName('');
    setFileSize('');
    setError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-[#B8ACA3] flex items-center gap-1.5">
          <ImageIcon className="w-3.5 h-3.5 text-[#FFB347]" />
          <span>Project Thumbnail {required && <span className="text-[#FF6A00]">*</span>}</span>
        </label>
        <div className="flex items-center gap-1 text-[10px] font-mono">
          <button
            type="button"
            onClick={() => setMode('file')}
            className={`px-2 py-0.5 rounded-md transition-colors ${
              mode === 'file' 
                ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-bold' 
                : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
            }`}
          >
            File Explorer
          </button>
          <button
            type="button"
            onClick={() => setMode('url')}
            className={`px-2 py-0.5 rounded-md transition-colors ${
              mode === 'url' 
                ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-bold' 
                : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
            }`}
          >
            Enter Link
          </button>
        </div>
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
        }}
        accept="image/*"
        className="hidden"
      />

      {mode === 'file' ? (
        <div className="space-y-2">
          {value ? (
            /* Selected Image Preview Card */
            <div className="relative rounded-2xl border border-[#FF6A00]/40 bg-[#140C08] p-3 flex flex-col sm:flex-row items-center gap-3 overflow-hidden shadow-lg group">
              <div className="relative w-full sm:w-36 h-24 rounded-xl overflow-hidden bg-black shrink-0 border border-[#FF6A00]/20">
                <img 
                  src={value} 
                  alt="Thumbnail Preview" 
                  className="w-full h-full object-cover" 
                />
              </div>

              <div className="flex-1 min-w-0 space-y-1 text-left w-full sm:w-auto">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F5F1EC] truncate">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="truncate">{fileName || 'Uploaded Image File'}</span>
                </div>
                {fileSize && (
                  <p className="text-[10px] font-mono text-[#B8ACA3]">
                    Size: <span className="text-[#FFB347] font-semibold">{fileSize}</span>
                  </p>
                )}
                <div className="flex items-center gap-2 pt-1.5">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-2.5 py-1 rounded-lg bg-[#1C100A] hover:bg-[#25150E] border border-[#FF6A00]/20 text-[#F5F1EC] text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Change File</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleClear}
                    className="px-2.5 py-1 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Remove</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Upload / Drag and drop dropzone */
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-5 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-2 ${
                isDragging 
                  ? 'border-[#FF6A00] bg-[#FF6A00]/10' 
                  : 'border-[#FF6A00]/25 hover:border-[#FF6A00]/60 bg-[#1C100A] hover:bg-[#25150E]'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-[#FF6A00]/15 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347] shadow-md">
                {isProcessing ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <FolderOpen className="w-5 h-5" />
                )}
              </div>

              <div>
                <p className="text-xs font-semibold text-[#F5F1EC] flex items-center justify-center gap-1.5">
                  <span>Click to browse File Explorer</span>
                  <span className="text-[#B8ACA3]/60 font-normal">or drag & drop</span>
                </p>
                <p className="text-[10px] text-[#B8ACA3] mt-0.5">
                  PNG, JPG, WEBP, or GIF (auto-optimized)
                </p>
              </div>

              <span className="px-3 py-1 rounded-full bg-[#140C08] border border-[#FF6A00]/30 text-[#F5F1EC] text-[10px] font-mono hover:bg-[#FF6A00] hover:text-[#0D0704] transition-colors">
                Select from Device
              </span>
            </div>
          )}
        </div>
      ) : (
        /* Direct URL input fallback */
        <div className="relative">
          <LinkIcon className="w-3.5 h-3.5 text-[#B8ACA3] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="url"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder="https://images.unsplash.com/... or https://..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
          />
        </div>
      )}

      {error && (
        <p className="text-[11px] text-red-400 flex items-center gap-1">
          <AlertCircle className="w-3 h-3 shrink-0" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
};

interface VideoUploaderProps {
  value: string;
  onChange: (value: string) => void;
  videoType: 'mp4' | 'youtube' | 'vimeo' | 'drive';
  onTypeChange: (type: 'mp4' | 'youtube' | 'vimeo' | 'drive') => void;
  aspectRatio?: '16:9' | '9:16' | '1:1' | 'auto';
  onAspectRatioChange?: (ratio: '16:9' | '9:16' | '1:1' | 'auto') => void;
  posterImage?: string;
  onThumbnailGenerated?: (dataUrl: string) => void;
}

export const VideoFileUploader: React.FC<VideoUploaderProps> = ({
  value,
  onChange,
  videoType,
  onTypeChange,
  aspectRatio = 'auto',
  onAspectRatioChange,
  posterImage,
  onThumbnailGenerated
}) => {
  const [mode, setMode] = useState<'file' | 'url'>('file');
  const [isDragging, setIsDragging] = useState(false);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [resolvedUrl, setResolvedUrl] = useState<string>('');
  const [detectedRatio, setDetectedRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [videoDims, setVideoDims] = useState<{ width: number; height: number } | null>(null);
  const [error, setError] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Active effective ratio
  const effectiveRatio: '16:9' | '9:16' | '1:1' = 
    aspectRatio !== 'auto' ? (aspectRatio as '16:9' | '9:16' | '1:1') : detectedRatio;

  // Resolve media url if stored as idb: or /videos/
  useEffect(() => {
    let isMounted = true;
    if (value) {
      resolveMediaUrl(value).then((res) => {
        if (isMounted) setResolvedUrl(res);
      });
    } else {
      setResolvedUrl('');
      setVideoDims(null);
    }
    return () => {
      isMounted = false;
    };
  }, [value]);

  const detectRatioFromDimensions = (w: number, h: number) => {
    const r = w / h;
    let det: '16:9' | '9:16' | '1:1' = '16:9';
    if (r < 0.85) {
      det = '9:16';
    } else if (r >= 0.85 && r <= 1.25) {
      det = '1:1';
    } else {
      det = '16:9';
    }
    setDetectedRatio(det);
    setVideoDims({ width: w, height: h });
    if (aspectRatio === 'auto' && onAspectRatioChange) {
      onAspectRatioChange(det);
    }
  };

  const handleFile = async (file: File) => {
    if (!file.type.startsWith('video/') && !file.name.match(/\.(mp4|webm|mov|mkv|ogg)$/i)) {
      setError('Please select a valid video file (MP4, WEBM, MOV, etc.)');
      return;
    }

    try {
      setIsProcessing(true);
      setError('');
      setFileName(file.name);
      setFileSize(formatFileSize(file.size));
      onTypeChange('mp4');

      // 1. Instant local object URL for zero-delay preview and ratio detection
      const directBlobUrl = URL.createObjectURL(file);
      setResolvedUrl(directBlobUrl);

      // Pre-detect dimensions & capture video frame thumbnail using in-memory video
      try {
        const tempVideo = document.createElement('video');
        tempVideo.preload = 'auto';
        tempVideo.muted = true;
        tempVideo.playsInline = true;
        tempVideo.src = directBlobUrl;
        
        tempVideo.onloadedmetadata = () => {
          if (tempVideo.videoWidth && tempVideo.videoHeight) {
            detectRatioFromDimensions(tempVideo.videoWidth, tempVideo.videoHeight);
          }
          // Seek ~0.5s into the video to capture a crisp video thumbnail
          tempVideo.currentTime = Math.min(0.5, (tempVideo.duration || 1) / 2);
        };

        tempVideo.onseeked = () => {
          try {
            const canvas = document.createElement('canvas');
            canvas.width = tempVideo.videoWidth || 1280;
            canvas.height = tempVideo.videoHeight || 720;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(tempVideo, 0, 0, canvas.width, canvas.height);
              const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
              onThumbnailGenerated?.(dataUrl);
            }
          } catch (snapErr) {
            console.debug('Video thumbnail snapshot note:', snapErr);
          }
        };
      } catch (e) {
        console.warn('Metadata pre-detection note:', e);
      }

      // 2. Save to IndexedDB & Object URL cache IMMEDIATELY
      const { id, blobUrl } = await saveMediaToStorage(file, undefined, file.name);
      setResolvedUrl(blobUrl);

      // CRITICAL FIX: IMMEDIATELY set the form's videoUrl to `idb:${id}`!
      // This guarantees videoUrl is NEVER empty in the project form when the user clicks Publish!
      onChange(`idb:${id}`);
      setIsProcessing(false);

      // 3. In the background, upload to server storage if supported
      uploadMediaToServer(file, id, file.name).then((serverUrl) => {
        if (serverUrl) {
          onChange(serverUrl);
        }
      }).catch((err) => {
        console.debug('Background server upload note:', err);
      });
    } catch (err: any) {
      console.error('Video file upload error:', err);
      setError('Failed to process video file.');
      setIsProcessing(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFile(file);
    }
  };

  const handleClear = () => {
    onChange('');
    setResolvedUrl('');
    setFileName('');
    setFileSize('');
    setVideoDims(null);
    setDetectedRatio('16:9');
    setError('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleVideoMetadataLoaded = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    const el = e.currentTarget;
    if (el.videoWidth && el.videoHeight) {
      detectRatioFromDimensions(el.videoWidth, el.videoHeight);
    }
  };

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-[#B8ACA3] flex items-center gap-1.5">
          <Film className="w-3.5 h-3.5 text-[#FFB347]" />
          <span>Project Video / Reel Media</span>
        </label>
        <div className="flex items-center gap-1 text-[10px] font-mono">
          <button
            type="button"
            onClick={() => setMode('file')}
            className={`px-2 py-0.5 rounded-md transition-colors ${
              mode === 'file' 
                ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-bold' 
                : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
            }`}
          >
            File Explorer
          </button>
          <button
            type="button"
            onClick={() => setMode('url')}
            className={`px-2 py-0.5 rounded-md transition-colors ${
              mode === 'url' 
                ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-bold' 
                : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
            }`}
          >
            Enter Link
          </button>
        </div>
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
        }}
        accept="video/mp4,video/webm,video/quicktime,video/ogg,video/*"
        className="hidden"
      />

      {mode === 'file' ? (
        <div className="space-y-2">
          {(value || resolvedUrl) ? (
            /* Live Video Player Preview Card adapted to video ratio */
            <div className="relative rounded-2xl border border-[#FF6A00]/40 bg-[#140C08] p-3 space-y-3 overflow-hidden shadow-lg">
              {/* Dynamic Ratio Frame: 9:16 vertical phone reel vs 16:9 widescreen */}
              <div className="relative flex justify-center items-center py-2 bg-black/40 rounded-xl overflow-hidden min-h-[160px]">
                {resolvedUrl ? (
                  <div 
                    className={`relative overflow-hidden bg-black border border-[#FF6A00]/20 transition-all duration-300 shadow-2xl ${
                      effectiveRatio === '9:16'
                        ? 'w-[240px] sm:w-[260px] aspect-[9/16] rounded-2xl border-[#FF6A00]/40'
                        : effectiveRatio === '1:1'
                          ? 'w-[280px] aspect-square rounded-2xl'
                          : 'w-full aspect-video rounded-xl'
                    }`}
                  >
                    <video
                      src={resolvedUrl}
                      controls
                      playsInline
                      poster={posterImage}
                      onLoadedMetadata={handleVideoMetadataLoaded}
                      className="w-full h-full object-contain bg-black"
                    />

                    {/* Ratio badge over preview */}
                    <div className="absolute top-2.5 left-2.5 pointer-events-none z-10">
                      <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase tracking-wider bg-black/80 backdrop-blur-md text-[#FFB347] border border-[#FF6A00]/30">
                        {effectiveRatio === '9:16' ? '📱 9:16 Reel' : effectiveRatio === '1:1' ? '⏹️ 1:1 Square' : '🖥️ 16:9 Video'}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center p-8 gap-2">
                    <RefreshCw className="w-6 h-6 animate-spin text-[#FF6A00]" />
                    <p className="text-xs text-[#B8ACA3] font-mono">Loading video stream...</p>
                  </div>
                )}
              </div>

              {/* Ratio Selector Controls */}
              <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/20">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="text-[11px] font-semibold text-[#B8ACA3] shrink-0">Ratio:</span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/30 shrink-0">
                    {effectiveRatio === '9:16' ? '9:16 Reel' : (effectiveRatio === '1:1' ? '1:1 Square' : '16:9 Widescreen')}
                  </span>
                  {videoDims && (
                    <span className="text-[10px] font-mono text-[#B8ACA3]/50 truncate hidden sm:inline">
                      ({videoDims.width}×{videoDims.height})
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1">
                  {(['auto', '9:16', '16:9', '1:1'] as const).map((r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => onAspectRatioChange?.(r)}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono cursor-pointer transition-all ${
                        aspectRatio === r
                          ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-bold shadow'
                          : 'bg-[#140C08] hover:bg-[#25150E] text-[#B8ACA3] hover:text-[#F5F1EC] border border-[#FF6A00]/20'
                      }`}
                    >
                      {r === 'auto' ? `Auto (${detectedRatio})` : r}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between gap-2 pt-1 border-t border-[#FF6A00]/15">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#F5F1EC] truncate">
                    {isProcessing ? (
                      <RefreshCw className="w-3.5 h-3.5 text-[#FFB347] animate-spin shrink-0" />
                    ) : (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    )}
                    <span className="truncate">{fileName || (value ? 'Attached Project Video' : 'Uploaded Video Media')}</span>
                    <span className="px-1.5 py-0.2 rounded text-[9px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                      READY TO PUBLISH
                    </span>
                  </div>
                  {fileSize && (
                    <p className="text-[10px] font-mono text-[#B8ACA3]">
                      Size: <span className="text-[#FFB347] font-semibold">{fileSize}</span> • Format: <span className="uppercase text-[#F5F1EC]">{videoType}</span>
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-2.5 py-1 rounded-lg bg-[#1C100A] hover:bg-[#25150E] border border-[#FF6A00]/20 text-[#F5F1EC] text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Change Video</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleClear}
                    className="px-2.5 py-1 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-[11px] font-medium flex items-center gap-1 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>Remove</span>
                  </button>
                </div>
              </div>
            </div>
          ) : (
            /* Upload / Drag and drop video dropzone */
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-5 text-center transition-all cursor-pointer flex flex-col items-center justify-center gap-2 ${
                isDragging 
                  ? 'border-[#FF6A00] bg-[#FF6A00]/10' 
                  : 'border-[#FF6A00]/25 hover:border-[#FF6A00]/60 bg-[#1C100A] hover:bg-[#25150E]'
              }`}
            >
              <div className="w-10 h-10 rounded-xl bg-[#FF6A00]/15 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347] shadow-md">
                {isProcessing ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <Film className="w-5 h-5" />
                )}
              </div>

              <div>
                <p className="text-xs font-semibold text-[#F5F1EC] flex items-center justify-center gap-1.5">
                  <span>Click to browse File Explorer for Video</span>
                  <span className="text-[#B8ACA3]/60 font-normal">or drag & drop</span>
                </p>
                <p className="text-[10px] text-[#B8ACA3] mt-0.5">
                  MP4, WEBM, MOV, or QuickTime files supported
                </p>
              </div>

              <span className="px-3 py-1 rounded-full bg-[#140C08] border border-[#FF6A00]/30 text-[#F5F1EC] text-[10px] font-mono hover:bg-[#FF6A00] hover:text-[#0D0704] transition-colors">
                Browse Video Media
              </span>
            </div>
          )}
        </div>
      ) : (
        /* Direct Video URL input fallback */
        <div className="space-y-2">
          <div className="relative">
            <LinkIcon className="w-3.5 h-3.5 text-[#B8ACA3] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="url"
              value={value}
              onChange={(e) => onChange(e.target.value)}
              placeholder="https://...mp4, YouTube, or Vimeo link"
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
            />
          </div>

          <div className="flex items-center justify-between gap-3 text-xs flex-wrap">
            <div className="flex items-center gap-3">
              <span className="text-[#B8ACA3] text-[11px]">Format:</span>
              {(['mp4', 'youtube', 'vimeo'] as const).map((t) => (
                <label key={t} className="flex items-center gap-1 text-[#B8ACA3] cursor-pointer text-xs">
                  <input
                    type="radio"
                    name="videoTypeSelect"
                    value={t}
                    checked={videoType === t}
                    onChange={() => onTypeChange(t)}
                    className="text-[#FF6A00] focus:ring-[#FF6A00]"
                  />
                  <span className="uppercase text-[10px] font-mono">{t}</span>
                </label>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <span className="text-[#B8ACA3] text-[11px]">Ratio:</span>
              {(['auto', '9:16', '16:9', '1:1'] as const).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => onAspectRatioChange?.(r)}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all cursor-pointer ${
                    aspectRatio === r
                      ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-bold'
                      : 'bg-[#140C08] hover:bg-[#25150E] text-[#B8ACA3] hover:text-[#F5F1EC] border border-[#FF6A00]/20'
                  }`}
                >
                  {r === 'auto' ? 'Auto' : r}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {error && (
        <p className="text-[11px] text-red-400 flex items-center gap-1">
          <AlertCircle className="w-3 h-3 shrink-0" />
          <span>{error}</span>
        </p>
      )}
    </div>
  );
};
