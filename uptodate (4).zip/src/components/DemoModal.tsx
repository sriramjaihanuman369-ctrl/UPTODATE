import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, PhoneCall, CheckCircle2, MessageSquare, Calendar, Sparkles, ArrowRight, Clock, ShieldCheck, Inbox } from 'lucide-react';
import { PhoneInputWithCountry } from './PhoneInputWithCountry';

export const DemoModal: React.FC = () => {
  const { demoModalOpen, setDemoModalOpen, saveDemoBooking } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [countryMeta, setCountryMeta] = useState<{ countryCode: string; countryName: string }>({
    countryCode: '+44',
    countryName: 'United Kingdom'
  });
  const [preferredService, setPreferredService] = useState('Ai Videos');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  if (!demoModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please provide your full name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }
    const cleanDigits = contactNumber.replace(/[^\d]/g, '');
    if (!contactNumber.trim() || cleanDigits.length < 6) {
      setError('Please provide a valid contact number with your country code.');
      return;
    }

    try {
      setIsSubmitting(true);
      await saveDemoBooking({
        name: name.trim(),
        email: email.trim(),
        contactNumber: contactNumber.trim(),
        countryCode: countryMeta.countryCode,
        countryName: countryMeta.countryName,
        preferredService,
        notes: notes.trim()
      });
      setIsSubmitting(false);
      setSubmitted(true);
    } catch (err: any) {
      console.error('Demo booking error:', err);
      setIsSubmitting(false);
      setError('Could not save your booking right now. Please call us directly at 962511181.');
    }
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setContactNumber('');
    setNotes('');
    setSubmitted(false);
    setError('');
    setDemoModalOpen(false);
  };

  return (
    <div 
      id="demo-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleReset();
      }}
    >
      <div 
        id="demo-modal-dialog"
        className="relative w-full max-w-xl bg-[#140C08] border border-[#FF6A00]/30 rounded-3xl p-6 sm:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(255,106,0,0.18)] overflow-hidden max-h-[92vh] overflow-y-auto"
      >
        {/* Ambient background molten orange glow */}
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-[#FF6A00]/15 rounded-full blur-3xl pointer-events-none"></div>

        {/* Close Button */}
        <button
          id="close-demo-modal"
          onClick={handleReset}
          className="absolute top-5 right-5 p-2 rounded-full text-[#B8ACA3] hover:text-[#F5F1EC] bg-[#1B110B] hover:bg-[#251710] border border-[#FF6A00]/25 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div id="demo-confirmation-view" className="text-center py-6 space-y-6">
            <div className="w-20 h-20 mx-auto rounded-full bg-[#FF6A00]/20 border border-[#FF6A00] flex items-center justify-center text-[#FFB347]">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div className="space-y-2">
              <span className="yellow-pill">Booking Saved to Database</span>
              <h3 className="font-display text-2xl sm:text-3xl font-extrabold text-[#F5F1EC] uppercase tracking-wider">
                Demo Call Booked Successfully!
              </h3>
              <p className="text-sm text-[#B8ACA3] max-w-md mx-auto leading-relaxed">
                Thank you <span className="text-[#FFB347] font-bold">{name}</span>. Your request is registered. We will call you directly at <span className="font-mono text-white font-bold">{contactNumber}</span> ({countryMeta.countryName}).
              </p>
            </div>

            {/* Automatic Email Notification Banner */}
            <div className="p-4 rounded-2xl bg-[#1B110B] border border-[#FF6A00]/30 text-left space-y-2.5 max-w-lg mx-auto">
              <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#FFB347] uppercase tracking-wider">
                <Inbox className="w-4 h-4" />
                <span>Instant Lead & Client Confirmation Dispatched</span>
              </div>
              <p className="text-xs text-[#B8ACA3] leading-relaxed">
                Full booking information including your international phone number has been dispatched directly to the studio directors (<span className="text-white font-mono font-semibold">sriramjaihanuman369@gmail.com</span> & <span className="text-white font-mono font-semibold">jasminnmayl@gmail.com</span>).
              </p>
              <div className="p-3 rounded-xl bg-black/40 border border-[#FF6A00]/20 text-xs space-y-1.5">
                <div className="text-[11px] font-mono uppercase tracking-wider text-[#FFB347] font-bold">Confirmation Sent to Your Email:</div>
                <div className="text-zinc-200 font-medium">Subject: <span className="text-[#F5F1EC] font-bold">We’ve Received Your Inquiry — UptoDate</span></div>
                <div className="text-[#B8ACA3] text-[11px] leading-relaxed italic">
                  "Hi {name}, Thank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps..."
                </div>
              </div>
            </div>

            {/* Direct Instant Action Box */}
            <div className="p-4 rounded-2xl bg-[#180E09] border border-[#FF6A00]/30 text-left flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="text-xs text-[#FFB347] uppercase font-mono tracking-wider font-bold">
                  Direct Founder Line
                </p>
                <p className="text-sm text-[#F5F1EC] font-bold">
                  Phone: <a href="tel:962511181" className="text-[#FFB347] font-mono hover:underline">962511181</a>
                </p>
                <p className="text-xs text-[#B8ACA3]">
                  Email: <span className="text-zinc-200">jasminnmayl@gmail.com</span>
                </p>
              </div>
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <a
                  href="tel:962511181"
                  id="direct-call-link"
                  className="yellow-btn flex-1 sm:flex-initial px-4 py-2 rounded-xl text-xs font-black text-[#0D0704] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <PhoneCall className="w-3.5 h-3.5" />
                  <span>Call 962511181</span>
                </a>
                <a
                  href="https://wa.me/91962511181?text=Hi%20UPTODATE,%20I%20just%20booked%20a%20free%20demo%20call!"
                  target="_blank"
                  rel="noopener noreferrer"
                  id="whatsapp-confirm-link"
                  className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-[#25D366] hover:bg-[#20bd5a] text-xs font-bold text-black flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>WhatsApp</span>
                </a>
              </div>
            </div>

            <button
              id="confirm-done-btn"
              onClick={handleReset}
              className="px-8 py-3 rounded-full bg-[#1B110B] hover:bg-[#251710] border border-[#FF6A00]/30 text-sm font-bold text-[#F5F1EC] transition-colors cursor-pointer"
            >
              Back to UPTODATE
            </button>
          </div>
        ) : (
          <div>
            {/* Header */}
            <div className="mb-6 space-y-2">
              <div className="flex items-center gap-2">
                <span className="yellow-pill">Free Strategy Consultation</span>
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-[#F5F1EC] uppercase tracking-wider">
                Book Your Free Demo
              </h2>
              <p className="text-xs sm:text-sm text-[#B8ACA3]">
                Discuss your AI video campaign, digital marketing, website, or rebrand. Direct line: <a href="tel:962511181" className="text-[#FFB347] font-bold font-mono hover:underline">962511181</a>.
              </p>
            </div>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name */}
              <div>
                <label className="block text-xs font-bold text-[#F5F1EC] mb-1.5 uppercase tracking-wider" htmlFor="demo-name">
                  Full Name <span className="text-[#FF6A00]">*</span>
                </label>
                <input
                  id="demo-name"
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Alex Morgan"
                  className="w-full px-4 py-3 rounded-xl bg-[#1B110B] border border-[#FF6A00]/25 text-[#F5F1EC] placeholder-zinc-500 text-sm focus:outline-none focus:border-[#FF6A00] transition-colors"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-bold text-[#F5F1EC] mb-1.5 uppercase tracking-wider" htmlFor="demo-email">
                  Work / Personal Email <span className="text-[#FF6A00]">*</span>
                </label>
                <input
                  id="demo-email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="alex@company.com"
                  className="w-full px-4 py-3 rounded-xl bg-[#1B110B] border border-[#FF6A00]/25 text-[#F5F1EC] placeholder-zinc-500 text-sm focus:outline-none focus:border-[#FF6A00] transition-colors"
                />
              </div>

              {/* Contact Number with Country Code */}
              <div>
                <PhoneInputWithCountry
                  idPrefix="demo"
                  label="Contact Number (WhatsApp / Mobile)"
                  required
                  defaultCountryCode="GB"
                  value={contactNumber}
                  onChange={(val, meta) => {
                    setContactNumber(val);
                    setCountryMeta({ countryCode: meta.country.dialCode, countryName: meta.country.name });
                  }}
                />
              </div>

              {/* Preferred Service */}
              <div>
                <label className="block text-xs font-bold text-[#F5F1EC] mb-1.5 uppercase tracking-wider">
                  Interested Service Focus
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {['Ai Videos', 'Website Design', 'Website Development', 'Branding'].map((srv) => (
                    <button
                      key={srv}
                      type="button"
                      id={`demo-srv-${srv.toLowerCase().replace(/\s+/g, '-')}`}
                      onClick={() => setPreferredService(srv)}
                      className={`px-3 py-2.5 rounded-xl text-xs font-bold transition-all text-center cursor-pointer ${
                        preferredService === srv
                          ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-extrabold shadow-md'
                          : 'bg-[#1B110B] border border-[#FF6A00]/20 text-[#B8ACA3] hover:text-[#F5F1EC] hover:border-[#FF6A00]/50'
                      }`}
                    >
                      {srv}
                    </button>
                  ))}
                </div>
              </div>

              {/* Message / Brief */}
              <div>
                <label className="block text-xs font-bold text-[#F5F1EC] mb-1.5 uppercase tracking-wider" htmlFor="demo-notes">
                  Project Brief or Goal (Optional)
                </label>
                <textarea
                  id="demo-notes"
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Tell us about your brand timeline or vision..."
                  className="w-full px-4 py-2.5 rounded-xl bg-[#1B110B] border border-[#FF6A00]/25 text-[#F5F1EC] placeholder-zinc-500 text-xs focus:outline-none focus:border-[#FF6A00] transition-colors resize-none"
                />
              </div>

              {/* Submit & Call */}
              <div className="pt-2">
                <button
                  id="submit-demo-call-btn"
                  type="submit"
                  disabled={isSubmitting}
                  className="yellow-btn w-full py-3.5 rounded-xl text-[#0D0704] font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <PhoneCall className="w-4 h-4" />
                      <span>Book a Call (Direct: 962511181)</span>
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </>
                  )}
                </button>
              </div>

              {/* Assurance footnote */}
              <div className="flex items-center justify-center gap-4 pt-1 text-[11px] text-[#B8ACA3] font-medium">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-[#FFB347]" /> Response in &lt;15 mins
                </span>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-[#FFB347]" /> Saved to database
                </span>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};
