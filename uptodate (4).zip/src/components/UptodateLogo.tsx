import React from 'react';

interface LogoProps {
  variant?: 'full' | 'mark-only';
  theme?: 'white' | 'yellow' | 'black';
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}

/**
 * UPTODATE official brand logo component
 * Generated directly from WhatsApp Image 2026-09-21 at 19.32.06.jpeg & 19.32.07.jpeg
 * Exact geometric 'U' with overhead dot icon mark + geometric spaced wordmark
 */
export const UptodateLogo: React.FC<LogoProps> = ({
  variant = 'full',
  theme = 'white',
  className = '',
  size = 'md'
}) => {
  const markColor = theme === 'yellow' ? '#FFE600' : theme === 'black' ? '#000000' : '#FFFFFF';
  const textColor = theme === 'yellow' ? '#FFE600' : theme === 'black' ? '#000000' : '#FFFFFF';

  const sizeClasses = {
    sm: { icon: 'w-6 h-7', text: 'text-sm tracking-[0.22em]' },
    md: { icon: 'w-8 h-9', text: 'text-lg tracking-[0.24em]' },
    lg: { icon: 'w-10 h-11', text: 'text-2xl tracking-[0.26em]' },
    xl: { icon: 'w-14 h-16', text: 'text-4xl tracking-[0.28em]' }
  }[size];

  return (
    <div className={`inline-flex items-center gap-3 select-none ${className}`}>
      {/* Signature U-Mark with Top Dot (Exact match to WhatsApp Image 2026-09-21 at 19.32.07.jpeg) */}
      <svg
        className={`${sizeClasses.icon} shrink-0 transition-transform duration-200 group-hover:scale-105`}
        viewBox="0 0 100 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="UPTODATE Mark"
      >
        {/* Overhead Circle Dot */}
        <circle cx="50" cy="20" r="14" fill={markColor} />
        
        {/* Geometric Horseshoe 'U' */}
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M8 40H33V76C33 85.3888 40.6112 93 50 93C59.3888 93 67 85.3888 67 76V40H92V76C92 99.196 73.196 118 50 118C26.804 118 8 99.196 8 76V40Z"
          fill={markColor}
        />
      </svg>

      {/* Wordmark (Exact match to WhatsApp Image 2026-09-21 at 19.32.06.jpeg) */}
      {variant === 'full' && (
        <span 
          className={`font-sans uppercase font-medium leading-none ${sizeClasses.text}`}
          style={{ color: textColor }}
        >
          UPTODATE
        </span>
      )}
    </div>
  );
};
