import React from 'react';
import { motion, useScroll, useSpring } from 'motion/react';

export const ScrollProgressBar: React.FC = () => {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 200,
    damping: 30,
    restDelta: 0.001
  });

  return (
    <div className="fixed top-0 left-0 right-0 h-1 z-[100] pointer-events-none">
      {/* Ambient background track */}
      <div className="w-full h-full bg-black/20 backdrop-blur-sm" />
      {/* Animated glow progress bar */}
      <motion.div
        className="absolute top-0 left-0 right-0 h-full bg-gradient-to-r from-[#FF6A00] via-[#FF851A] to-[#FFB347] origin-left shadow-[0_0_12px_rgba(255,106,0,0.85)]"
        style={{ scaleX }}
      />
    </div>
  );
};
