import React, { useState, useEffect, useRef, useMemo } from 'react';
import { ChevronDown, Search, Check, Globe } from 'lucide-react';
import { COUNTRIES, Country } from '../data/countries';

export interface PhoneInputMeta {
  country: Country;
  localNumber: string;
  fullNumber: string;
}

interface PhoneInputWithCountryProps {
  idPrefix: string;
  value: string;
  onChange: (fullNumber: string, meta: PhoneInputMeta) => void;
  defaultCountryCode?: string;
  required?: boolean;
  disabled?: boolean;
  className?: string;
  label?: string;
}

export const PhoneInputWithCountry: React.FC<PhoneInputWithCountryProps> = ({
  idPrefix,
  value,
  onChange,
  defaultCountryCode = 'GB', // Defaults to UK as explicitly requested: "UK WALE BHI LOGIN AND CONTACT DETAILS ADD KR SAKE"
  required = false,
  disabled = false,
  className = '',
  label
}) => {
  // Find initial country from defaultCountryCode or value
  const initialCountry = useMemo(() => {
    if (value && value.startsWith('+')) {
      // Find matching country by dialCode
      const matched = COUNTRIES.find(c => value.startsWith(c.dialCode));
      if (matched) return matched;
    }
    const found = COUNTRIES.find(c => c.code.toUpperCase() === defaultCountryCode.toUpperCase());
    return found || COUNTRIES[0];
  }, []);

  const [selectedCountry, setSelectedCountry] = useState<Country>(initialCountry);
  const [localNumber, setLocalNumber] = useState<string>(() => {
    if (value && value.startsWith(selectedCountry.dialCode)) {
      return value.slice(selectedCountry.dialCode.length).trim();
    }
    return value ? value.replace(/^\+\d+\s*/, '') : '';
  });

  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const phoneInputRef = useRef<HTMLInputElement>(null);

  // Sync if external value resets to empty
  useEffect(() => {
    if (!value) {
      setLocalNumber('');
    }
  }, [value]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      // Auto-focus search input
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 50);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  // Filter countries by search query
  const filteredCountries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return COUNTRIES;
    return COUNTRIES.filter(c => 
      c.name.toLowerCase().includes(q) ||
      c.code.toLowerCase().includes(q) ||
      c.dialCode.includes(q) ||
      c.dialCode.replace('+', '').includes(q)
    );
  }, [searchQuery]);

  // Handle local number change
  const handleNumberChange = (rawText: string) => {
    // If user pastes full international number starting with +, try auto-detecting country
    if (rawText.startsWith('+')) {
      const match = COUNTRIES.find(c => rawText.startsWith(c.dialCode));
      if (match) {
        setSelectedCountry(match);
        const rest = rawText.slice(match.dialCode.length).trim();
        setLocalNumber(rest);
        const full = `${match.dialCode} ${rest}`.trim();
        onChange(full, { country: match, localNumber: rest, fullNumber: full });
        return;
      }
    }

    // Clean number (allow digits, spaces, hyphens, parenthesis)
    const cleaned = rawText.replace(/[^\d\s\-()]/g, '');
    setLocalNumber(cleaned);
    const full = cleaned.trim() ? `${selectedCountry.dialCode} ${cleaned.trim()}` : '';
    onChange(full, { country: selectedCountry, localNumber: cleaned, fullNumber: full });
  };

  // Select country from dropdown
  const handleSelectCountry = (country: Country) => {
    setSelectedCountry(country);
    setIsOpen(false);
    setSearchQuery('');
    const full = localNumber.trim() ? `${country.dialCode} ${localNumber.trim()}` : '';
    onChange(full, { country, localNumber, fullNumber: full });
    phoneInputRef.current?.focus();
  };

  const quickPicks = [
    { code: 'GB', label: 'UK +44', flag: '🇬🇧' },
    { code: 'IN', label: 'India +91', flag: '🇮🇳' },
    { code: 'US', label: 'US +1', flag: '🇺🇸' },
    { code: 'AE', label: 'UAE +971', flag: '🇦🇪' },
    { code: 'CA', label: 'Canada +1', flag: '🇨🇦' },
    { code: 'AU', label: 'Australia +61', flag: '🇦🇺' }
  ];

  return (
    <div className={`relative ${className}`}>
      {label && (
        <label 
          htmlFor={`${idPrefix}-phone-input`}
          className="block text-xs font-medium text-zinc-300 mb-1.5"
        >
          {label} {required && <span className="text-amber-500">*</span>}
        </label>
      )}

      {/* Main Input Group */}
      <div className="relative flex items-stretch rounded-xl bg-[#161822] border border-white/10 focus-within:border-amber-500/70 transition-colors shadow-inner">
        
        {/* Country Picker Trigger Button */}
        <button
          type="button"
          id={`${idPrefix}-country-btn`}
          disabled={disabled}
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center gap-1.5 px-3.5 py-3 rounded-l-xl bg-white/[0.04] hover:bg-white/[0.08] border-r border-white/10 text-white transition-colors cursor-pointer select-none text-xs font-medium shrink-0 group"
          title={`Selected: ${selectedCountry.name} (${selectedCountry.dialCode})`}
          aria-haspopup="listbox"
          aria-expanded={isOpen}
        >
          <span className="text-base leading-none" role="img" aria-label={selectedCountry.name}>
            {selectedCountry.flag}
          </span>
          <span className="font-mono font-bold text-amber-400 group-hover:text-amber-300">
            {selectedCountry.dialCode}
          </span>
          <ChevronDown className={`w-3.5 h-3.5 text-zinc-400 group-hover:text-white transition-transform ${isOpen ? 'rotate-180' : ''}`} />
        </button>

        {/* Local Number Input */}
        <input
          ref={phoneInputRef}
          id={`${idPrefix}-phone-input`}
          type="tel"
          required={required}
          disabled={disabled}
          value={localNumber}
          onChange={(e) => handleNumberChange(e.target.value)}
          placeholder={selectedCountry.format || 'Enter phone number'}
          className="w-full px-4 py-3 rounded-r-xl bg-transparent text-white placeholder-zinc-500 text-sm focus:outline-none font-mono"
        />
      </div>

      {/* Helper Country Pill below input */}
      <div className="flex items-center justify-between mt-1 px-1 text-[11px] text-zinc-500">
        <span className="truncate">
          Region: <strong className="text-zinc-300">{selectedCountry.name}</strong> ({selectedCountry.dialCode})
        </span>
        <button
          type="button"
          onClick={() => setIsOpen(true)}
          className="text-amber-500/90 hover:text-amber-400 font-mono font-medium hover:underline text-[10px] shrink-0 ml-2 cursor-pointer"
        >
          Change Country
        </button>
      </div>

      {/* Floating Dropdown Popover */}
      {isOpen && (
        <div
          ref={dropdownRef}
          id={`${idPrefix}-country-dropdown`}
          className="absolute z-50 left-0 top-full mt-2 w-full max-w-sm sm:w-80 bg-[#0f1118] border border-amber-500/40 rounded-2xl shadow-2xl overflow-hidden backdrop-blur-xl animate-in fade-in zoom-in-95 duration-150"
        >
          {/* Header & Search */}
          <div className="p-3 border-b border-white/10 bg-[#141620] space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" /> Select Country / Dial Code
              </span>
              <span className="text-[10px] text-zinc-400 font-mono">
                {filteredCountries.length} available
              </span>
            </div>

            {/* Search Bar */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                ref={searchInputRef}
                id={`${idPrefix}-country-search`}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search by country or code (+44, UK, India, US...)"
                className="w-full pl-8 pr-3 py-2 rounded-xl bg-[#0b0c10] border border-white/10 text-white placeholder-zinc-500 text-xs focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Quick Pick Chips */}
            <div className="flex flex-wrap gap-1 pt-1">
              {quickPicks.map(qp => {
                const isSelected = selectedCountry.code === qp.code;
                return (
                  <button
                    key={qp.code}
                    type="button"
                    onClick={() => {
                      const found = COUNTRIES.find(c => c.code === qp.code);
                      if (found) handleSelectCountry(found);
                    }}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold transition-all flex items-center gap-1 ${
                      isSelected
                        ? 'bg-amber-500 text-black shadow'
                        : 'bg-white/5 hover:bg-white/10 text-zinc-300 border border-white/5'
                    }`}
                  >
                    <span>{qp.flag}</span>
                    <span>{qp.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Scrollable Country List */}
          <div className="max-h-60 overflow-y-auto divide-y divide-white/[0.04] py-1 text-xs">
            {filteredCountries.length === 0 ? (
              <div className="py-8 text-center text-zinc-500 text-xs">
                No matching country or dial code found
              </div>
            ) : (
              filteredCountries.map((c) => {
                const isSelected = selectedCountry.code === c.code;
                return (
                  <button
                    key={c.code}
                    type="button"
                    id={`${idPrefix}-country-${c.code.toLowerCase()}`}
                    onClick={() => handleSelectCountry(c)}
                    className={`w-full px-3.5 py-2.5 flex items-center justify-between text-left transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-amber-500/15 text-amber-300 font-semibold'
                        : 'hover:bg-white/5 text-zinc-300 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="text-base leading-none shrink-0" role="img" aria-label={c.name}>
                        {c.flag}
                      </span>
                      <span className="truncate">{c.name}</span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0 ml-2">
                      <span className="font-mono text-[11px] text-amber-400 font-bold">
                        {c.dialCode}
                      </span>
                      {isSelected && (
                        <Check className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>

        </div>
      )}
    </div>
  );
};
