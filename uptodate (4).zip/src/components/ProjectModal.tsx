import React, { useRef, useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { X, ExternalLink, Play, Sparkles, Tag, TrendingUp, Calendar, Trash2, Edit3, Maximize, Minimize, AlertTriangle, RefreshCw } from 'lucide-react';
import { ProjectMediaVideo } from './ProjectMediaVideo';

export const ProjectModal: React.FC = () => {
  const { 
    activeProjectModal, 
    setActiveProjectModal, 
    user, 
    isAdmin, 
    removeProject,
    openEditInAdmin,
    setCurrentPage
  } = useApp();

  const [detectedRatio, setDetectedRatio] = useState<'16:9' | '9:16' | '1:1'>('16:9');
  const [videoDims, setVideoDims] = useState<{ width: number; height: number; realRatio: number } | null>(null);
  const [userOverrideRatio, setUserOverrideRatio] = useState<'16:9' | '9:16' | '1:1' | null>(null);
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [isConfirmingDelete, setIsConfirmingDelete] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  // Sync fullscreen state
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(Boolean(document.fullscreenElement));
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Reset ratios when modal opens/changes
  useEffect(() => {
    if (activeProjectModal) {
      setUserOverrideRatio(null);
      setVideoDims(null);
      if (activeProjectModal.aspectRatio && activeProjectModal.aspectRatio !== 'auto') {
        setDetectedRatio(activeProjectModal.aspectRatio as '16:9' | '9:16' | '1:1');
      } else if (activeProjectModal.videoUrl?.includes('/shorts/')) {
        setDetectedRatio('9:16');
      } else {
        setDetectedRatio('16:9');
      }
    }
  }, [activeProjectModal?.id, activeProjectModal?.aspectRatio, activeProjectModal?.videoUrl]);

  if (!activeProjectModal) return null;

  const project = activeProjectModal;
  const isOwnerOrAdmin = isAdmin;

  const effectiveRatio: '16:9' | '9:16' | '1:1' = userOverrideRatio || (
    project.aspectRatio && project.aspectRatio !== 'auto'
      ? (project.aspectRatio as '16:9' | '9:16' | '1:1')
      : detectedRatio
  );

  const handleRatioDetected = (
    r: '16:9' | '9:16' | '1:1',
    dims?: { width: number; height: number; realRatio: number }
  ) => {
    if (dims) {
      setVideoDims(dims);
    }
    // Only adopt auto-detected ratio if project doesn't have an explicit non-auto setting
    if (!project.aspectRatio || project.aspectRatio === 'auto') {
      setDetectedRatio(r);
    }
  };

  const toggleFullscreen = () => {
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(console.warn);
    } else if (containerRef.current) {
      containerRef.current.requestFullscreen().catch(() => {
        if (videoRef.current) {
          videoRef.current.requestFullscreen().catch(console.warn);
        }
      });
    } else if (videoRef.current) {
      videoRef.current.requestFullscreen().catch(console.warn);
    }
  };

  const handleDelete = () => {
    setIsConfirmingDelete(true);
  };

  const handleConfirmDelete = async () => {
    try {
      setIsDeleting(true);
      await removeProject(project.id);
      setIsDeleting(false);
      setIsConfirmingDelete(false);
      setActiveProjectModal(null);
    } catch (e) {
      console.warn('Delete project error:', e);
      setIsDeleting(false);
    }
  };

  const renderVideoPlayer = () => {
    const activeVideoUrl = project.videoUrl || '';

    if (!activeVideoUrl) {
      return (
        <div className="relative mx-auto rounded-2xl overflow-hidden bg-black border border-white/10 shadow-xl w-full aspect-video flex items-center justify-center">
          <img 
            src={project.thumbnail} 
            alt={project.title} 
            className="w-full h-full object-contain bg-black"
          />
        </div>
      );
    }

    if (activeVideoUrl.includes('youtube.com') || activeVideoUrl.includes('youtu.be')) {
      const getYouTubeId = (url: string) => {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|shorts\/)([^#\&\?]*).*/;
        const match = url.match(regExp);
        return (match && match[2].length === 11) ? match[2] : null;
      };
      const videoId = getYouTubeId(activeVideoUrl);
      if (!videoId) {
        return (
          <div className="relative mx-auto rounded-2xl overflow-hidden bg-black border border-white/10 shadow-xl w-full aspect-video">
            <img 
              src={project.thumbnail} 
              alt={project.title} 
              className="w-full h-full object-contain bg-black"
            />
          </div>
        );
      }
      const isShorts = activeVideoUrl.includes('/shorts/') || effectiveRatio === '9:16';

      return (
        <div ref={containerRef} className="video-ratio-lock-container relative w-full flex justify-center bg-black rounded-2xl overflow-hidden">
          <div className={`relative overflow-hidden bg-black border border-white/10 shadow-2xl transition-all duration-300 ${
            isShorts 
              ? 'w-full max-w-[340px] sm:max-w-[380px] aspect-[9/16] rounded-3xl border-amber-500/30' 
              : effectiveRatio === '1:1'
                ? 'w-full max-w-lg aspect-square rounded-2xl'
                : 'w-full aspect-video rounded-2xl'
          }`}>
            <iframe
              src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`}
              title={project.title}
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
              allowFullScreen
              className="w-full h-full border-0"
            />
          </div>
        </div>
      );
    }

    if (activeVideoUrl.includes('vimeo.com')) {
      const match = activeVideoUrl.match(/vimeo\.com\/(\d+)/);
      const vimeoId = match ? match[1] : '';
      if (!vimeoId) {
        return (
          <div className="relative mx-auto rounded-2xl overflow-hidden bg-black border border-white/10 shadow-xl w-full aspect-video">
            <img 
              src={project.thumbnail} 
              alt={project.title} 
              className="w-full h-full object-contain bg-black"
            />
          </div>
        );
      }
      return (
        <div ref={containerRef} className="video-ratio-lock-container relative w-full flex justify-center bg-black rounded-2xl overflow-hidden">
          <div className={`relative overflow-hidden bg-black border border-white/10 shadow-2xl transition-all duration-300 ${
            effectiveRatio === '9:16'
              ? 'w-full max-w-[340px] sm:max-w-[380px] aspect-[9/16] rounded-3xl border-amber-500/30'
              : effectiveRatio === '1:1'
                ? 'w-full max-w-lg aspect-square rounded-2xl'
                : 'w-full aspect-video rounded-2xl'
          }`}>
            <iframe
              src={`https://player.vimeo.com/video/${vimeoId}?autoplay=1&title=0&byline=0&portrait=0`}
              title={project.title}
              allow="autoplay; fullscreen; picture-in-picture"
              allowFullScreen
              className="w-full h-full border-0"
            />
          </div>
        </div>
      );
    }

    // Direct MP4 / Uploaded video player presented in its TRUE REAL RATIO
    const realRatio = videoDims
      ? videoDims.realRatio
      : (effectiveRatio === '9:16' ? 9 / 16 : effectiveRatio === '1:1' ? 1 : 16 / 9);
    const isPortrait = realRatio < 0.95;

    return (
      <div 
        ref={containerRef}
        className="video-ratio-lock-container relative w-full flex items-center justify-center py-2 bg-black rounded-2xl overflow-hidden shadow-2xl border border-white/10"
        style={{ minHeight: '280px', maxHeight: '76vh' }}
      >
        <div 
          className="relative flex items-center justify-center transition-all duration-300 w-full overflow-hidden rounded-2xl bg-black"
          style={{
            aspectRatio: videoDims ? `${videoDims.width} / ${videoDims.height}` : (isPortrait ? '9 / 16' : realRatio === 1 ? '1 / 1' : '16 / 9'),
            maxHeight: '76vh',
            maxWidth: isPortrait ? `min(100%, calc(76vh * ${realRatio}))` : '100%',
          }}
        >
          <ProjectMediaVideo 
            ref={videoRef}
            videoUrl={activeVideoUrl} 
            controls 
            autoPlay 
            playsInline
            poster={project.thumbnail}
            onRatioDetected={handleRatioDetected}
            className="w-full h-full object-contain bg-black"
          />

          {/* Fullscreen Button */}
          <button
            type="button"
            onClick={toggleFullscreen}
            title="Toggle Fullscreen"
            className="absolute top-3.5 right-3.5 z-20 p-2 rounded-full bg-black/70 hover:bg-black/90 text-white/80 hover:text-amber-400 border border-white/10 hover:border-amber-500/40 backdrop-blur-md transition-all cursor-pointer shadow-lg"
            aria-label="Toggle Fullscreen"
          >
            {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </button>
        </div>
      </div>
    );
  };


  return (
    <div 
      id="project-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) setActiveProjectModal(null);
      }}
    >
      <div 
        id="project-modal-dialog"
        className="relative w-full max-w-4xl bg-[#140C08] border border-[#FF6A00]/30 rounded-3xl p-6 sm:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(255,106,0,0.18)] max-h-[90vh] overflow-y-auto"
      >
        <button
          id="close-project-modal"
          onClick={() => setActiveProjectModal(null)}
          className="absolute top-5 right-5 z-20 p-2 rounded-full text-[#B8ACA3] hover:text-[#F5F1EC] bg-[#1B110B] hover:bg-[#251710] border border-[#FF6A00]/25 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Video / Media Player Section */}
        <div className="mb-6 space-y-2">
          {renderVideoPlayer()}
          {project.videoUrl && (
            <div className="flex items-center justify-between px-2 pt-1 text-xs text-[#B8ACA3]">
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] text-[#B8ACA3]">Playback Format:</span>
                <span className="text-[10px] font-mono text-[#FFB347] font-semibold uppercase">
                  {effectiveRatio === '9:16' ? '📱 9:16 Reel' : effectiveRatio === '1:1' ? '⏹️ 1:1 Square' : '🖥️ 16:9 Widescreen'}
                </span>
              </div>
              <div className="flex items-center gap-1">
                {(['9:16', '16:9', '1:1'] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setUserOverrideRatio(r)}
                    className={`px-2 py-0.5 rounded text-[10px] font-mono transition-all cursor-pointer ${
                      effectiveRatio === r
                        ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-bold shadow-sm'
                        : 'bg-[#180E09] hover:bg-[#22140D] text-[#B8ACA3] hover:text-[#F5F1EC] border border-[#FF6A00]/20'
                    }`}
                  >
                    {r === '9:16' ? '9:16 Reel' : r === '16:9' ? '16:9 Widescreen' : '1:1'}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Title, Category & Meta */}
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full text-[11px] font-mono font-bold uppercase tracking-wider bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/30">
                {project.category}
              </span>
              {project.featured && (
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-[#180E09] text-[#B8ACA3] border border-[#FF6A00]/25">
                  Featured Case Study
                </span>
              )}
            </div>
            <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#F5F1EC] tracking-tight">
              {project.title}
            </h2>
          </div>

          <div className="flex items-center gap-2 flex-wrap shrink-0">
            {/* Website Link if available */}
            {project.websiteUrl && (
              <a
                href={project.websiteUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="view-live-project-link"
                className="yellow-btn px-4 py-2.5 rounded-xl text-xs font-black text-[#0D0704] flex items-center gap-1.5 shrink-0 uppercase tracking-wider shadow-md cursor-pointer"
              >
                <span>Visit Live Project</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            )}
          </div>
        </div>

        {/* Results Highlight Banner */}
        {project.results && (
          <div className="mb-6 p-4 rounded-2xl bg-[#180E09] border border-[#FF6A00]/30 flex items-center gap-3">
            <div className="p-2 rounded-xl bg-[#FF6A00]/20 text-[#FFB347] shrink-0">
              <TrendingUp className="w-5 h-5" />
            </div>
            <div>
              <p className="text-[10px] uppercase font-mono tracking-widest text-[#FFB347] font-bold">
                Measurable Campaign Performance
              </p>
              <p className="text-sm font-bold text-[#F5F1EC]">
                {project.results}
              </p>
            </div>
          </div>
        )}

        {/* Description */}
        <div className="mb-6">
          <h4 className="text-xs uppercase font-mono tracking-wider text-[#FFB347] mb-2 font-semibold">
            Project Overview & Strategy
          </h4>
          <p className="text-[#B8ACA3] text-sm leading-relaxed whitespace-pre-line">
            {project.description}
          </p>
        </div>

        {/* Tags */}
        {project.tags && project.tags.length > 0 && (
          <div className="mb-6">
            <h4 className="text-xs uppercase font-mono tracking-wider text-[#FFB347] mb-2 font-semibold">
              Keywords & Deliverables
            </h4>
            <div className="flex flex-wrap gap-2">
              {project.tags.map((tag, i) => (
                <span 
                  key={i} 
                  className="px-3 py-1 rounded-lg bg-[#180E09] border border-[#FF6A00]/20 text-xs text-[#B8ACA3] font-mono"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Gallery Images */}
        {project.galleryImages && project.galleryImages.length > 0 && (
          <div className="mb-6">
            <h4 className="text-xs uppercase font-mono tracking-wider text-[#FFB347] mb-2 font-semibold">
              Project Visual Stills & Frames
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {project.galleryImages.map((imgUrl, i) => (
                <div key={i} className="aspect-video rounded-xl overflow-hidden bg-black/40 border border-[#FF6A00]/25">
                  <img 
                    src={imgUrl} 
                    alt={`Frame ${i + 1}`} 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300" 
                  />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Admin/Owner controls */}
        {isOwnerOrAdmin && (
          <div className="mt-8 pt-4 border-t border-[#FF6A00]/20 flex items-center justify-between">
            <div className="text-xs text-[#B8ACA3]">
              Created by: <span className="text-[#F5F1EC]">{project.authorEmail || 'Admin'}</span>
            </div>
            <div className="flex items-center gap-3">
              <button
                id="edit-project-shortcut-btn"
                onClick={() => openEditInAdmin(project)}
                className="px-4 py-2 rounded-xl bg-[#1B110B] hover:bg-[#251710] border border-[#FF6A00]/25 text-xs font-semibold text-[#F5F1EC] flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5 text-[#FFB347]" />
                <span>Edit in Dashboard</span>
              </button>
              <button
                id="delete-project-modal-btn"
                onClick={handleDelete}
                className="px-4 py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-xs font-semibold text-red-400 flex items-center gap-1.5 transition-colors border border-red-500/25 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Project</span>
              </button>
            </div>
          </div>
        )}

        {/* Delete Confirmation Modal */}
        {isConfirmingDelete && (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
            onClick={(e) => {
              e.stopPropagation();
              if (!isDeleting) setIsConfirmingDelete(false);
            }}
          >
            <div 
              className="relative w-full max-w-md bg-[#140C08] border border-red-500/40 rounded-3xl p-6 sm:p-8 space-y-5 shadow-[0_20px_60px_rgba(0,0,0,0.95)]"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="w-14 h-14 rounded-2xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
                <AlertTriangle className="w-7 h-7" />
              </div>

              <div className="text-center space-y-2">
                <h3 className="font-heading text-xl font-bold text-[#F5F1EC]">
                  Delete Project?
                </h3>
                <p className="text-xs text-[#B8ACA3] leading-relaxed">
                  Are you sure you want to delete <strong className="text-[#F5F1EC]">"{project.title}"</strong>? This will remove it from the public portfolio.
                </p>
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={() => setIsConfirmingDelete(false)}
                  className="flex-1 py-3 rounded-xl bg-[#1C100A] hover:bg-[#25150E] border border-white/10 text-xs font-semibold text-[#B8ACA3] hover:text-[#F5F1EC] cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  disabled={isDeleting}
                  onClick={handleConfirmDelete}
                  className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg"
                >
                  {isDeleting ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      <span>Deleting...</span>
                    </>
                  ) : (
                    <>
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
