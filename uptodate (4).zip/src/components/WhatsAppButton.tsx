import React from 'react';
import { MessageSquare } from 'lucide-react';

export const WhatsAppButton: React.FC = () => {
  return (
    <aside aria-label="Quick contact" className="contents">
      <a
        id="sticky-whatsapp-btn"
        href="https://wa.me/91962511181?text=Hi%20UPTODATE,%20I'd%20like%20to%20discuss%20an%20AI%20video%20or%20website%20project!"
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with UPTODATE on WhatsApp (962511181)"
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2.5 px-4 py-3 bg-[#25D366] hover:bg-[#20bd5a] text-black font-bold text-xs rounded-full shadow-[0_4px_25px_rgba(37,211,102,0.45)] hover:shadow-[0_6px_30px_rgba(37,211,102,0.65)] hover:scale-105 transition-all duration-300 group cursor-pointer"
      >
        <MessageSquare className="w-5 h-5 fill-current text-black group-hover:rotate-12 transition-transform" />
        <span className="hidden sm:inline font-sans">Chat on WhatsApp</span>
        <span className="text-[10px] font-mono bg-black/15 px-2 py-0.5 rounded-full hidden md:inline">
          962511181
        </span>
      </a>
    </aside>
  );
};
