import React, { useRef, useState, useEffect, useCallback } from 'react';
import { Volume2, VolumeX, Play, Sparkles } from 'lucide-react';
import { Project } from '../types';
import { useMediaUrl } from '../utils/mediaStorage';

interface ProjectCardVideoPreviewProps {
  project: Project;
  isHovered?: boolean;
  aspectRatioClass?: string;
  className?: string;
}

export const ProjectCardVideoPreview: React.FC<ProjectCardVideoPreviewProps> = ({
  project,
  isHovered = false,
  aspectRatioClass,
  className = ''
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const [isMuted, setIsMuted] = useState(true); // Muted by default as per modern browser autoplay requirements
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);
  const [isInViewport, setIsInViewport] = useState(false);

  // Resolve media URL if it was uploaded via IndexedDB (`idb:`) or is a normal URL
  const resolvedVideoUrl = useMediaUrl(project.videoUrl || '');
  const [currentSrc, setCurrentSrc] = useState<string>('');
  const [naturalAspectRatio, setNaturalAspectRatio] = useState<number | null>(null);

  useEffect(() => {
    setCurrentSrc(resolvedVideoUrl || '');
    setHasError(false);
  }, [resolvedVideoUrl]);

  // Determine if it's a YouTube link
  const isYouTube = Boolean(
    currentSrc &&
    (currentSrc.includes('youtube.com') || currentSrc.includes('youtu.be'))
  );

  const getYouTubeId = (url: string) => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|shorts\/)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return match && match[2].length === 11 ? match[2] : null;
  };

  const youTubeId = isYouTube ? getYouTubeId(currentSrc) : null;

  // Determine aspect ratio class with auto-detection support from actual video dimensions
  const isNaturalReel = naturalAspectRatio !== null && naturalAspectRatio < 0.85;
  const isReel = project.aspectRatio === '9:16' || currentSrc.includes('/shorts/') || isNaturalReel;
  const isSquare = project.aspectRatio === '1:1' || (naturalAspectRatio !== null && naturalAspectRatio >= 0.85 && naturalAspectRatio <= 1.15);
  const effectiveAspectClass =
    aspectRatioClass ||
    (isReel ? 'aspect-[9/16] max-h-[520px]' : isSquare ? 'aspect-square' : 'aspect-video');

  // Safely play video
  const playVideo = useCallback(() => {
    const video = videoRef.current;
    if (!video || hasError) return;

    // Browser policy: video MUST have DOM-level muted and playsinline properties
    video.defaultMuted = true;
    video.muted = isMuted;
    video.playsInline = true;

    const promise = video.play();
    if (promise !== undefined) {
      promise
        .then(() => {
          setIsPlaying(true);
        })
        .catch((err) => {
          // If browser prevented unmuted playback, force mute and retry
          if (video) {
            video.muted = true;
            setIsMuted(true);
            video.play()
              .then(() => setIsPlaying(true))
              .catch(() => {
                setIsPlaying(false);
              });
          }
        });
    }
  }, [isMuted, hasError]);

  // Pause video
  const pauseVideo = useCallback(() => {
    const video = videoRef.current;
    if (video) {
      video.pause();
      setIsPlaying(false);
    }
  }, []);

  // IntersectionObserver: Auto-play when visible, pause when scrolled out of view
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsInViewport(true);
            playVideo();
          } else {
            setIsInViewport(false);
            pauseVideo();
          }
        });
      },
      {
        threshold: 0.15,
        rootMargin: '100px 0px 100px 0px'
      }
    );

    observer.observe(container);

    return () => {
      observer.disconnect();
    };
  }, [playVideo, pauseVideo]);

  // Sync muted property directly to DOM element
  useEffect(() => {
    const video = videoRef.current;
    if (video) {
      video.defaultMuted = true;
      video.muted = isMuted;
    }
  }, [isMuted]);

  // Tab visibility: pause when tab is hidden, resume when tab is active
  useEffect(() => {
    const handleVisibility = () => {
      if (document.hidden) {
        pauseVideo();
      } else if (isInViewport) {
        playVideo();
      }
    };

    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [isInViewport, playVideo, pauseVideo]);

  // Toggle audio mute directly on the card
  const handleToggleMute = (e: React.MouseEvent) => {
    e.stopPropagation(); // Do not trigger card opening modal
    const video = videoRef.current;
    if (!video) return;

    const newMuted = !isMuted;
    setIsMuted(newMuted);
    video.muted = newMuted;

    if (!newMuted) {
      // Unmuting: ensure volume is up and playing
      video.volume = 1;
      video.play().catch(() => {
        // If browser blocks unmuted playback without prior user interaction, revert to muted
        video.muted = true;
        setIsMuted(true);
      });
    }
  };

  const handleLoadedMetadata = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    const video = e.currentTarget;
    if (video.videoWidth && video.videoHeight) {
      setNaturalAspectRatio(video.videoWidth / video.videoHeight);
    }
  };

  const handleVideoCanPlay = () => {
    setIsLoaded(true);
    setHasError(false);
    playVideo();
  };

  const handleVideoError = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
    const err = e.currentTarget.error;
    if (err && err.code === 1) return; // MEDIA_ERR_ABORTED
    setHasError(true);
    setIsPlaying(false);
  };

  const hasVideoSource = Boolean(currentSrc && !hasError);

  return (
    <div
      ref={containerRef}
      className={`relative w-full bg-[#0D0704] overflow-hidden transition-all duration-300 select-none ${effectiveAspectClass} ${className}`}
    >
      {/* 1. Underlying Thumbnail (always crisp fallback & poster, never hidden) */}
      <img
        src={project.thumbnail}
        alt={project.title}
        loading="lazy"
        onError={(e) => {
          e.currentTarget.onerror = null;
          e.currentTarget.src = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80';
        }}
        className={`w-full h-full object-cover transition-transform duration-700 ${
          isHovered ? 'scale-105' : 'scale-100'
        }`}
      />

      {/* 2. Direct HTML5 Video Player (Auto-Playing, Muted by Default) */}
      {hasVideoSource && !isYouTube && (
        <video
          ref={videoRef}
          src={currentSrc}
          autoPlay
          muted={isMuted}
          loop
          playsInline
          crossOrigin="anonymous"
          preload="metadata"
          onLoadedMetadata={handleLoadedMetadata}
          onCanPlay={handleVideoCanPlay}
          onPlaying={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
          onError={handleVideoError}
          className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 pointer-events-none ${
            isLoaded && isPlaying ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ objectFit: 'cover' }}
        />
      )}

      {/* 3. YouTube Embed Fallback (for YouTube URLs) */}
      {hasVideoSource && isYouTube && youTubeId && (
        <div className="absolute inset-0 w-full h-full pointer-events-none overflow-hidden">
          <iframe
            src={`https://www.youtube-nocookie.com/embed/${youTubeId}?autoplay=1&mute=1&controls=0&loop=1&playlist=${youTubeId}&playsinline=1&modestbranding=1&rel=0`}
            title={project.title}
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            className="w-full h-full border-0 pointer-events-none scale-105"
          />
        </div>
      )}

      {/* 4. Top Overlay Badges */}
      <div className="absolute top-3.5 left-3.5 right-3.5 flex items-center justify-between z-10 pointer-events-none">
        <span className="px-3 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider bg-[#0D0704]/85 backdrop-blur-md text-[#FFB347] border border-[#FF6A00]/30 shadow-md">
          {project.category}
        </span>
        <div className="flex items-center gap-1.5">
          {/* Live Auto-playing indicator badge */}
          {hasVideoSource && isPlaying && (
            <span className="px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase tracking-wider bg-black/80 backdrop-blur-md text-[#FFB347] border border-[#FF6A00]/40 flex items-center gap-1.5 shadow-md">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FF6A00] animate-pulse"></span>
              <span>LIVE</span>
            </span>
          )}
          {isReel && (
            <span className="px-2.5 py-0.5 rounded-full text-[9px] font-mono font-bold uppercase tracking-wider bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] shadow">
              9:16 Reel
            </span>
          )}
          {project.featured && (
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/30">
              Featured
            </span>
          )}
        </div>
      </div>

      {/* 5. Bottom Controls: Mute/Unmute Audio Toggle & Autoplay Hint */}
      {hasVideoSource && !isYouTube && (
        <div className="absolute bottom-3 right-3 z-20 flex items-center gap-2">
          {/* Quick Mute/Unmute Button */}
          <button
            type="button"
            onClick={handleToggleMute}
            aria-label={isMuted ? 'Unmute video audio' : 'Mute video audio'}
            title={isMuted ? 'Click to unmute audio' : 'Click to mute audio'}
            className="group/sound px-2.5 py-1.5 rounded-full bg-[#0D0704]/85 hover:bg-[#0D0704] text-[#FFB347] border border-[#FF6A00]/40 hover:border-[#FF6A00] backdrop-blur-md text-xs font-mono font-semibold flex items-center gap-1.5 transition-all shadow-lg cursor-pointer pointer-events-auto"
          >
            {isMuted ? (
              <>
                <VolumeX className="w-3.5 h-3.5 text-[#FFB347]" />
                <span className="text-[10px] text-[#B8ACA3] group-hover/sound:text-[#F5F1EC] hidden sm:inline">
                  MUTED
                </span>
              </>
            ) : (
              <>
                <Volume2 className="w-3.5 h-3.5 text-[#FF6A00] animate-bounce" />
                <span className="text-[10px] text-[#FF6A00] font-bold">
                  SOUND ON
                </span>
              </>
            )}
          </button>
        </div>
      )}

      {/* 6. Hover Fullscreen / Inspect Overlay Indicator */}
      <div
        className={`absolute inset-0 flex items-center justify-center transition-opacity duration-300 pointer-events-none ${
          isHovered ? 'opacity-100' : 'opacity-0'
        }`}
      >
        <div className="px-4 py-2 rounded-full bg-[#0D0704]/90 border border-[#FF6A00]/60 text-[#FFB347] flex items-center gap-2 shadow-2xl backdrop-blur-md transform scale-95 transition-transform group-hover:scale-100">
          <Play className="w-3.5 h-3.5 fill-current text-[#FF6A00]" />
          <span className="text-xs font-bold text-[#F5F1EC] uppercase tracking-wider font-mono">
            View Case Study
          </span>
        </div>
      </div>
    </div>
  );
};
