import React from 'react';
import { motion, type HTMLMotionProps } from 'motion/react';

interface ScrollRevealProps extends HTMLMotionProps<'div'> {
  children: React.ReactNode;
  animation?: 'fade-up' | 'pop-up' | 'zoom-in' | 'slide-left' | 'slide-right' | 'card-3d';
  delay?: number;
  duration?: number;
  className?: string;
}

export const ScrollReveal: React.FC<ScrollRevealProps> = ({
  children,
  animation = 'fade-up',
  delay = 0,
  duration = 0.6,
  className = '',
  ...props
}) => {
  const getVariants = () => {
    switch (animation) {
      case 'pop-up':
        return {
          initial: { opacity: 0, scale: 0.88, y: 35 },
          whileInView: { opacity: 1, scale: 1, y: 0 }
        };
      case 'card-3d':
        return {
          initial: { opacity: 0, y: 45, rotateX: 10, scale: 0.94 },
          whileInView: { opacity: 1, y: 0, rotateX: 0, scale: 1 }
        };
      case 'zoom-in':
        return {
          initial: { opacity: 0, scale: 0.92 },
          whileInView: { opacity: 1, scale: 1 }
        };
      case 'slide-left':
        return {
          initial: { opacity: 0, x: -40 },
          whileInView: { opacity: 1, x: 0 }
        };
      case 'slide-right':
        return {
          initial: { opacity: 0, x: 40 },
          whileInView: { opacity: 1, x: 0 }
        };
      case 'fade-up':
      default:
        return {
          initial: { opacity: 0, y: 30 },
          whileInView: { opacity: 1, y: 0 }
        };
    }
  };

  const variants = getVariants();

  return (
    <motion.div
      initial={variants.initial}
      whileInView={variants.whileInView}
      viewport={{ once: true, amount: 0.15 }}
      transition={{
        duration,
        delay,
        ease: [0.16, 1, 0.3, 1]
      }}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  );
};
