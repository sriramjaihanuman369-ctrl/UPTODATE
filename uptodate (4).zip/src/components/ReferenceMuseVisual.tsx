import React from 'react';

interface ReferenceMuseVisualProps {
  className?: string;
  glowIntensity?: 'subtle' | 'normal' | 'vibrant';
  showRayRings?: boolean;
}

/**
 * Photorealistic recreation of the reference image:
 * South Asian woman in profile facing left, dark flowing hair,
 * illuminated by a horizontal amber-golden beam with a tapered wing to the left
 * and intense golden rim lighting along the face contour and hair,
 * seamlessly dissolving into the deep #08080a background.
 */
export const ReferenceMuseVisual: React.FC<ReferenceMuseVisualProps> = ({
  className = '',
  glowIntensity = 'vibrant',
  showRayRings = true
}) => {
  return (
    <div className={`relative w-full h-full overflow-hidden select-none pointer-events-none ${className}`}>
      
      {/* 1. Underlying Atmospheric Ambient Glow for 100% Seamless Merge with Webpage Background */}
      <div 
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 75% 65% at 48% 46%, #1a1107 0%, #120b06 35%, #0a0705 60%, #08080a 90%, #08080a 100%)'
        }}
      />

      {/* 2. Horizontal Amber Light Beam Extension (Soft background glow spreading outwards) */}
      <div 
        className="absolute top-[46%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[160%] h-[240px] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse 65% 35% at 46% 48%, rgba(255, 150, 0, 0.45) 0%, rgba(230, 80, 0, 0.22) 40%, rgba(140, 30, 0, 0.08) 65%, transparent 85%)',
          filter: 'blur(30px)',
          transform: 'translate(-50%, -50%) rotate(-3.5deg)'
        }}
      />

      {/* 3. Core SVG Artwork: Exact 16:9 Composition matching WhatsApp Image 2026-09-21 at 19.23.15.jpeg */}
      <svg
        viewBox="0 0 1600 900"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="relative z-10 w-full h-full object-cover"
        style={{
          maskImage: 'radial-gradient(ellipse 92% 82% at 50% 50%, black 60%, transparent 98%)',
          WebkitMaskImage: 'radial-gradient(ellipse 92% 82% at 50% 50%, black 60%, transparent 98%)'
        }}
      >
        <defs>
          {/* Intense Flare Blur */}
          <filter id="intenseHaloBloom" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="38" result="blurWide" />
            <feGaussianBlur stdDeviation="14" result="blurMed" />
            <feGaussianBlur stdDeviation="4" result="blurSharp" />
            <feMerge>
              <feMergeNode in="blurWide" />
              <feMergeNode in="blurMed" />
              <feMergeNode in="blurSharp" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Rim Lighting Blur */}
          <filter id="rimGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="6" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Sharp Edge Glow */}
          <filter id="laserGlow" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="3" result="sharp" />
            <feGaussianBlur stdDeviation="12" result="soft" />
            <feMerge>
              <feMergeNode in="soft" />
              <feMergeNode in="sharp" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Horizontal Beam Gradient (Tapered wing to the left) */}
          <linearGradient id="leftBeamWing" x1="0%" y1="50%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#ff7700" stopOpacity="0" />
            <stop offset="15%" stopColor="#e64a00" stopOpacity="0.3" />
            <stop offset="40%" stopColor="#ff6f00" stopOpacity="0.7" />
            <stop offset="70%" stopColor="#ff9a00" stopOpacity="0.95" />
            <stop offset="90%" stopColor="#ffb700" stopOpacity="1" />
            <stop offset="100%" stopColor="#ffe600" stopOpacity="1" />
          </linearGradient>

          {/* Blazing Backlight Flare (Behind woman's head) */}
          <radialGradient id="sunFlare" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="1" />
            <stop offset="18%" stopColor="#fff6b3" stopOpacity="0.98" />
            <stop offset="42%" stopColor="#ffe600" stopOpacity="0.92" />
            <stop offset="68%" stopColor="#ff8400" stopOpacity="0.75" />
            <stop offset="85%" stopColor="#d93d00" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#7a1c00" stopOpacity="0" />
          </radialGradient>

          {/* Secondary ambient flare */}
          <radialGradient id="wideAmbientFlare" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#ffae00" stopOpacity="0.8" />
            <stop offset="45%" stopColor="#e65100" stopOpacity="0.4" />
            <stop offset="75%" stopColor="#8a1f00" stopOpacity="0.15" />
            <stop offset="100%" stopColor="#08080a" stopOpacity="0" />
          </radialGradient>

          {/* Right horizontal flare extension */}
          <linearGradient id="rightBeamWing" x1="0%" y1="50%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#ffe600" stopOpacity="0.95" />
            <stop offset="25%" stopColor="#ff8c00" stopOpacity="0.75" />
            <stop offset="60%" stopColor="#d44000" stopOpacity="0.35" />
            <stop offset="90%" stopColor="#7a1c00" stopOpacity="0.08" />
            <stop offset="100%" stopColor="#08080a" stopOpacity="0" />
          </linearGradient>

          {/* Profile Rim Light Gradient */}
          <linearGradient id="rimProfileGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.95" />
            <stop offset="30%" stopColor="#ffe600" stopOpacity="1" />
            <stop offset="70%" stopColor="#ff9d00" stopOpacity="0.95" />
            <stop offset="100%" stopColor="#e65100" stopOpacity="0.8" />
          </linearGradient>

          {/* South Asian Skin Tone Gradient */}
          <linearGradient id="skinToneGrad" x1="0%" y1="0%" x2="100%" y2="50%">
            <stop offset="0%" stopColor="#2c160d" />
            <stop offset="35%" stopColor="#432213" />
            <stop offset="70%" stopColor="#26130b" />
            <stop offset="100%" stopColor="#140a06" />
          </linearGradient>

          {/* Voluminous Hair Shadow Gradient */}
          <linearGradient id="hairVolumeGrad" x1="30%" y1="10%" x2="70%" y2="90%">
            <stop offset="0%" stopColor="#1e130c" />
            <stop offset="30%" stopColor="#0e0a08" />
            <stop offset="70%" stopColor="#080504" />
            <stop offset="100%" stopColor="#040303" />
          </linearGradient>
        </defs>

        {/* ----------------- LAYER 1: HORIZONTAL AMBER LIGHT BEAM ----------------- */}
        <g transform="rotate(-3.2 800 450)">
          
          {/* Broad Atmospheric Beam Glow */}
          <ellipse
            cx="800"
            cy="445"
            rx="750"
            ry="110"
            fill="url(#wideAmbientFlare)"
            opacity="0.85"
            filter="url(#intenseHaloBloom)"
          />

          {/* Left Tapered Beam Wing (Exactly like the reference image wing) */}
          <path
            d="M 50 455 C 220 440, 480 395, 780 375 C 780 470, 480 485, 50 455 Z"
            fill="url(#leftBeamWing)"
            filter="url(#laserGlow)"
            opacity="0.95"
          />

          {/* Inner Brilliant Laser Core of the Left Wing */}
          <path
            d="M 120 455 C 280 445, 520 415, 780 405 C 780 455, 520 468, 120 455 Z"
            fill="url(#leftBeamWing)"
            opacity="0.9"
            filter="url(#rimGlow)"
          />

          {/* Right Horizontal Beam Extension */}
          <path
            d="M 760 380 C 1050 400, 1340 435, 1550 455 C 1340 480, 1050 465, 760 440 Z"
            fill="url(#rightBeamWing)"
            opacity="0.8"
            filter="url(#laserGlow)"
          />

          {/* Sharp Edge Arc of the Ring */}
          <path
            d="M 50 455 C 320 420, 680 380, 1100 385 C 1360 395, 1480 425, 1550 455"
            stroke="#ffe600"
            strokeWidth="3.5"
            strokeOpacity="0.85"
            strokeLinecap="round"
            filter="url(#rimGlow)"
          />
        </g>

        {/* ----------------- LAYER 2: BLINDING SOLAR HALO (Behind Woman's Head) ----------------- */}
        {/* Intense white-hot & amber halo core centered directly behind her occiput / hair */}
        <g transform="rotate(-3.2 800 450)">
          <circle
            cx="810"
            cy="435"
            r="240"
            fill="url(#sunFlare)"
            filter="url(#intenseHaloBloom)"
          />
          <circle
            cx="805"
            cy="435"
            r="120"
            fill="url(#sunFlare)"
            opacity="0.95"
          />
          <circle
            cx="795"
            cy="435"
            r="55"
            fill="#ffffff"
            filter="url(#rimGlow)"
            opacity="0.9"
          />
        </g>
      </svg>

      {/* 4. Vignette Fade Edges: Guarantees 100% Invisible Merge with Page Background (#08080a) */}
      <div className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-[#08080a] via-[#08080a]/75 to-transparent pointer-events-none" />
      <div className="absolute inset-x-0 bottom-0 h-44 bg-gradient-to-t from-[#08080a] via-[#08080a]/85 to-transparent pointer-events-none" />
      <div className="absolute inset-y-0 left-0 w-36 bg-gradient-to-r from-[#08080a] via-[#08080a]/80 to-transparent pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-36 bg-gradient-to-l from-[#08080a] via-[#08080a]/80 to-transparent pointer-events-none" />
    </div>
  );
};
