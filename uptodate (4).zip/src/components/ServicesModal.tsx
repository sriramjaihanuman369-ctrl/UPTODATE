import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Video, Megaphone, Globe, Palette, ArrowRight, Sparkles } from 'lucide-react';
import { UptodateLogo } from './UptodateLogo';

export const ServicesModal: React.FC = () => {
  const { servicesModalOpen, setServicesModalOpen, setCurrentPage, setSelectedCategory, setDemoModalOpen } = useApp();

  if (!servicesModalOpen) return null;

  const services = [
    {
      id: 'ai',
      categoryKey: 'ai video',
      title: 'AI CREATIVE',
      icon: Video,
      badge: '48 hrs to 5 days',
      subpoints: [
        { name: 'AI Ad Videos', desc: 'Hyper-realistic synthetic commercials & cinematic product films' },
        { name: 'AI Optimised Content', desc: 'Algorithmically tuned social hooks engineered for viral retention' }
      ]
    },
    {
      id: 'marketing',
      categoryKey: 'digital marketing',
      title: 'DIGITAL MARKETING',
      icon: Megaphone,
      badge: 'High ROAS',
      subpoints: [
        { name: 'Social Media', desc: 'Daily organic and paid short-form video pipelines for TikTok & Reels' },
        { name: 'Influencer Marketing', desc: 'AI-matched creator partnerships with scalable performance models' },
        { name: 'Content Marketing', desc: 'Editorial leadership, interactive assets, and search authority' }
      ]
    },
    {
      id: 'website',
      categoryKey: 'website',
      title: 'WEBSITE',
      icon: Globe,
      badge: '48 hrs to 5 days',
      subpoints: [
        { name: 'Design', desc: 'Award-grade UI/UX design, custom 3D web visuals & kinetic animations' },
        { name: 'Development', desc: 'Ultra-fast Next/React architectures, headless CMS & full-stack API systems' }
      ]
    },
    {
      id: 'branding',
      categoryKey: 'branding',
      title: 'BRANDING',
      icon: Palette,
      badge: 'Full Identity',
      subpoints: [
        { name: 'Logo Design', desc: 'Iconic vector monograms and bespoke logotypes for future tech brands' },
        { name: 'Brand Development', desc: 'Comprehensive visual strategy, color science, and typographic systems' },
        { name: 'Brand Collateral', desc: 'Pitch decks, premium packaging, merch & conversion marketing assets' },
        { name: 'Corporate Identity', desc: 'Cross-platform design systems & enterprise brand compliance guidelines' }
      ]
    }
  ];

  const handleSelectService = (categoryKey: string) => {
    setSelectedCategory(categoryKey);
    setCurrentPage('projects');
    setServicesModalOpen(false);
  };

  const handleGoToFullServices = () => {
    setCurrentPage('services');
    setServicesModalOpen(false);
  };

  return (
    <div 
      id="services-popup-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) setServicesModalOpen(false);
      }}
    >
      <div 
        id="services-popup-dialog"
        className="relative w-full max-w-4xl bg-[#140C08] border border-[#FF6A00]/30 rounded-3xl p-6 sm:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(255,106,0,0.18)] overflow-hidden max-h-[90vh] overflow-y-auto"
      >
        {/* Ambient background molten orange glow */}
        <div className="absolute -top-32 -left-32 w-80 h-80 bg-[#FF6A00]/15 rounded-full blur-3xl pointer-events-none"></div>

        {/* Close Button */}
        <button
          id="close-services-modal"
          onClick={() => setServicesModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-full text-[#B8ACA3] hover:text-[#F5F1EC] bg-[#1B110B] hover:bg-[#251710] border border-[#FF6A00]/25 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-8 space-y-2">
          <div className="flex items-center gap-3">
            <UptodateLogo variant="full" theme="white" size="sm" />
            <span className="yellow-pill">Pillars of Excellence</span>
          </div>
          <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-[#F5F1EC] tracking-wider uppercase">
            Our 4 Core Service Pillars
          </h2>
          <p className="text-sm text-[#B8ACA3] max-w-xl">
            From photorealistic AI commercials to high-converting websites and brand identities, explore how UPTODATE turns ideas into attention magnets.
          </p>
        </div>

        {/* 4 Interactive Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {services.map((srv) => {
            const Icon = srv.icon;
            return (
              <div
                key={srv.id}
                id={`services-card-${srv.id}`}
                className="group relative p-5 rounded-2xl bg-[#180E09] border border-[#FF6A00]/20 hover:border-[#FF6A00]/60 transition-all duration-300 hover:shadow-[0_10px_30px_rgba(0,0,0,0.7),0_0_20px_rgba(255,106,0,0.15)] hover:-translate-y-0.5"
              >
                <div className="flex items-start justify-between gap-3 mb-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2.5 rounded-xl bg-[#FF6A00]/15 border border-[#FF6A00]/30 text-[#FFB347]">
                      <Icon className="w-5 h-5" />
                    </div>
                    <h3 className="font-display font-bold text-lg text-[#F5F1EC] group-hover:text-[#FFB347] transition-colors uppercase tracking-wide">
                      {srv.title}
                    </h3>
                  </div>
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-mono font-bold bg-[#FF6A00]/15 border border-[#FF6A00]/30 text-[#FFB347]">
                    {srv.badge}
                  </span>
                </div>

                {/* Subpoints with description directly to the right */}
                <div className="space-y-2.5 mb-4">
                  {srv.subpoints.map((sub, idx) => (
                    <div key={idx} className="flex items-start gap-2.5 text-xs">
                      <div className="mt-1.5 w-1.5 h-1.5 rounded-full bg-[#FF6A00] shrink-0"></div>
                      <div className="leading-snug">
                        <span className="font-bold text-[#F5F1EC] mr-1.5">{sub.name}:</span>
                        <span className="text-[#B8ACA3]">{sub.desc}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <button
                  id={`view-projects-${srv.id}`}
                  onClick={() => handleSelectService(srv.categoryKey)}
                  className="w-full mt-2 pt-2.5 border-t border-[#FF6A00]/15 flex items-center justify-between text-xs font-bold text-[#FFB347] hover:text-white transition-colors group/btn cursor-pointer"
                >
                  <span>Explore {srv.title} Works</span>
                  <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Footer actions inside modal */}
        <div className="pt-4 border-t border-[#FF6A00]/20 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-[#B8ACA3] font-medium">
            <span className="text-[#FFB347] font-bold">To Know the Price contact us</span> • Custom bespoke scope engineered for your goals.
          </p>
          <div className="flex items-center gap-3 w-full sm:w-auto">
            <button
              id="view-all-services-page"
              onClick={handleGoToFullServices}
              className="flex-1 sm:flex-initial px-5 py-2.5 rounded-xl bg-[#1B110B] hover:bg-[#251710] border border-[#FF6A00]/25 text-xs font-semibold text-[#F5F1EC] transition-colors cursor-pointer"
            >
              Full Details
            </button>
            <button
              id="services-popup-book-call"
              onClick={() => {
                setServicesModalOpen(false);
                setDemoModalOpen(true);
              }}
              className="yellow-btn flex-1 sm:flex-initial px-5 py-2.5 rounded-xl text-xs font-extrabold text-[#0D0704] transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
            >
              Book Free Demo
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
