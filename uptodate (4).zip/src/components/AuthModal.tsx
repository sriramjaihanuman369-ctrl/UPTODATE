import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { X, Lock, Mail, ArrowRight, ShieldCheck } from 'lucide-react';
import { UptodateLogo } from './UptodateLogo';
import { PhoneInputWithCountry } from './PhoneInputWithCountry';

export const AuthModal: React.FC = () => {
  const { 
    authModalOpen, 
    setAuthModalOpen, 
    loginWithEmail, 
    registerWithEmail, 
    loginWithGoogle
  } = useApp();

  const [mode, setMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!authModalOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (mode === 'signin') {
        await loginWithEmail(email, password);
      } else {
        await registerWithEmail(email, password);
      }
      setLoading(false);
    } catch (err: any) {
      console.warn('Auth modal catch:', err);
      setLoading(false);
      const msg = err?.message || '';
      if (msg.includes('6 characters') || err?.code === 'auth/weak-password') {
        setError('Password should be at least 6 characters.');
      } else if (err?.code === 'auth/invalid-credential' || err?.code === 'auth/wrong-password') {
        setError('Invalid email or password. Please try again.');
      } else if (err?.code === 'auth/email-already-in-use') {
        setError('An account with this email already exists. Try signing in.');
      } else {
        setError('Authentication could not proceed. Please check your email and password.');
      }
    }
  };

  const handleGoogleSignIn = async () => {
    setError('');
    setLoading(true);
    try {
      await loginWithGoogle();
      setLoading(false);
    } catch (err: any) {
      console.warn('Google Sign In note:', err);
      setLoading(false);
      setError('Google Sign-in was cancelled or encountered a popup issue.');
    }
  };

  return (
    <div 
      id="auth-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) setAuthModalOpen(false);
      }}
    >
      <div 
        id="auth-modal-dialog"
        className="relative w-full max-w-md bg-[#140C08] border border-[#FF6A00]/30 rounded-3xl p-6 sm:p-8 shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_35px_rgba(255,106,0,0.18)] overflow-hidden"
      >
        {/* Ambient background molten orange glow */}
        <div className="absolute -top-24 -right-24 w-60 h-60 bg-[#FF6A00]/15 rounded-full blur-3xl pointer-events-none"></div>

        <button
          id="close-auth-modal"
          onClick={() => setAuthModalOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-full text-[#B8ACA3] hover:text-[#F5F1EC] bg-[#1B110B] hover:bg-[#251710] border border-[#FF6A00]/25 transition-colors cursor-pointer"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Brand Icon Header */}
        <div className="text-center mb-6">
          <div className="flex justify-center mb-3">
            <UptodateLogo variant="full" theme="white" size="md" />
          </div>
          <h3 className="font-display text-2xl font-bold text-[#F5F1EC] uppercase tracking-wider">
            {mode === 'signin' ? 'Sign In' : 'Create Account'}
          </h3>
          <p className="text-xs text-[#B8ACA3] mt-1">
            {mode === 'signin' 
              ? 'Access creative briefings, client portals, and brand tracking' 
              : 'Sign up to access exclusive project insights and updates'}
          </p>
        </div>

        {/* Tab switch */}
        <div className="flex p-1 bg-[#180E09] rounded-xl mb-5 border border-[#FF6A00]/20">
          <button
            type="button"
            id="tab-signin"
            onClick={() => { setMode('signin'); setError(''); }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              mode === 'signin' 
                ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-extrabold shadow-md' 
                : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            id="tab-signup"
            onClick={() => { setMode('signup'); setError(''); }}
            className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
              mode === 'signup' 
                ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-extrabold shadow-md' 
                : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
            }`}
          >
            Create Account
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs">
            {error}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          <div>
            <label className="block text-xs font-medium text-[#F5F1EC] mb-1" htmlFor="auth-email">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-[#B8ACA3] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="auth-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@company.com or name@company.co.uk"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#1B110B] border border-[#FF6A00]/25 text-[#F5F1EC] placeholder-zinc-500 text-sm focus:outline-none focus:border-[#FF6A00]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-[#F5F1EC] mb-1" htmlFor="auth-password">
              Password
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-[#B8ACA3] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                id="auth-password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#1B110B] border border-[#FF6A00]/25 text-[#F5F1EC] placeholder-zinc-500 text-sm focus:outline-none focus:border-[#FF6A00]"
              />
            </div>
          </div>

          {mode === 'signup' && (
            <div>
              <PhoneInputWithCountry
                idPrefix="auth-signup"
                label="Mobile / WhatsApp Number (Optional)"
                defaultCountryCode="GB"
                value={phone}
                onChange={(val) => setPhone(val)}
              />
            </div>
          )}

          <button
            id="auth-submit-btn"
            type="submit"
            disabled={loading}
            className="yellow-btn w-full py-3 rounded-xl text-[#0D0704] font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 mt-2 shadow-md"
          >
            {loading ? (
              <div className="w-4 h-4 border-2 border-[#0D0704] border-t-transparent rounded-full animate-spin"></div>
            ) : (
              <>
                <span>{mode === 'signin' ? 'Sign In' : 'Create Account'}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="relative my-5">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-[#FF6A00]/15"></div>
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="px-3 bg-[#140C08] text-[#B8ACA3] uppercase tracking-widest font-mono text-[10px]">
              or connect with
            </span>
          </div>
        </div>

        {/* Google Auth */}
        <button
          type="button"
          id="google-auth-btn"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full py-2.5 rounded-xl bg-[#180E09] hover:bg-[#22140D] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs font-semibold flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.66-5.17 3.66-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.26v3.15C3.25 21.36 7.33 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.26C.46 8.16 0 9.94 0 12s.46 3.84 1.26 5.42l4.02-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.25 2.64 1.26 6.58l4.02 3.15c.95-2.83 3.6-4.93 6.72-4.93z"
            />
          </svg>
          <span>Continue with Google</span>
        </button>

        {/* Security Notice */}
        <div className="mt-5 pt-3 border-t border-[#FF6A00]/15 flex items-center justify-center gap-1.5 text-[11px] text-[#B8ACA3]">
          <ShieldCheck className="w-3.5 h-3.5 text-[#FFB347]" />
          <span>Agency Administrator: jasminnmayl@gmail.com</span>
        </div>
      </div>
    </div>
  );
};
