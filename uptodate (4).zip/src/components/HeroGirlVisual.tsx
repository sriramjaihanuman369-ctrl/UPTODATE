import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, ArrowUpRight, Zap, PhoneCall } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { UptodateLogo } from './UptodateLogo';
import { ReferenceMuseVisual } from './ReferenceMuseVisual';

interface HeroGirlVisualProps {
  className?: string;
  variant?: 'full-hero' | 'card' | 'ambient';
  children?: React.ReactNode;
}

export const HeroGirlVisual: React.FC<HeroGirlVisualProps> = ({
  className = '',
  variant = 'full-hero',
  children
}) => {
  const { setDemoModalOpen, setCurrentPage, setSelectedCategory } = useApp();

  if (variant === 'ambient') {
    return (
      <div className={`relative pointer-events-none select-none overflow-hidden ${className}`}>
        <ReferenceMuseVisual />
      </div>
    );
  }

  return (
    <div className={`relative w-full ${className}`}>
      {/* Centerpiece Container with Amber Halo Beam Theme */}
      <div className="relative mx-auto max-w-6xl flex flex-col items-center justify-center">
        
        {/* CENTERPIECE STAGE: Golden Halo Beam Behind Foreground Content */}
        <div className="relative w-full max-w-[780px] sm:max-w-[940px] lg:max-w-[1100px] min-h-[520px] sm:min-h-[580px] lg:min-h-[640px] flex flex-col items-center justify-between mx-auto overflow-visible pt-2 pb-2">
          
          {/* 1. SEAMLESS AMBER & GOLDEN HALO BEAM THEME (Pure light beam & halo glow) */}
          <div className="absolute inset-0 z-0 flex items-center justify-center select-none pointer-events-none">
            <div className="relative w-full h-full flex items-center justify-center">
              <ReferenceMuseVisual />
            </div>
          </div>

          {/* 6. LEFT POPUP: Compact with minimal text with 3D float animation */}
          <motion.div 
            initial={{ opacity: 0, x: -30, scale: 0.9 }}
            animate={{ 
              opacity: 1, 
              x: 0, 
              scale: 1,
              y: [0, -7, 0]
            }}
            transition={{
              opacity: { duration: 0.6, delay: 0.2 },
              x: { duration: 0.6, delay: 0.2 },
              scale: { duration: 0.6, delay: 0.2 },
              y: { repeat: Infinity, duration: 4.5, ease: "easeInOut" }
            }}
            className="hidden sm:block absolute top-[20%] sm:top-[22%] -left-2 sm:-left-6 lg:-left-12 z-20 w-44 sm:w-48 lg:w-52 p-3 sm:p-3.5 rounded-2xl bg-[#140C08]/92 border border-[#FF6A00]/30 hover:border-[#FF6A00] backdrop-blur-xl shadow-[0_15px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(255,106,0,0.18)] transition-all duration-300 hover:scale-[1.05] pointer-events-auto group"
          >
            <div className="flex items-center justify-between gap-1 mb-1.5">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] text-[8px] font-mono font-black tracking-wider uppercase">
                <span className="w-1 h-1 rounded-full bg-[#0D0704] animate-pulse"></span>
                <span>01 / CORE</span>
              </span>
              <ArrowUpRight className="w-3 h-3 text-[#FFB347] opacity-80 group-hover:opacity-100 transition-opacity" />
            </div>

            <h4 className="font-heading font-black text-xs sm:text-sm text-[#F5F1EC] tracking-wide uppercase">
              Full-Cycle Creative
            </h4>

            <p className="text-[10px] text-[#B8ACA3] mt-1 leading-snug">
              AI Ads & 3D Web Systems
            </p>

            <button
              onClick={() => {
                setCurrentPage('services');
                setSelectedCategory('all');
              }}
              className="mt-2.5 w-full py-1.5 rounded-lg text-[10px] font-bold text-[#0D0704] bg-gradient-to-r from-[#FF6A00] to-[#FFB347] hover:brightness-110 transition-all flex items-center justify-center gap-1 cursor-pointer shadow-sm uppercase tracking-wider"
            >
              <span>Explore</span>
              <ArrowUpRight className="w-3 h-3" />
            </button>
          </motion.div>

          {/* 7. RIGHT POPUP: Compact with minimal text with 3D float animation */}
          <motion.div 
            initial={{ opacity: 0, x: 30, scale: 0.9 }}
            animate={{ 
              opacity: 1, 
              x: 0, 
              scale: 1,
              y: [0, 8, 0]
            }}
            transition={{
              opacity: { duration: 0.6, delay: 0.35 },
              x: { duration: 0.6, delay: 0.35 },
              scale: { duration: 0.6, delay: 0.35 },
              y: { repeat: Infinity, duration: 5, ease: "easeInOut" }
            }}
            className="hidden sm:block absolute top-[8%] sm:top-[10%] -right-2 sm:-right-6 lg:-right-12 z-20 w-44 sm:w-48 lg:w-52 p-3 sm:p-3.5 rounded-2xl bg-[#140C08]/92 border border-[#FF6A00]/30 hover:border-[#FF6A00] backdrop-blur-xl shadow-[0_15px_35px_rgba(0,0,0,0.8),0_0_20px_rgba(255,106,0,0.18)] transition-all duration-300 hover:scale-[1.05] pointer-events-auto group"
          >
            <div className="flex items-center justify-between gap-1 mb-1.5">
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#1F140E] text-[#FFB347] border border-[#FF6A00]/40 text-[8px] font-mono font-black tracking-wider uppercase">
                <Zap className="w-2.5 h-2.5 text-[#FFB347]" />
                <span>AI LAB</span>
              </span>
              <span className="text-[9px] font-mono text-[#FFB347] font-bold">48H</span>
            </div>

            <h4 className="font-heading font-black text-xs sm:text-sm text-[#F5F1EC] tracking-wide uppercase">
              Future-Ready Lab
            </h4>

            <p className="text-[10px] text-[#B8ACA3] mt-1 leading-snug">
              Studio-Grade Generative Tech
            </p>

            <button
              onClick={() => setDemoModalOpen(true)}
              className="mt-2.5 w-full py-1.5 rounded-lg text-[10px] font-bold text-[#F5F1EC] bg-[#1F140E] hover:bg-gradient-to-r hover:from-[#FF6A00] hover:to-[#FFB347] hover:text-[#0D0704] border border-[#FF6A00]/30 transition-all flex items-center justify-center gap-1 cursor-pointer uppercase tracking-wider"
            >
              <PhoneCall className="w-2.5 h-2.5" />
              <span>Book Demo</span>
            </button>
          </motion.div>

          {/* 8. FOREGROUND CONTENT: The Search Bar sitting directly in front of the merged background girl image */}
          <div className="relative z-20 w-full mt-auto pt-44 sm:pt-48 pb-3">
            {children}

            {/* Mobile Cards (Rendered cleanly on small screens where floating side popups are hidden) */}
            <div className="grid grid-cols-2 gap-2 mt-4 sm:hidden">
              <button
                onClick={() => {
                  setCurrentPage('services');
                  setSelectedCategory('all');
                }}
                className="p-3 rounded-2xl bg-[#140C08]/95 border border-[#FF6A00]/30 text-left backdrop-blur-xl"
              >
                <span className="text-[8px] font-mono font-black uppercase text-[#FFB347] tracking-wider block">01 / CREATIVE</span>
                <span className="font-heading font-black text-xs text-[#F5F1EC] uppercase block mt-0.5">FULL-CYCLE</span>
                <span className="text-[9px] text-[#B8ACA3] mt-1 block">AI Ads & 3D Web →</span>
              </button>

              <button
                onClick={() => setDemoModalOpen(true)}
                className="p-3 rounded-2xl bg-[#140C08]/95 border border-[#FF6A00]/30 text-left backdrop-blur-xl"
              >
                <span className="text-[8px] font-mono font-black uppercase text-[#FFB347] tracking-wider block">02 / AI LAB</span>
                <span className="font-heading font-black text-xs text-[#F5F1EC] uppercase block mt-0.5">FUTURE-READY</span>
                <span className="text-[9px] text-[#B8ACA3] mt-1 block">48h Turnaround →</span>
              </button>
            </div>
          </div>

          {/* 9. OVERLAID BOTTOM AGENCY BAR: Lowercase "digital agency" + "Start a Project" with official Uptodate logo */}
          <div className="relative z-20 w-full flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 sm:p-4 rounded-2xl bg-[#120A06]/95 border border-[#FF6A00]/25 backdrop-blur-xl shadow-2xl pointer-events-auto">
            
            {/* The Stylized Lowercase "digital agency" Typography & Logo */}
            <div className="flex items-center gap-3 text-center sm:text-left">
              <UptodateLogo variant="mark-only" size="sm" theme="yellow" />
              <div className="flex items-baseline gap-2">
                <span className="font-sans font-black text-2xl sm:text-3xl tracking-tight text-[#F5F1EC] lowercase">
                  digital<span className="text-[#FF6A00]">agency</span>
                </span>
                <span className="text-[11px] font-mono text-[#B8ACA3] uppercase tracking-widest">
                  / UPTODATE
                </span>
              </div>
            </div>

            {/* The Distinctive Yellow Pill Button "Start a Project" */}
            <button
              id="hero-start-a-project-btn"
              onClick={() => setDemoModalOpen(true)}
              className="yellow-btn w-full sm:w-auto px-6 py-2.5 rounded-full text-xs font-black text-[#0D0704] flex items-center justify-center gap-2 cursor-pointer shadow-[0_0_25px_rgba(255,106,0,0.45)] uppercase tracking-wider hover:scale-105 transition-all"
            >
              <span>Start a Project</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
