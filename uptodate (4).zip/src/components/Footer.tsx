import React from 'react';
import { useApp } from '../context/AppContext';
import { 
  PhoneCall, 
  Mail, 
  MessageSquare, 
  ArrowUpRight, 
  Sparkles, 
  Globe, 
  Instagram, 
  Linkedin, 
  Twitter, 
  Youtube 
} from 'lucide-react';
import { PageView } from '../types';
import { UptodateLogo } from './UptodateLogo';

export const Footer: React.FC = () => {
  const { setCurrentPage, setDemoModalOpen, setSelectedCategory } = useApp();

  const handleNav = (page: PageView) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleServiceClick = (category: string) => {
    setSelectedCategory(category);
    setCurrentPage('projects');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="relative bg-[#0A0503] border-t border-[#FF6A00]/20 pt-16 pb-12 overflow-hidden">
      {/* Ambient background glow */}
      <div className="absolute -bottom-40 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-[#FF6A00]/10 blur-3xl pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Top Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-[#FF6A00]/15">
          
          {/* Brand Column (2 cols on lg) */}
          <div className="lg:col-span-2 space-y-4">
            <div className="space-y-1">
              <UptodateLogo variant="full" size="lg" theme="white" />
              <span className="text-[10px] tracking-[0.22em] uppercase font-mono text-[#B8ACA3] font-semibold block pt-1">
                AI Creative Agency & Digital Studio
              </span>
            </div>

            <p className="text-[#B8ACA3] text-sm leading-relaxed max-w-sm">
              We design and produce cinematic AI video ads, high-converting digital products, interactive websites, and unforgettable brand identities for visionary global brands.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="X / Twitter"
                className="w-9 h-9 rounded-xl bg-[#140C08] hover:bg-[#1C120C] border border-[#FF6A00]/25 flex items-center justify-center text-[#B8ACA3] hover:text-[#F5F1EC] transition-colors"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="w-9 h-9 rounded-xl bg-[#140C08] hover:bg-[#1C120C] border border-[#FF6A00]/25 flex items-center justify-center text-[#B8ACA3] hover:text-[#F5F1EC] transition-colors"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn"
                className="w-9 h-9 rounded-xl bg-[#140C08] hover:bg-[#1C120C] border border-[#FF6A00]/25 flex items-center justify-center text-[#B8ACA3] hover:text-[#F5F1EC] transition-colors"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href="https://youtube.com"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="YouTube"
                className="w-9 h-9 rounded-xl bg-[#140C08] hover:bg-[#1C120C] border border-[#FF6A00]/25 flex items-center justify-center text-[#B8ACA3] hover:text-[#F5F1EC] transition-colors"
              >
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-mono tracking-widest text-[#F5F1EC] font-bold">
              Navigation
            </h4>
            <ul className="space-y-2 text-sm text-[#B8ACA3]">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-[#FFB347] transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-[#FFB347] transition-colors">
                  About Studio
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('services')} className="hover:text-[#FFB347] transition-colors">
                  Services
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('projects')} className="hover:text-[#FFB347] transition-colors">
                  Featured Projects
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-[#FFB347] transition-colors">
                  Contact Agency
                </button>
              </li>
            </ul>
          </div>

          {/* Services Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-mono tracking-widest text-[#F5F1EC] font-bold">
              Capabilities
            </h4>
            <ul className="space-y-2 text-sm text-[#B8ACA3]">
              <li>
                <button onClick={() => handleServiceClick('ai video')} className="hover:text-[#FFB347] transition-colors">
                  AI Commercials & Ads
                </button>
              </li>
              <li>
                <button onClick={() => handleServiceClick('ugc video')} className="hover:text-[#FFB347] transition-colors">
                  AI UGC Videos & Avatars
                </button>
              </li>
              <li>
                <button onClick={() => handleServiceClick('website')} className="hover:text-[#FFB347] transition-colors">
                  Website Design & Dev
                </button>
              </li>
              <li>
                <button onClick={() => handleServiceClick('branding')} className="hover:text-[#FFB347] transition-colors">
                  Logo & Brand Identity
                </button>
              </li>
              <li>
                <button onClick={() => handleServiceClick('digital marketing')} className="hover:text-[#FFB347] transition-colors">
                  Digital & Influencer Marketing
                </button>
              </li>
            </ul>
          </div>

          {/* Direct Contact / Direct Phone 962511181 */}
          <div className="space-y-3">
            <h4 className="text-xs uppercase font-mono tracking-widest text-[#F5F1EC] font-bold">
              Direct Contact
            </h4>
            <div className="space-y-3 text-sm">
              <a
                href="tel:962511181"
                className="flex items-center gap-2 text-[#B8ACA3] hover:text-[#FFB347] transition-colors group"
              >
                <div className="p-2 rounded-lg bg-[#FF6A00]/10 border border-[#FF6A00]/25 text-[#FFB347]">
                  <PhoneCall className="w-3.5 h-3.5 group-hover:rotate-12 transition-transform" />
                </div>
                <div>
                  <span className="block text-[11px] text-[#B8ACA3]">Call Directly</span>
                  <span className="font-mono font-bold text-[#F5F1EC] group-hover:text-[#FFB347]">962511181</span>
                </div>
              </a>

              <a
                href="https://wa.me/91962511181?text=Hi%20UPTODATE,%20I'd%20like%20to%20discuss%20a%20project!"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-[#B8ACA3] hover:text-emerald-400 transition-colors group"
              >
                <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-emerald-400">
                  <MessageSquare className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className="block text-[11px] text-[#B8ACA3]">WhatsApp Chat</span>
                  <span className="font-mono font-bold text-[#F5F1EC] group-hover:text-emerald-400">+91 962511181</span>
                </div>
              </a>

              <a
                href="mailto:jasminnmayl@gmail.com"
                className="flex items-center gap-2 text-[#B8ACA3] hover:text-[#FFB347] transition-colors group"
              >
                <div className="p-2 rounded-lg bg-[#140C08] border border-[#FF6A00]/20 text-[#FFB347]">
                  <Mail className="w-3.5 h-3.5" />
                </div>
                <div>
                  <span className="block text-[11px] text-[#B8ACA3]">Direct Inquiries</span>
                  <span className="font-mono text-[#F5F1EC] text-xs">jasminnmayl@gmail.com</span>
                </div>
              </a>

              <button
                id="footer-book-demo-btn"
                onClick={() => setDemoModalOpen(true)}
                className="yellow-btn w-full mt-2 py-2.5 rounded-xl text-[#0D0704] text-xs font-black flex items-center justify-center gap-1.5 cursor-pointer uppercase tracking-wider shadow-md"
              >
                <PhoneCall className="w-3.5 h-3.5" />
                <span>Book a Call Now</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#B8ACA3]">
          <p>© {new Date().getFullYear()} UPTODATE Studio Inc. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <span className="hover:text-[#F5F1EC] cursor-pointer">Privacy Policy</span>
            <span className="hover:text-[#F5F1EC] cursor-pointer">Terms of Service</span>
            <span className="font-mono text-[#FFB347] font-medium">To Know the Price contact us</span>
          </div>
        </div>

      </div>
    </footer>
  );
};
