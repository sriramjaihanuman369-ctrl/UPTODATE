import React, { forwardRef, useRef, useImperativeHandle, useEffect, useState } from 'react';
import { useMediaUrl } from '../utils/mediaStorage';
import { AlertCircle, RefreshCw, VolumeX } from 'lucide-react';

interface ProjectMediaVideoProps extends React.VideoHTMLAttributes<HTMLVideoElement> {
  videoUrl?: string;
  poster?: string;
  onRatioDetected?: (
    ratio: '16:9' | '9:16' | '1:1', 
    dimensions: { width: number; height: number; realRatio: number }
  ) => void;
}

export const ProjectMediaVideo = forwardRef<HTMLVideoElement, ProjectMediaVideoProps>(
  ({ videoUrl, src, poster, onLoadedMetadata, onRatioDetected, className = '', style, muted, autoPlay, ...props }, ref) => {
    const internalRef = useRef<HTMLVideoElement | null>(null);
    useImperativeHandle(ref, () => internalRef.current as HTMLVideoElement);

    const targetUrl = videoUrl || (typeof src === 'string' ? src : '');
    const resolvedUrl = useMediaUrl(targetUrl);
    const hasDetectedRef = useRef<string | null>(null);

    const [activeSrc, setActiveSrc] = useState<string>('');
    const [hasError, setHasError] = useState<boolean>(false);
    const [isLoaded, setIsLoaded] = useState<boolean>(false);
    const [isAutoplayMuted, setIsAutoplayMuted] = useState<boolean>(muted !== undefined ? Boolean(muted) : false);

    // Reset error and load state when URL changes
    useEffect(() => {
      setActiveSrc(resolvedUrl || '');
      setHasError(false);
      setIsLoaded(false);
    }, [resolvedUrl]);

    // Ensure DOM properties are set for modern browser autoplay policies
    useEffect(() => {
      const video = internalRef.current;
      if (!video || !activeSrc) return;

      const shouldMute = muted !== undefined ? Boolean(muted) : isAutoplayMuted;
      video.defaultMuted = shouldMute;
      video.muted = shouldMute;
      video.playsInline = true;
      video.setAttribute('playsinline', '');
      video.setAttribute('webkit-playsinline', '');

      if (autoPlay) {
        const playPromise = video.play();
        if (playPromise !== undefined) {
          playPromise.catch((err) => {
            console.debug('Autoplay unmuted blocked by browser, falling back to muted:', err);
            video.muted = true;
            setIsAutoplayMuted(true);
            video.play().catch((secondErr) => {
              console.debug('Autoplay muted retry note:', secondErr);
            });
          });
        }
      }
    }, [muted, autoPlay, activeSrc, isAutoplayMuted]);

    const handleLoadedMetadata = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
      const video = e.currentTarget;
      // Detect video dimensions and exact real ratio
      if (video.videoWidth && video.videoHeight && hasDetectedRef.current !== activeSrc) {
        hasDetectedRef.current = activeSrc || '';
        const realRatio = video.videoWidth / video.videoHeight;
        let detectedRatio: '16:9' | '9:16' | '1:1' = '16:9';
        if (realRatio < 0.85) {
          detectedRatio = '9:16';
        } else if (realRatio >= 0.85 && realRatio <= 1.25) {
          detectedRatio = '1:1';
        } else {
          detectedRatio = '16:9';
        }
        onRatioDetected?.(detectedRatio, { 
          width: video.videoWidth, 
          height: video.videoHeight,
          realRatio 
        });
      }

      if (onLoadedMetadata) {
        onLoadedMetadata(e);
      }
    };

    const handleCanPlay = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
      setIsLoaded(true);
      setHasError(false);
      if (props.onCanPlay) {
        props.onCanPlay(e);
      }
    };

    const handleError = (e: React.SyntheticEvent<HTMLVideoElement, Event>) => {
      const err = e.currentTarget.error;
      // Code 1 is MEDIA_ERR_ABORTED - browser aborted download due to source transition, ignore
      if (err && err.code === 1) {
        return;
      }
      console.warn('ProjectMediaVideo note for source:', activeSrc, err);
      setHasError(true);
      if (props.onError) {
        props.onError(e);
      }
    };

    const handleRetry = (e: React.MouseEvent) => {
      e.stopPropagation();
      setHasError(false);
      const video = internalRef.current;
      if (video) {
        video.load();
        video.play().catch(console.warn);
      }
    };

    const handleToggleMute = (e: React.MouseEvent) => {
      e.stopPropagation();
      const video = internalRef.current;
      if (video) {
        video.muted = !video.muted;
        setIsAutoplayMuted(video.muted);
      }
    };

    return (
      <div className="relative w-full h-full flex items-center justify-center bg-[#0D0704] overflow-hidden">
        {/* Underlying Poster Image: Always rendered so NO black screen ever flashes */}
        {poster && (
          <img
            src={poster}
            alt=""
            onError={(e) => {
              e.currentTarget.onerror = null;
              e.currentTarget.src = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80';
            }}
            className={`absolute inset-0 w-full h-full object-contain pointer-events-none transition-opacity duration-300 ${
              isLoaded && !hasError ? 'opacity-0' : 'opacity-100'
            }`}
          />
        )}

        {/* Video Player */}
        {activeSrc && !hasError && (
          <video
            ref={internalRef}
            src={activeSrc}
            playsInline
            crossOrigin="anonymous"
            muted={muted !== undefined ? muted : isAutoplayMuted}
            autoPlay={autoPlay}
            poster={poster}
            onLoadedMetadata={handleLoadedMetadata}
            onCanPlay={handleCanPlay}
            onError={handleError}
            className={`w-full h-full object-contain select-none transition-opacity duration-300 ${
              isLoaded ? 'opacity-100' : 'opacity-0'
            } ${className}`}
            style={{
              objectFit: 'contain',
              ...style,
            }}
            {...props}
          />
        )}

        {/* Loading Spinner Indicator (subtle, non-intrusive) */}
        {!isLoaded && !hasError && activeSrc && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10 bg-black/25 backdrop-blur-[1px]">
            <div className="flex flex-col items-center gap-2">
              <div className="w-9 h-9 rounded-full border-2 border-[#FF6A00]/30 border-t-[#FF6A00] animate-spin" />
              <span className="text-[10px] font-mono text-[#F5F1EC]/80 uppercase tracking-widest">Buffering</span>
            </div>
          </div>
        )}

        {/* Graceful Error Fallback */}
        {hasError && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/85 backdrop-blur-sm z-20 p-4 text-center">
            <AlertCircle className="w-9 h-9 text-[#FF6A00] mb-2" />
            <p className="text-xs sm:text-sm font-semibold text-[#F5F1EC] mb-1">Video stream unavailable</p>
            <p className="text-[11px] text-[#B8ACA3] max-w-xs mb-3">The stream could not be loaded directly.</p>
            <button
              type="button"
              onClick={handleRetry}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-[#FF6A00] hover:bg-[#FF8533] text-black font-semibold text-xs transition-colors shadow-lg cursor-pointer"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry Playback</span>
            </button>
          </div>
        )}

        {/* Quick Unmute indicator if video was muted by browser autoplay policy */}
        {isLoaded && !hasError && isAutoplayMuted && (
          <button
            type="button"
            onClick={handleToggleMute}
            className="absolute bottom-4 right-4 z-20 px-3 py-1 rounded-full bg-black/80 hover:bg-black text-[#FFB347] border border-[#FF6A00]/40 backdrop-blur-md text-xs font-semibold flex items-center gap-1.5 transition-all shadow-lg cursor-pointer"
            title="Click to Unmute"
          >
            <VolumeX className="w-3.5 h-3.5 text-[#FF6A00]" />
            <span>Unmute</span>
          </button>
        )}
      </div>
    );
  }
);

ProjectMediaVideo.displayName = 'ProjectMediaVideo';

