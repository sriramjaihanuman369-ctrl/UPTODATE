import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  PhoneCall, 
  Mail, 
  MessageSquare, 
  Send, 
  CheckCircle2, 
  Clock, 
  Building2, 
  Sparkles, 
  ShieldCheck, 
  ArrowRight,
  Inbox
} from 'lucide-react';
import { PhoneInputWithCountry } from '../components/PhoneInputWithCountry';

export const ContactView: React.FC = () => {
  const { saveContactEnquiry, setDemoModalOpen } = useApp();

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [countryMeta, setCountryMeta] = useState<{ countryCode: string; countryName: string }>({
    countryCode: '+44',
    countryName: 'United Kingdom'
  });
  const [companyName, setCompanyName] = useState('');
  const [message, setMessage] = useState('');
  const [service, setService] = useState('Ai Videos');

  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!name.trim()) {
      setError('Please enter your name.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setError('Please provide a valid email address.');
      return;
    }
    const cleanPhoneDigits = phone.replace(/[^\d]/g, '');
    if (!phone.trim() || cleanPhoneDigits.length < 6) {
      setError('Please enter a valid phone number with your country code.');
      return;
    }
    if (!message.trim()) {
      setError('Please provide a message or project brief.');
      return;
    }

    try {
      setLoading(true);
      await saveContactEnquiry({
        name: name.trim(),
        email: email.trim(),
        phone: phone.trim(),
        countryCode: countryMeta.countryCode,
        countryName: countryMeta.countryName,
        companyName: companyName.trim(),
        message: message.trim(),
        service
      });
      setLoading(false);
      setSubmitted(true);
    } catch (err: any) {
      console.error('Contact enquiry save error:', err);
      setLoading(false);
      setError('Failed to submit enquiry. Please call us directly at 962511181.');
    }
  };

  const handleReset = () => {
    setName('');
    setEmail('');
    setPhone('');
    setCompanyName('');
    setMessage('');
    setSubmitted(false);
  };

  return (
    <div id="contact-page-view" className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-12">
      
      {/* Header */}
      <div className="space-y-4 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-xs font-mono font-semibold text-amber-400 uppercase tracking-wider">
          <Sparkles className="w-3 h-3" />
          <span>Connect with UPTODATE</span>
        </div>
        <h1 className="font-heading text-4xl sm:text-6xl font-extrabold text-white tracking-tight leading-tight">
          Let's Build Something Impossible to Ignore.
        </h1>
        <p className="text-zinc-400 text-base sm:text-lg">
          Have an AI video concept, website rebrand, or performance campaign in mind? Send an inquiry or reach us directly on our dedicated studio phone <span className="text-amber-400 font-mono font-bold">962511181</span>.
        </p>
      </div>

      {/* Two-column layout: Form on Left (First on Mobile), Contact Details on Right (Below on Mobile) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
        
        {/* LEFT COLUMN: Contact Form */}
        <div className="lg:col-span-7 bg-[#11131a] rounded-3xl border border-white/10 p-6 sm:p-10 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>

          {submitted ? (
            <div id="contact-success-state" className="text-center py-10 space-y-6 animate-in fade-in duration-300">
              <div className="w-20 h-20 mx-auto rounded-full bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <div className="space-y-2">
                <h3 className="font-heading text-2xl sm:text-3xl font-bold text-white">
                  Message Sent to Agency Owner!
                </h3>
                <p className="text-sm text-zinc-300 max-w-md mx-auto leading-relaxed">
                  Thank you, <span className="text-amber-400 font-semibold">{name}</span>. Your project brief has been logged in our secure studio database.
                </p>
              </div>

              {/* Automatic Email Confirmation Notification Banner */}
              <div className="p-5 rounded-2xl bg-[#161924] border border-amber-500/30 text-left space-y-3 max-w-lg mx-auto">
                <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-400 uppercase tracking-wider">
                  <Inbox className="w-4 h-4" />
                  <span>Instant Lead & Client Confirmation Dispatched</span>
                </div>
                <p className="text-xs text-zinc-300 leading-relaxed">
                  Your inquiry with international contact number <span className="text-amber-400 font-mono font-bold">{phone}</span> ({countryMeta.countryName}) has been securely logged and dispatched to the studio directors (<span className="text-white font-mono font-semibold">sriramjaihanuman369@gmail.com</span> & <span className="text-white font-mono font-semibold">jasminnmayl@gmail.com</span>).
                </p>
                <div className="p-3 rounded-xl bg-black/40 border border-white/10 text-xs space-y-1.5">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-amber-400 font-bold">Confirmation Sent to Your Email:</div>
                  <div className="text-zinc-200 font-medium">Subject: <span className="text-white font-bold">We’ve Received Your Inquiry — UptoDate</span></div>
                  <div className="text-zinc-400 text-[11px] leading-relaxed italic">
                    "Hi {name}, Thank you for reaching out to UptoDate. We’ve received your inquiry and will get back to you shortly to discuss your requirements and the next steps..."
                  </div>
                </div>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
                <button
                  id="contact-another-msg-btn"
                  onClick={handleReset}
                  className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-white/10 hover:bg-white/15 text-xs font-semibold text-white transition-colors"
                >
                  Send Another Inquiry
                </button>
                <a
                  href="https://wa.me/91962511181?text=Hi%20UPTODATE,%20I%20just%20submitted%20a%20project%20inquiry!"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-xs font-bold text-black flex items-center justify-center gap-2 transition-colors"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Chat Immediately on WhatsApp (962511181)</span>
                </a>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="border-b border-white/10 pb-4 mb-6">
                <h3 className="font-heading text-2xl font-bold text-white">
                  Project Inquiry Form
                </h3>
                <p className="text-xs text-zinc-400 mt-1">
                  Fill out the details below and we will automatically dispatch a briefing confirmation to your email.
                </p>
              </div>

              {error && (
                <div className="p-3.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs">
                  {error}
                </div>
              )}

              {/* Name & Email Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5" htmlFor="contact-name">
                    Full Name <span className="text-amber-500">*</span>
                  </label>
                  <input
                    id="contact-name"
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Jordan Hayes"
                    className="w-full px-4 py-3 rounded-xl bg-[#161822] border border-white/10 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-amber-500/70"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5" htmlFor="contact-email">
                    Email Address <span className="text-amber-500">*</span>
                  </label>
                  <input
                    id="contact-email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jordan@company.com"
                    className="w-full px-4 py-3 rounded-xl bg-[#161822] border border-white/10 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-amber-500/70"
                  />
                </div>
              </div>

              {/* Phone & Company Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <PhoneInputWithCountry
                    idPrefix="contact"
                    label="Phone / WhatsApp Number"
                    required
                    defaultCountryCode="GB"
                    value={phone}
                    onChange={(fullVal, meta) => {
                      setPhone(fullVal);
                      setCountryMeta({ countryCode: meta.country.dialCode, countryName: meta.country.name });
                    }}
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-zinc-300 mb-1.5" htmlFor="contact-company">
                    Your Company Name
                  </label>
                  <input
                    id="contact-company"
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Acme Brands Inc."
                    className="w-full px-4 py-3 rounded-xl bg-[#161822] border border-white/10 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-amber-500/70"
                  />
                </div>
              </div>

              {/* Service Needed */}
              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Service You Need <span className="text-amber-500">*</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {['Ai Videos', 'Website Design', 'Website Development', 'Branding'].map((srv) => (
                    <button
                      key={srv}
                      type="button"
                      id={`contact-srv-btn-${srv.toLowerCase().replace(/\s+/g, '-')}`}
                      onClick={() => setService(srv)}
                      className={`px-3 py-2.5 rounded-xl text-xs font-medium border text-center transition-all ${
                        service === srv
                          ? 'bg-amber-500/20 border-amber-500/60 text-amber-300 font-bold'
                          : 'bg-[#161822] border-white/10 text-zinc-400 hover:text-white hover:border-white/20'
                      }`}
                    >
                      {srv}
                    </button>
                  ))}
                </div>
              </div>

              {/* Message */}
              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5" htmlFor="contact-message">
                  Your Message & Brief <span className="text-amber-500">*</span>
                </label>
                <textarea
                  id="contact-message"
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Share details about your upcoming campaign, target audience, budget, or launch timeline..."
                  className="w-full p-4 rounded-xl bg-[#161822] border border-white/10 text-white placeholder-zinc-500 text-sm focus:outline-none focus:border-amber-500/70 resize-none"
                />
              </div>

              <button
                id="submit-contact-enquiry-btn"
                type="submit"
                disabled={loading}
                className="yellow-btn w-full py-4 rounded-xl text-black font-black text-sm flex items-center justify-center gap-2.5 cursor-pointer disabled:opacity-50 uppercase tracking-wider shadow-lg"
              >
                {loading ? (
                  <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Send Project Inquiry</span>
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-4 pt-1 text-[11px] text-zinc-500">
                <span>✓ Owner notified instantly</span>
                <span>✓ Client confirmation email triggered</span>
              </div>
            </form>
          )}
        </div>

        {/* RIGHT COLUMN: Contact Details (Below on Mobile) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Studio Direct Contact Box */}
          <div className="p-8 rounded-3xl bg-[#11131a] border border-white/10 shadow-xl space-y-6">
            <h3 className="font-heading text-xl font-bold text-white">
              Studio Direct Channels
            </h3>
            
            <div className="space-y-4">
              
              {/* Phone Direct (962511181) */}
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-amber-500 text-black shrink-0">
                  <PhoneCall className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-mono uppercase text-amber-400 font-bold tracking-wider">
                    Direct Studio Phone
                  </p>
                  <a
                    href="tel:962511181"
                    id="contact-call-direct"
                    className="font-mono text-xl font-extrabold text-white hover:text-amber-400 transition-colors block mt-0.5"
                  >
                    962511181
                  </a>
                  <p className="text-xs text-zinc-400 mt-1">
                    Call anytime for immediate campaign onboarding.
                  </p>
                </div>
              </div>

              {/* WhatsApp Direct */}
              <div className="p-4 rounded-2xl bg-[#25D366]/10 border border-[#25D366]/30 flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-[#25D366] text-black shrink-0">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-mono uppercase text-emerald-400 font-bold tracking-wider">
                    WhatsApp Chat
                  </p>
                  <a
                    href="https://wa.me/91962511181?text=Hi%20UPTODATE,%20I'd%20like%20to%20discuss%20a%20project!"
                    target="_blank"
                    rel="noopener noreferrer"
                    id="contact-whatsapp-direct"
                    className="font-mono text-lg font-extrabold text-white hover:text-emerald-400 transition-colors block mt-0.5"
                  >
                    +91 962511181
                  </a>
                  <p className="text-xs text-zinc-400 mt-1">
                    Average response time &lt; 5 minutes.
                  </p>
                </div>
              </div>

              {/* Email */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-white/10 text-white shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-[11px] font-mono uppercase text-zinc-400 font-bold tracking-wider">
                    General Enquiries
                  </p>
                  <a
                    href="mailto:jasminnmayl@gmail.com"
                    className="font-mono text-base font-bold text-white hover:text-[#ffe600] transition-colors block mt-0.5"
                  >
                    jasminnmayl@gmail.com
                  </a>
                  <p className="text-xs text-zinc-400 mt-1">
                    For pitch decks, partnerships & RFPs.
                  </p>
                </div>
              </div>

            </div>
          </div>

          {/* Pricing & Working Hours Card */}
          <div className="p-8 rounded-3xl bg-[#11131a] border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#ffe600] font-bold">
              <Clock className="w-4 h-4" />
              <span>Studio Hours & Pricing</span>
            </div>
            <div className="space-y-2 text-xs text-zinc-300">
              <div className="flex justify-between py-1.5 border-b border-white/5">
                <span className="text-zinc-400">Monday — Saturday</span>
                <span className="font-mono font-semibold text-white">9:00 AM — 9:00 PM IST</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/5">
                <span className="text-zinc-400">Project Pricing</span>
                <span className="font-mono font-bold text-[#ffe600]">To Know the Price contact us</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/5">
                <span className="text-zinc-400">Average Production</span>
                <span className="font-mono font-bold text-white">48 hrs to 5 days</span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-zinc-400">Emergency 24h Turnaround</span>
                <span className="font-mono text-emerald-400 font-semibold">Available on Request</span>
              </div>
            </div>

            <button
              id="contact-side-book-demo-btn"
              onClick={() => setDemoModalOpen(true)}
              className="yellow-btn w-full mt-4 py-3 rounded-xl text-black font-black text-xs flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider shadow-md"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <span>Book Instant Free Demo</span>
            </button>
          </div>

        </div>

      </div>

    </div>
  );
};
