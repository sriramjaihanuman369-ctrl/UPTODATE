import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Search, 
  Sparkles, 
  ArrowRight, 
  Play, 
  PhoneCall, 
  CheckCircle2, 
  Zap, 
  TrendingUp, 
  DollarSign, 
  Clock, 
  ShieldCheck, 
  Video, 
  Megaphone, 
  Globe, 
  Palette, 
  ExternalLink,
  ChevronRight,
  Layers,
  Award
} from 'lucide-react';
import { Project } from '../types';
import { HeroGirlVisual } from '../components/HeroGirlVisual';
import { ProjectCardVideoPreview } from '../components/ProjectCardVideoPreview';
import { Card3D } from '../components/Card3D';
import { ScrollReveal } from '../components/ScrollReveal';
import { motion } from 'motion/react';

export const HomeView: React.FC = () => {
  const { 
    projects, 
    setCurrentPage, 
    setActiveSearchQuery, 
    setSelectedCategory, 
    setDemoModalOpen, 
    setServicesModalOpen,
    setActiveProjectModal,
    isAdmin
  } = useApp();

  const [searchInput, setSearchInput] = useState('');
  const [hoveredProjectId, setHoveredProjectId] = useState<string | null>(null);

  const heroSearchOptions = [
    { label: 'Ai Videos', category: 'ai video', query: 'ai video' },
    { label: 'Website Design', category: 'website', query: 'design' },
    { label: 'Website Development', category: 'website', query: 'development' },
    { label: 'Branding', category: 'branding', query: 'branding' }
  ];

  const handleHeroSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      setActiveSearchQuery(searchInput.trim());
      setCurrentPage('projects');
    }
  };

  const handleOptionClick = (option: { label: string; category: string; query: string }) => {
    setSelectedCategory(option.category);
    setActiveSearchQuery(option.query);
    setCurrentPage('projects');
  };

  // 6 Featured Projects
  const featuredProjects = projects.filter(p => p.featured).slice(0, 6);
  const displayProjects = featuredProjects.length > 0 ? featuredProjects : projects.slice(0, 6);

  const handleMouseEnter = (id: string) => {
    setHoveredProjectId(id);
  };

  const handleMouseLeave = () => {
    setHoveredProjectId(null);
  };

  return (
    <div id="home-view" className="relative min-h-screen">
      
      {/* 1. HERO SECTION (Integrating high-quality girl image with golden halo as background element behind hero search bar) */}
      <section 
        id="hero-section"
        className="relative min-h-[95vh] flex flex-col items-center justify-center pt-28 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden text-center"
      >
        {/* Cinematic Atmospheric Backdrop: Seamlessly merged with the studio image lighting */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {/* Deep warm studio gradient matching the photo background */}
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_35%,#1A0D07_0%,#120A06_50%,#0D0704_100%)]"></div>
          
          {/* Ambient Warm Molten Glow Bloom */}
          <div className="absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-[850px] sm:w-[1300px] h-[600px] bg-gradient-to-b from-[#FF6A00]/16 via-[#FFB347]/08 to-transparent rounded-full blur-[140px]"></div>
        </div>

        <div className="relative z-10 max-w-5xl mx-auto w-full space-y-8">
          
          {/* Top Brand Tag & Master Headline */}
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-4 max-w-3xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#140C08] border border-[#FF6A00]/35 text-xs font-mono font-semibold text-[#FFB347] shadow-[0_0_20px_rgba(255,106,0,0.18)]">
              <span className="w-2 h-2 rounded-full bg-[#FF6A00] animate-pulse"></span>
              <span>UPTODATE — NEXT-GEN AI CREATIVE LAB</span>
            </div>

            <h1 className="font-heading text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-[#F5F1EC] leading-[1.06]">
              Turning Ideas Into <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FF6A00] via-[#FF8C00] to-[#FFB347] drop-shadow-[0_0_25px_rgba(255,106,0,0.35)]">
                Attention Magnets
              </span>
            </h1>

            {/* Supporting Text */}
            <p className="text-sm sm:text-base text-[#B8ACA3] max-w-2xl mx-auto leading-relaxed">
              We engineer high-impact AI video commercials, bespoke web ecosystems, and category-defining branding that make ambitious companies impossible to ignore.
            </p>
          </motion.div>

          {/* MASTER CENTERPIECE: High-quality image of the girl with golden halo light beam as background element behind search bar */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.94, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-4xl mx-auto"
          >
            <HeroGirlVisual variant="full-hero">
              {/* Foreground Hero Search Bar & 4 Quick Explore Options */}
              <div className="relative w-full max-w-2xl mx-auto px-3 sm:px-4">
                <div className="p-2 sm:p-2.5 rounded-2xl bg-[#140C08]/95 border border-[#FF6A00]/40 backdrop-blur-xl shadow-[0_20px_60px_rgba(0,0,0,0.9),0_0_30px_rgba(255,106,0,0.18)] transition-all focus-within:border-[#FF6A00] focus-within:ring-2 focus-within:ring-[#FF6A00]/30 hover:shadow-[0_25px_70px_rgba(255,106,0,0.22)]">
                  <form onSubmit={handleHeroSearchSubmit} className="flex flex-col sm:flex-row items-center gap-2">
                    <div className="flex items-center gap-3 w-full px-4 py-2">
                      <Search className="w-5 h-5 text-[#FFB347] shrink-0" />
                      <input
                        id="hero-center-search-input"
                        type="text"
                        value={searchInput}
                        onChange={(e) => setSearchInput(e.target.value)}
                        placeholder="Search services or projects... e.g. AI video, website, branding"
                        className="w-full bg-transparent text-[#F5F1EC] placeholder-[#B8ACA3]/60 text-sm sm:text-base focus:outline-none"
                      />
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.04 }}
                      whileTap={{ scale: 0.96 }}
                      id="hero-search-submit-btn"
                      type="submit"
                      className="yellow-btn w-full sm:w-auto px-7 py-3 rounded-xl text-xs sm:text-sm font-black text-[#0D0704] shrink-0 flex items-center justify-center gap-2 cursor-pointer shadow-md uppercase tracking-wider"
                    >
                      <span>Search</span>
                      <ArrowRight className="w-4 h-4" />
                    </motion.button>
                  </form>
                </div>

                {/* 4 Clickable Quick Options Below Search Bar */}
                <div className="mt-3.5 flex flex-wrap items-center justify-center gap-2">
                  <span className="text-[11px] font-mono text-[#B8ACA3] uppercase tracking-wider mr-1 hidden sm:inline">
                    Quick Explore:
                  </span>
                  {heroSearchOptions.map((opt, idx) => (
                    <motion.button
                      initial={{ opacity: 0, y: 15 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: 0.3 + idx * 0.07 }}
                      whileHover={{ scale: 1.06, y: -2 }}
                      whileTap={{ scale: 0.95 }}
                      key={opt.label}
                      id={`hero-option-${opt.label.toLowerCase().replace(/\s+/g, '-')}`}
                      onClick={() => handleOptionClick(opt)}
                      className="px-3.5 py-1.5 rounded-full text-xs font-bold bg-[#140C08]/90 backdrop-blur-md hover:bg-gradient-to-r hover:from-[#FF6A00] hover:to-[#FFB347] text-[#B8ACA3] hover:text-[#0D0704] border border-[#FF6A00]/25 hover:border-[#FF6A00] transition-all duration-200 cursor-pointer flex items-center gap-1.5 shadow-sm"
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-[#FF6A00]"></span>
                      <span>{opt.label}</span>
                    </motion.button>
                  ))}
                </div>
              </div>
            </HeroGirlVisual>
          </motion.div>

          {/* Action Buttons: Book Your Free Demo & View Projects */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.45 }}
            className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <motion.button
              whileHover={{ scale: 1.04, boxShadow: '0 0 45px rgba(255,106,0,0.65)' }}
              whileTap={{ scale: 0.97 }}
              id="hero-book-free-demo-btn"
              onClick={() => setDemoModalOpen(true)}
              className="yellow-btn w-full sm:w-auto px-8 py-4 rounded-full text-sm font-black text-[#0D0704] flex items-center justify-center gap-2.5 shadow-[0_0_35px_rgba(255,106,0,0.45)] cursor-pointer group uppercase tracking-wider"
            >
              <PhoneCall className="w-4 h-4 group-hover:rotate-12 transition-transform" />
              <span>BOOK YOUR FREE DEMO</span>
              <span className="text-xs font-mono font-bold bg-black/15 px-2 py-0.5 rounded hidden sm:inline">(962511181)</span>
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              id="hero-view-projects-btn"
              onClick={() => setCurrentPage('projects')}
              className="w-full sm:w-auto px-8 py-4 rounded-full text-sm font-bold text-[#F5F1EC] bg-[#180E09] hover:bg-[#22140D] border border-[#FF6A00]/30 hover:border-[#FF6A00]/60 transition-all flex items-center justify-center gap-2 group cursor-pointer uppercase tracking-wider"
            >
              <span>View Projects</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </motion.div>

          {/* Social Proof / Guarantee Strip */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="pt-2 flex flex-wrap items-center justify-center gap-6 text-xs text-[#B8ACA3]"
          >
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#FF6A00]" /> To Know the Price contact us
            </span>
            <span className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#FF6A00]" /> Average production: 48 hrs to 5 days
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#FF6A00]" /> 100% Commercial rights
            </span>
          </motion.div>

        </div>
      </section>



      {/* 2. SERVICES PREVIEW (4 Premium Interactive Cards) */}
      <section id="services-preview-section" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <ScrollReveal animation="fade-up" className="flex flex-col md:flex-row md:items-end justify-between mb-14 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-[11px] font-mono font-semibold text-[#FFB347] uppercase tracking-wider mb-3">
              <Layers className="w-3 h-3" />
              <span>Full-Spectrum Capabilities</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#F5F1EC] tracking-tight">
              What We Create
            </h2>
            <p className="text-[#B8ACA3] text-sm sm:text-base max-w-xl mt-2">
              Combining world-class creative vision with next-generation generative AI infrastructure to engineer category-defining brand experiences.
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            id="open-services-modal-btn"
            onClick={() => setServicesModalOpen(true)}
            className="px-6 py-3 rounded-full text-xs font-bold text-[#FFB347] bg-[#FF6A00]/10 hover:bg-[#FF6A00]/20 border border-[#FF6A00]/30 transition-all flex items-center gap-2 self-start md:self-auto cursor-pointer"
          >
            <span>View All 4 Services In Detail</span>
            <ChevronRight className="w-4 h-4" />
          </motion.button>
        </ScrollReveal>

        {/* 4 Cards Grid with 3D Pop-Up & Tilt */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
          
          {/* Card 1: AI */}
          <Card3D delay={0.05} intensity={10} enableGlow={true} className="h-full">
            <div 
              id="service-card-ai"
              className="h-full group relative rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 hover:border-[#FF6A00]/60 p-6 sm:p-8 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(255,106,0,0.18)] flex flex-col justify-between overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#FF6A00]/10 rounded-full blur-3xl group-hover:bg-[#FF6A00]/20 transition-all pointer-events-none"></div>

              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FF6A00]/25 to-[#FFB347]/10 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347]">
                    <Video className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#FF6A00]/15 text-[#FFB347] border border-[#FF6A00]/30">
                    AI PRODUCTION
                  </span>
                </div>

                <h3 className="font-heading text-2xl font-bold text-[#F5F1EC] mb-2 group-hover:text-[#FFB347] transition-colors">
                  AI CREATIVE & VIDEO
                </h3>
                <p className="text-[#B8ACA3] text-xs sm:text-sm mb-6">
                  Hyper-realistic synthetic film production, AI actors, and algorithmically engineered visual assets.
                </p>

                {/* Subpoints with descriptions in right of its name */}
                <div className="space-y-3.5 border-t border-[#FF6A00]/15 pt-5 mb-6">
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      AI Ad Videos:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Photorealistic 4K cinematic commercials produced without film crews.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      AI OPTIMISED CONTENT:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      High-retention social hooks & dynamic avatar campaigns built for viral CTR.
                    </span>
                  </div>
                </div>
              </div>

              <button
                id="goto-ai-service"
                onClick={() => {
                  setSelectedCategory('ai video');
                  setCurrentPage('projects');
                }}
                className="mt-4 pt-4 border-t border-[#FF6A00]/15 flex items-center justify-between text-xs font-bold text-[#FFB347] group-hover:text-[#FF6A00] transition-colors cursor-pointer"
              >
                <span>Explore AI Video Projects</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </Card3D>

          {/* Card 2: DIGITAL MARKETING */}
          <Card3D delay={0.15} intensity={10} enableGlow={true} className="h-full">
            <div 
              id="service-card-marketing"
              className="h-full group relative rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 hover:border-[#FF6A00]/60 p-6 sm:p-8 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(255,106,0,0.18)] flex flex-col justify-between overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#FF6A00]/10 rounded-full blur-3xl group-hover:bg-[#FF6A00]/20 transition-all pointer-events-none"></div>

              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FF6A00]/25 to-[#FF8C00]/10 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347]">
                    <Megaphone className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#FF6A00]/15 text-[#FFB347] border border-[#FF6A00]/30">
                    PERFORMANCE
                  </span>
                </div>

                <h3 className="font-heading text-2xl font-bold text-[#F5F1EC] mb-2 group-hover:text-[#FFB347] transition-colors">
                  DIGITAL MARKETING
                </h3>
                <p className="text-[#B8ACA3] text-xs sm:text-sm mb-6">
                  Full-funnel organic and paid acquisition engines powered by creator intelligence and AI video scale.
                </p>

                {/* Subpoints with descriptions */}
                <div className="space-y-3.5 border-t border-[#FF6A00]/15 pt-5 mb-6">
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      Social Media:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Continuous video output across TikTok, Reels, and YouTube Shorts.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      INFLUENCER MARKETING:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Targeted creator matchmaking with scalable revenue-share performance.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      CONTENT MARKETING:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Authority-building storytelling, interactive decks, and SEO frameworks.
                    </span>
                  </div>
                </div>
              </div>

              <button
                id="goto-marketing-service"
                onClick={() => {
                  setSelectedCategory('digital marketing');
                  setCurrentPage('projects');
                }}
                className="mt-4 pt-4 border-t border-[#FF6A00]/15 flex items-center justify-between text-xs font-bold text-[#FFB347] group-hover:text-[#FF6A00] transition-colors cursor-pointer"
              >
                <span>Explore Marketing Case Studies</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </Card3D>

          {/* Card 3: WEBSITE */}
          <Card3D delay={0.25} intensity={10} enableGlow={true} className="h-full">
            <div 
              id="service-card-website"
              className="h-full group relative rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 hover:border-[#FF6A00]/60 p-6 sm:p-8 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(255,106,0,0.18)] flex flex-col justify-between overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#FF6A00]/10 rounded-full blur-3xl group-hover:bg-[#FF6A00]/20 transition-all pointer-events-none"></div>

              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FF6A00]/25 to-[#FFB347]/10 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347]">
                    <Globe className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#FF6A00]/15 text-[#FFB347] border border-[#FF6A00]/30">
                    WEB ARCHITECTURE
                  </span>
                </div>

                <h3 className="font-heading text-2xl font-bold text-[#F5F1EC] mb-2 group-hover:text-[#FFB347] transition-colors">
                  WEBSITE & DIGITAL PRODUCTS
                </h3>
                <p className="text-[#B8ACA3] text-xs sm:text-sm mb-6">
                  High-performance immersive web applications, spatial UI/UX design, and conversion-optimized architectures.
                </p>

                {/* Subpoints with descriptions */}
                <div className="space-y-3.5 border-t border-[#FF6A00]/15 pt-5 mb-6">
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      DESIGN:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Custom spatial UI/UX design, micro-interactions, and 3D visual assets.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      DEVELOPMENT:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Blazing-fast React/Next.js codebases, headless CMS, and API integrations.
                    </span>
                  </div>
                </div>
              </div>

              <button
                id="goto-website-service"
                onClick={() => {
                  setSelectedCategory('website');
                  setCurrentPage('projects');
                }}
                className="mt-4 pt-4 border-t border-[#FF6A00]/15 flex items-center justify-between text-xs font-bold text-[#FFB347] group-hover:text-[#FF6A00] transition-colors cursor-pointer"
              >
                <span>Explore Websites & Apps</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </Card3D>

          {/* Card 4: BRANDING */}
          <Card3D delay={0.35} intensity={10} enableGlow={true} className="h-full">
            <div 
              id="service-card-branding"
              className="h-full group relative rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 hover:border-[#FF6A00]/60 p-6 sm:p-8 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(255,106,0,0.18)] flex flex-col justify-between overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#FF6A00]/10 rounded-full blur-3xl group-hover:bg-[#FF6A00]/20 transition-all pointer-events-none"></div>

              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#FF6A00]/25 to-[#FFB347]/10 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347]">
                    <Palette className="w-6 h-6" />
                  </div>
                  <span className="px-3 py-1 rounded-full text-[11px] font-mono font-semibold bg-[#FF6A00]/15 text-[#FFB347] border border-[#FF6A00]/30">
                    BRAND IDENTITY
                  </span>
                </div>

                <h3 className="font-heading text-2xl font-bold text-[#F5F1EC] mb-2 group-hover:text-[#FFB347] transition-colors">
                  BRANDING & IDENTITY
                </h3>
                <p className="text-[#B8ACA3] text-xs sm:text-sm mb-6">
                  Complete corporate identities, iconic logos, and memorable design systems built for modern digital dominance.
                </p>

                {/* Subpoints with descriptions */}
                <div className="space-y-3.5 border-t border-[#FF6A00]/15 pt-5 mb-6">
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      LOGO DESIGN:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Distinctive vector monograms & iconic emblems crafted for longevity.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      BRAND DEVELOPMENT:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Visual rules, typography pairings, color systems, and tone of voice.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      BRAND COLLATERAL:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Investor pitch decks, packaging, merchandise & conversion marketing kits.
                    </span>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-1 text-xs">
                    <span className="font-bold text-[#F5F1EC] uppercase tracking-wider font-mono text-[11px]">
                      Corporate identity:
                    </span>
                    <span className="text-[#B8ACA3] sm:text-right text-xs">
                      Cross-platform design systems & enterprise brand compliance guidelines.
                    </span>
                  </div>
                </div>
              </div>

              <button
                id="goto-branding-service"
                onClick={() => {
                  setSelectedCategory('branding');
                  setCurrentPage('projects');
                }}
                className="mt-4 pt-4 border-t border-[#FF6A00]/15 flex items-center justify-between text-xs font-bold text-[#FFB347] group-hover:text-[#FF6A00] transition-colors cursor-pointer"
              >
                <span>Explore Branding Work</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          </Card3D>

        </div>
      </section>

      {/* 3. FEATURED PROJECTS (Editorial Asymmetric Grid) */}
      <section id="featured-projects-section" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#FF6A00]/20">
        <ScrollReveal animation="fade-up" className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-[11px] font-mono font-semibold text-[#FFB347] uppercase tracking-wider mb-3">
              <Sparkles className="w-3 h-3" />
              <span>Selected Case Studies</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl md:text-5xl font-extrabold text-[#F5F1EC] tracking-tight">
              Featured Projects
            </h2>
            <p className="text-[#B8ACA3] text-sm sm:text-base max-w-xl mt-2">
              Hover on any card to preview video motion. Click to inspect the full case study, metrics, and deliverables.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {isAdmin && (
              <button
                id="admin-add-project-quick"
                onClick={() => setCurrentPage('admin')}
                className="px-4 py-2 rounded-full text-xs font-mono font-bold bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/40 hover:bg-[#FF6A00]/30 transition-colors cursor-pointer"
              >
                + Manage Projects (Admin)
              </button>
            )}
            <motion.button
              whileHover={{ scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              id="view-all-projects-btn"
              onClick={() => setCurrentPage('projects')}
              className="px-6 py-3 rounded-full text-xs font-bold text-[#F5F1EC] bg-[#180E09] hover:bg-[#22140D] border border-[#FF6A00]/30 hover:border-[#FF6A00]/60 transition-colors flex items-center gap-2 cursor-pointer uppercase tracking-wider"
            >
              <span>View All Projects ({projects.length})</span>
              <ArrowRight className="w-4 h-4" />
            </motion.button>
          </div>
        </ScrollReveal>

        {/* 6 Projects in Editorial Asymmetric Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 items-start">
          {displayProjects.map((proj, index) => {
            const isHovered = hoveredProjectId === proj.id;
            const isLarge = (index === 0 || index === 3) && proj.aspectRatio !== '9:16';
            const isReel = proj.aspectRatio === '9:16' || proj.videoUrl?.includes('/shorts/');
            const isSquare = proj.aspectRatio === '1:1';

            return (
              <Card3D
                key={proj.id}
                delay={(index % 3) * 0.08}
                intensity={8}
                enableGlow={true}
                className={isLarge ? 'md:col-span-2 lg:col-span-2 h-full' : 'h-full'}
              >
                <div
                  id={`featured-project-card-${proj.id}`}
                  onMouseEnter={() => handleMouseEnter(proj.id)}
                  onMouseLeave={() => handleMouseLeave()}
                  onClick={() => setActiveProjectModal(proj)}
                  className="h-full group relative rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 overflow-hidden cursor-pointer hover:border-[#FF6A00]/60 transition-all duration-300 hover:shadow-[0_12px_40px_rgba(255,106,0,0.18)] flex flex-col justify-between"
                >
                  {/* Auto-playing Muted Video Card Preview */}
                  <ProjectCardVideoPreview
                    project={proj}
                    isHovered={isHovered}
                  />

                  {/* Card Information */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="font-heading font-bold text-xl text-[#F5F1EC] group-hover:text-[#FFB347] transition-colors line-clamp-1 mb-2">
                        {proj.title}
                      </h3>
                      <p className="text-[#B8ACA3] text-xs line-clamp-2 leading-relaxed mb-4">
                        {proj.description}
                      </p>
                    </div>

                    <div className="pt-3 border-t border-[#FF6A00]/15 flex items-center justify-between text-xs">
                      {proj.results ? (
                        <span className="font-mono text-[#FFB347] text-[11px] font-semibold truncate max-w-[200px]">
                          ★ {proj.results}
                        </span>
                      ) : (
                        <span className="font-mono text-[#B8ACA3]/70 text-[11px]">
                          Full Case Study
                        </span>
                      )}

                      <span className="text-[#B8ACA3] group-hover:text-[#F5F1EC] flex items-center gap-1 font-semibold text-xs">
                        View Project <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </span>
                    </div>
                  </div>
                </div>
              </Card3D>
            );
          })}
        </div>
      </section>

      {/* 4. WHY US ? SECTION */}
      <section id="why-us-section" className="py-24 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-[#FF6A00]/20">
        <ScrollReveal animation="fade-up" className="text-center max-w-2xl mx-auto mb-16 space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-[11px] font-mono font-semibold text-[#FFB347] uppercase tracking-wider">
            <ShieldCheck className="w-3 h-3" />
            <span>The UPTODATE Advantage</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-extrabold text-[#F5F1EC] tracking-tight">
            WHY US ?
          </h2>
          <p className="text-[#B8ACA3] text-sm sm:text-base">
            We eliminated the bureaucratic bloat of traditional agency models to deliver world-class creative output at tech speed.
          </p>
        </ScrollReveal>

        {/* 3 Pillars as mandated in prompt: CREATIVE, Faster production, AFFORDABLE : WORK START WITH 3000 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Pillar 1: CREATIVE */}
          <Card3D delay={0.05} intensity={10} enableGlow={true} className="h-full">
            <div 
              id="why-us-creative"
              className="h-full p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 hover:border-[#FF6A00]/50 transition-all duration-300 space-y-4 relative overflow-hidden group flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-[#FF6A00]/15 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347] group-hover:scale-110 transition-transform">
                  <Sparkles className="w-7 h-7" />
                </div>
                <h3 className="font-heading font-extrabold text-2xl text-[#F5F1EC] tracking-tight">
                  CREATIVE
                </h3>
                <p className="text-[#B8ACA3] text-sm leading-relaxed">
                  We don't output raw prompts or robotic clichés. Every piece of work is directed by veteran designers, colorists, and copywriters to ensure your brand commands attention and builds genuine equity.
                </p>
              </div>
              <div className="pt-2">
                <span className="inline-block px-3 py-1 rounded-full text-[11px] font-mono bg-[#FF6A00]/10 border border-[#FF6A00]/20 text-[#FFB347]">
                  Art-Directed Synthesis
                </span>
              </div>
            </div>
          </Card3D>

          {/* Pillar 2: Faster production */}
          <Card3D delay={0.15} intensity={10} enableGlow={true} className="h-full">
            <div 
              id="why-us-speed"
              className="h-full p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 hover:border-[#FF6A00]/50 transition-all duration-300 space-y-4 relative overflow-hidden group flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-[#FF6A00]/15 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347] group-hover:scale-110 transition-transform">
                  <Zap className="w-7 h-7" />
                </div>
                <h3 className="font-heading font-extrabold text-2xl text-[#F5F1EC] tracking-tight">
                  Faster Production
                </h3>
                <p className="text-[#B8ACA3] text-sm leading-relaxed">
                  What takes conventional production companies 6 to 8 weeks, UPTODATE delivers with an average production of 48 hrs to 5 days. Launch multiple campaign variations simultaneously, test hooks rapidly, and iterate without delay.
                </p>
              </div>
              <div className="pt-2">
                <span className="inline-block px-3 py-1 rounded-full text-[11px] font-mono bg-[#FF6A00]/10 border border-[#FF6A00]/20 text-[#FFB347]">
                  48 hrs to 5 days Production
                </span>
              </div>
            </div>
          </Card3D>

          {/* Pillar 3: AFFORDABLE: TRANSPARENT VALUE */}
          <Card3D delay={0.25} intensity={12} enableGlow={true} className="h-full">
            <div 
              id="why-us-affordable"
              className="h-full p-8 rounded-3xl bg-gradient-to-b from-[#1C100A] to-[#140C08] border border-[#FF6A00]/40 hover:border-[#FF6A00]/70 transition-all duration-300 space-y-4 relative overflow-hidden group shadow-[0_10px_35px_rgba(255,106,0,0.18)] flex flex-col justify-between"
            >
              <div className="space-y-4">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#FF6A00] to-[#FFB347] flex items-center justify-center text-[#0D0704] font-bold text-xl group-hover:scale-110 transition-transform">
                  ✦
                </div>
                <h3 className="font-heading font-extrabold text-2xl text-[#F5F1EC] tracking-tight flex items-center justify-between">
                  <span>AFFORDABLE</span>
                  <span className="text-xs font-mono font-bold text-[#0D0704] bg-gradient-to-r from-[#FF6A00] to-[#FFB347] px-2.5 py-1 rounded-full border border-[#FF6A00]/50">
                    CUSTOM QUOTES
                  </span>
                </h3>
                <div className="text-[#FFB347] font-mono font-bold text-lg">
                  To Know the Price contact us
                </div>
                <p className="text-[#B8ACA3] text-sm leading-relaxed">
                  No bloated retainers, studio overheads, or hidden fee markups. Transparent deliverables tailored to your scope with 10x the output volume of standard agencies.
                </p>
              </div>
              <div className="pt-2">
                <button
                  id="why-us-book-demo-link"
                  onClick={() => setDemoModalOpen(true)}
                  className="text-xs font-bold text-[#0D0704] bg-gradient-to-r from-[#FF6A00] to-[#FFB347] hover:brightness-110 px-4 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer shadow-md"
                >
                  <span>To Know the Price contact us</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </Card3D>

        </div>
      </section>

      {/* 6. FINAL CTA BANNER (Large premium molten orange and charcoal banner) */}
      <section id="final-cta-section" className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <ScrollReveal animation="zoom-in" delay={0.1}>
          <div className="relative rounded-3xl bg-[#120A06] border border-[#FF6A00]/40 p-8 sm:p-14 lg:p-16 overflow-hidden shadow-2xl text-center space-y-6">
            
            {/* Ambient Molten Orange Glow */}
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-[#FF6A00]/15 rounded-full blur-3xl pointer-events-none"></div>
            <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-[#FF6A00]/10 rounded-full blur-3xl pointer-events-none"></div>

            <div className="relative z-10 max-w-3xl mx-auto space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF6A00]/15 border border-[#FF6A00]/30 text-xs font-mono font-bold text-[#FFB347] uppercase tracking-widest">
                <Sparkles className="w-3.5 h-3.5" />
                <span>START YOUR NEXT CAMPAIGN TODAY</span>
              </div>

              <h2 className="font-display text-3xl sm:text-5xl lg:text-6xl font-extrabold text-[#F5F1EC] tracking-tight leading-tight uppercase">
                Ready to create something{' '}
                <span className="text-[#FFB347]">
                  impossible to ignore?
                </span>
              </h2>

              <p className="text-[#B8ACA3] text-sm sm:text-base max-w-xl mx-auto">
                Schedule a 1-on-1 strategy call with our creative technology directors. Direct agency line: <a href="tel:962511181" className="text-[#FFB347] font-mono font-bold hover:underline">962511181</a> • <a href="mailto:jasminnmayl@gmail.com" className="text-[#F5F1EC] hover:text-[#FFB347] hover:underline">jasminnmayl@gmail.com</a>.
              </p>

              <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-4">
                <motion.button
                  whileHover={{ scale: 1.05, boxShadow: "0 0 35px rgba(255,106,0,0.5)" }}
                  whileTap={{ scale: 0.95 }}
                  id="final-cta-book-a-call-btn"
                  onClick={() => setDemoModalOpen(true)}
                  className="yellow-btn w-full sm:w-auto px-10 py-4 rounded-full text-base font-black text-[#0D0704] flex items-center justify-center gap-3 cursor-pointer group uppercase tracking-wider shadow-lg"
                >
                  <PhoneCall className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                  <span>BOOK A CALL</span>
                  <span className="text-xs font-mono font-bold bg-black/15 px-2 py-0.5 rounded hidden sm:inline">(962511181)</span>
                </motion.button>

                <motion.button
                  whileHover={{ scale: 1.04 }}
                  whileTap={{ scale: 0.96 }}
                  id="final-cta-contact-btn"
                  onClick={() => setCurrentPage('contact')}
                  className="w-full sm:w-auto px-8 py-4 rounded-full text-sm font-bold text-[#F5F1EC] bg-[#180E09] hover:bg-[#22140D] border border-[#FF6A00]/30 hover:border-[#FF6A00]/60 transition-all cursor-pointer uppercase tracking-wider"
                >
                  Send Us a Message
                </motion.button>
              </div>
            </div>
          </div>
        </ScrollReveal>
      </section>

    </div>
  );
};
