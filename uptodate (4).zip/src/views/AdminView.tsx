import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ShieldCheck, 
  PlusCircle, 
  Trash2, 
  Edit3, 
  Star, 
  Calendar, 
  Mail, 
  PhoneCall, 
  CheckCircle, 
  Sparkles, 
  FolderGit2, 
  UserCheck, 
  Search,
  ExternalLink,
  X,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  LogIn
} from 'lucide-react';
import { Project } from '../types';
import { ThumbnailFileUploader, VideoFileUploader } from '../components/MediaFileUploader';

export const AdminView: React.FC = () => {
  const { 
    isAdmin, 
    isAuthLoading,
    user, 
    projects, 
    demoBookings, 
    contactEnquiries, 
    addProject, 
    editProject, 
    removeProject,
    setActiveProjectModal,
    editingProjectId,
    setEditingProjectId,
    setAuthModalOpen,
    loginWithGoogle
  } = useApp();

  const [activeTab, setActiveTab] = useState<'projects' | 'bookings' | 'enquiries'>('projects');
  const [isAdding, setIsAdding] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  // Form states
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<'ai video' | 'website' | 'branding' | 'ugc video' | 'digital marketing'>('ai video');
  const [description, setDescription] = useState('');
  const [thumbnail, setThumbnail] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [videoType, setVideoType] = useState<'mp4' | 'youtube' | 'vimeo' | 'drive'>('mp4');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1' | 'auto'>('auto');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [tags, setTags] = useState('');
  const [results, setResults] = useState('');
  const [featured, setFeatured] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Delete modal state (replaces broken window.confirm)
  const [projectToDelete, setProjectToDelete] = useState<{ id: string; title: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  const [searchQuery, setSearchQuery] = useState('');
  const formRef = useRef<HTMLDivElement>(null);

  const showToast = (text: string, type: 'success' | 'error' = 'success') => {
    setToastMessage({ text, type });
    setTimeout(() => {
      setToastMessage(null);
    }, 4000);
  };

  // If directed here to edit a specific project
  useEffect(() => {
    if (editingProjectId && projects.length > 0) {
      const proj = projects.find(p => p.id === editingProjectId);
      if (proj) {
        handleOpenEdit(proj);
      }
      setEditingProjectId(null);
    }
  }, [editingProjectId, projects]);

  const handleOpenAdd = () => {
    setTitle('');
    setCategory('ai video');
    setDescription('');
    setThumbnail('');
    setVideoUrl('');
    setVideoType('mp4');
    setAspectRatio('auto');
    setWebsiteUrl('');
    setTags('AI Video, Neural Ads, Commercial');
    setResults('+340% ROAS');
    setFeatured(true);
    setEditingProject(null);
    setError('');
    setIsAdding(true);

    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleOpenEdit = (proj: Project) => {
    setTitle(proj.title);
    setCategory(proj.category as any);
    setDescription(proj.description);
    setThumbnail(proj.thumbnail);
    setVideoUrl(proj.videoUrl || '');
    setVideoType(proj.videoType || 'mp4');
    setAspectRatio(proj.aspectRatio || 'auto');
    setWebsiteUrl(proj.websiteUrl || '');
    setTags(proj.tags ? proj.tags.join(', ') : '');
    setResults(proj.results || '');
    setFeatured(Boolean(proj.featured));
    setEditingProject(proj);
    setError('');
    setIsAdding(true);

    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim()) {
      setError('Project title is required.');
      return;
    }

    // Auto-fallback: if thumbnail is not uploaded yet, provide crisp default or let auto-captured frame serve
    let finalThumbnail = thumbnail.trim();
    if (!finalThumbnail) {
      finalThumbnail = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80';
    }

    try {
      setSaving(true);
      const tagArray = tags.split(',').map(t => t.trim()).filter(Boolean);

      const projectPayload = {
        title: title.trim(),
        category,
        description: description.trim(),
        thumbnail: finalThumbnail,
        videoUrl: videoUrl.trim(),
        videoType,
        aspectRatio,
        websiteUrl: websiteUrl.trim(),
        tags: tagArray,
        results: results.trim(),
        featured
      };

      if (editingProject) {
        await editProject(editingProject.id, projectPayload);
        showToast(`Project "${title.trim()}" updated successfully!`, 'success');
      } else {
        await addProject(projectPayload);
        showToast(`New project "${title.trim()}" published live!`, 'success');
      }

      setSaving(false);
      setIsAdding(false);
      setEditingProject(null);
    } catch (err: any) {
      console.error('Admin save project error:', err);
      setSaving(false);
      setError('Failed to save project. Please check network connection.');
    }
  };

  const handleToggleFeatured = async (proj: Project) => {
    await editProject(proj.id, { featured: !proj.featured });
    showToast(`Featured status for "${proj.title}" updated.`, 'success');
  };

  const handleDeleteConfirm = async () => {
    if (!projectToDelete) return;
    try {
      setIsDeleting(true);
      await removeProject(projectToDelete.id);
      showToast(`Project "${projectToDelete.title}" was permanently deleted.`, 'success');
      setIsDeleting(false);
      setProjectToDelete(null);
    } catch (err: any) {
      console.error('Delete error:', err);
      setIsDeleting(false);
      showToast('Could not delete project. Please try again.', 'error');
    }
  };

  const handleExportProjectsBackup = () => {
    try {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(projects, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `uptodate_projects_backup_${new Date().toISOString().split('T')[0]}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      showToast('JSON backup exported successfully.', 'success');
    } catch (e) {
      console.error("Backup export error:", e);
    }
  };

  // Admin access gate
  if (isAuthLoading) {
    return (
      <div className="min-h-[75vh] flex items-center justify-center pt-28">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-full border-2 border-[#FF6A00]/30 border-t-[#FF6A00] animate-spin" />
          <p className="text-xs font-mono text-[#B8ACA3]">Verifying Director Credentials...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div id="admin-restricted-view" className="min-h-[80vh] flex items-center justify-center px-4 pt-28 pb-16">
        <div className="max-w-md w-full p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/40 text-center space-y-6 shadow-2xl">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-[#FF6A00]/20 border border-[#FF6A00]/40 flex items-center justify-center text-[#FFB347]">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <h2 className="font-heading text-2xl font-bold text-[#F5F1EC]">
              Director Access Control
            </h2>
            <p className="text-xs text-[#B8ACA3] leading-relaxed mt-2">
              The project publishing & management studio is reserved for agency directors (<span className="text-[#FFB347] font-mono">sriramjaihanuman369@gmail.com</span> & <span className="text-[#FFB347] font-mono">jasminnmayl@gmail.com</span>).
            </p>
          </div>

          <div className="pt-2 text-xs text-[#B8ACA3]/70">
            Currently signed in as: <span className="text-[#F5F1EC] font-mono">{user?.email || 'Guest / Not Signed In'}</span>
          </div>

          <div className="space-y-2.5 pt-2">
            <button
              onClick={() => loginWithGoogle().catch(() => setAuthModalOpen(true))}
              className="yellow-btn w-full py-3.5 rounded-xl text-[#0D0704] font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg"
            >
              <LogIn className="w-4 h-4" />
              <span>Sign In as Director</span>
            </button>
            <button
              onClick={() => setAuthModalOpen(true)}
              className="w-full py-2.5 rounded-xl bg-[#1C100A] hover:bg-[#25150E] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <span>Use Email / Password</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const filteredProjects = projects.filter(p => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div id="admin-page-view" className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-24 right-4 sm:right-8 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-[#140C08] border border-emerald-500/50 text-[#F5F1EC] shadow-[0_10px_35px_rgba(0,0,0,0.85)] animate-in fade-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage.text}</span>
          <button 
            onClick={() => setToastMessage(null)}
            className="p-1 text-[#B8ACA3] hover:text-[#F5F1EC] ml-2"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {projectToDelete && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => !isDeleting && setProjectToDelete(null)}
        >
          <div 
            className="relative w-full max-w-md bg-[#140C08] border border-red-500/40 rounded-3xl p-6 sm:p-8 space-y-5 shadow-[0_20px_60px_rgba(0,0,0,0.95)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-14 h-14 rounded-2xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="font-heading text-xl font-bold text-[#F5F1EC]">
                Delete Project?
              </h3>
              <p className="text-xs text-[#B8ACA3] leading-relaxed">
                Are you sure you want to permanently delete <strong className="text-[#F5F1EC]">"{projectToDelete.title}"</strong>? This will remove the project from the public website, agency portfolio, and persistent cloud storage.
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setProjectToDelete(null)}
                className="flex-1 py-3 rounded-xl bg-[#1C100A] hover:bg-[#25150E] border border-white/10 text-xs font-semibold text-[#B8ACA3] hover:text-[#F5F1EC] transition-colors cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleDeleteConfirm}
                className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-lg shadow-red-950"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Permanently</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Admin Bar */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-[#140C08] via-[#1C100A] to-[#140C08] border border-[#FF6A00]/30 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#FF6A00]/20 border border-[#FF6A00]/40 flex items-center justify-center text-[#FFB347]">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-heading text-xl font-bold text-[#F5F1EC]">
                UPTODATE Control Center
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704]">
                DIRECTOR ADMIN
              </span>
            </div>
            <p className="text-xs text-[#B8ACA3]">
              Agency Directors: <span className="font-mono text-[#F5F1EC]">sriramjaihanuman369@gmail.com</span> & <span className="font-mono text-[#F5F1EC]">jasminnmayl@gmail.com</span>
            </p>
          </div>
        </div>

        {/* Tab Switcher & Export */}
        <div className="flex items-center flex-wrap gap-2">
          <button
            id="admin-export-backup-btn"
            onClick={handleExportProjectsBackup}
            title="Download JSON backup of all current live projects"
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-[#1C100A] border border-[#FF6A00]/30 text-[#FFB347] hover:bg-[#FF6A00]/15 flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>Export Projects JSON</span>
          </button>

          <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-[#140C08] border border-[#FF6A00]/20 self-start md:self-auto">
            <button
              id="admin-tab-projects"
              onClick={() => setActiveTab('projects')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'projects'
                  ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-black shadow'
                  : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
              }`}
            >
              Projects ({projects.length})
            </button>
            <button
              id="admin-tab-bookings"
              onClick={() => setActiveTab('bookings')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'bookings'
                  ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-black shadow'
                  : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
              }`}
            >
              Demo Bookings ({demoBookings.length})
            </button>
            <button
              id="admin-tab-enquiries"
              onClick={() => setActiveTab('enquiries')}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeTab === 'enquiries'
                  ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] font-black shadow'
                  : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
              }`}
            >
              Inquiries ({contactEnquiries.length})
            </button>
          </div>
        </div>
      </div>

      {/* 1. PROJECTS TAB */}
      {activeTab === 'projects' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            
            {/* Search filter */}
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-[#FFB347] absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Filter projects by title..."
                className="w-full pl-10 pr-4 py-2 rounded-xl bg-[#140C08] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
              />
            </div>

            <button
              id="admin-add-new-project-btn"
              onClick={handleOpenAdd}
              className="yellow-btn w-full sm:w-auto px-6 py-2.5 rounded-xl text-xs font-black text-[#0D0704] flex items-center justify-center gap-2 cursor-pointer uppercase tracking-wider shadow-md"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Add New Project</span>
            </button>
          </div>

          {/* Add / Edit Form */}
          {isAdding && (
            <div 
              ref={formRef}
              id="admin-project-form" 
              className="p-6 sm:p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/40 shadow-2xl space-y-6 animate-in fade-in duration-300"
            >
              <div className="flex items-center justify-between border-b border-[#FF6A00]/15 pb-4">
                <div className="flex items-center gap-2.5">
                  <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider ${
                    editingProject ? 'bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/40' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  }`}>
                    {editingProject ? 'EDITING PROJECT' : 'NEW PROJECT'}
                  </span>
                  <h3 className="font-heading text-lg sm:text-xl font-bold text-[#F5F1EC]">
                    {editingProject ? editingProject.title : 'Create New Agency Project'}
                  </h3>
                </div>
                <button 
                  onClick={() => { setIsAdding(false); setEditingProject(null); }} 
                  className="p-2 text-[#B8ACA3] hover:text-[#F5F1EC] rounded-xl hover:bg-[#1C100A]"
                  title="Close form"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {error && (
                <div className="p-3 rounded-xl bg-red-500/20 text-red-300 text-xs border border-red-500/30 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{error}</span>
                </div>
              )}

              <form onSubmit={handleFormSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Title *</label>
                    <input
                      type="text"
                      required
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      placeholder="e.g. AURA: Autonomous AI Fashion"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Category *</label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as any)}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                    >
                      <option value="ai video">AI Video</option>
                      <option value="website">Website</option>
                      <option value="branding">Branding</option>
                      <option value="ugc video">UGC Video</option>
                      <option value="digital marketing">Digital Marketing</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Website URL (Optional)</label>
                    <input
                      type="url"
                      value={websiteUrl}
                      onChange={(e) => setWebsiteUrl(e.target.value)}
                      placeholder="https://clientbrand.com"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Results Metric</label>
                    <input
                      type="text"
                      value={results}
                      onChange={(e) => setResults(e.target.value)}
                      placeholder="+340% ROAS or 4.8M Views"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                    />
                  </div>
                </div>

                {/* Media Section: Thumbnail & Video Upload via File Explorer */}
                <div className="p-4 sm:p-5 rounded-2xl bg-[#0D0704] border border-[#FF6A00]/25 space-y-4">
                  <div className="flex items-center justify-between border-b border-[#FF6A00]/15 pb-2.5">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-[#FF6A00]/20 border border-[#FF6A00]/40 flex items-center justify-center text-[#FFB347]">
                        <FolderGit2 className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <h4 className="font-heading text-xs sm:text-sm font-bold text-[#F5F1EC] uppercase tracking-wide">
                          Media Assets (File Explorer & Cloud Storage)
                        </h4>
                        <p className="text-[10px] text-[#B8ACA3]">
                          Upload videos & thumbnails from your computer. Videos are persistently synced to the cloud database for public website playback.
                        </p>
                      </div>
                    </div>
                    <span className="hidden sm:inline-flex px-2.5 py-0.5 rounded-full text-[9px] font-mono bg-[#FF6A00]/10 text-[#FFB347] border border-[#FF6A00]/30">
                      PERSISTENT CLOUD
                    </span>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {/* Thumbnail File Uploader */}
                    <ThumbnailFileUploader
                      value={thumbnail}
                      onChange={setThumbnail}
                      required
                    />

                    {/* Video File Uploader */}
                    <VideoFileUploader
                      value={videoUrl}
                      onChange={setVideoUrl}
                      videoType={videoType}
                      onTypeChange={setVideoType}
                      aspectRatio={aspectRatio}
                      onAspectRatioChange={setAspectRatio}
                      posterImage={thumbnail}
                      onThumbnailGenerated={(captured) => {
                        setThumbnail((curr) => curr ? curr : captured);
                      }}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Tags (comma separated)</label>
                  <input
                    type="text"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="AI Video, Commercial Reel, 3D, High Conversion"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Description *</label>
                  <textarea
                    rows={3}
                    required
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe the campaign, client, visual aesthetic, and deliverables..."
                    className="w-full p-3 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                  />
                </div>

                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="checkbox"
                    id="featured-check"
                    checked={featured}
                    onChange={(e) => setFeatured(e.target.checked)}
                    className="rounded text-[#FF6A00] focus:ring-[#FF6A00] cursor-pointer"
                  />
                  <label htmlFor="featured-check" className="text-xs text-[#B8ACA3] cursor-pointer">
                    Feature on Home Page Featured Projects Section
                  </label>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-[#FF6A00]/15">
                  <button
                    type="button"
                    onClick={() => { setIsAdding(false); setEditingProject(null); }}
                    className="px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/20 text-xs text-[#B8ACA3] hover:text-[#F5F1EC] cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={saving}
                    className="yellow-btn px-6 py-2.5 rounded-xl text-xs font-black text-[#0D0704] uppercase tracking-wider shadow-md flex items-center gap-2 cursor-pointer"
                  >
                    {saving && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                    <span>{saving ? 'Saving...' : editingProject ? 'Save Changes' : 'Publish Project'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* Table of all projects */}
          <div className="rounded-3xl border border-[#FF6A00]/25 bg-[#140C08] overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#FF6A00]/20 bg-[#1C100A] text-[#B8ACA3] uppercase font-mono tracking-wider">
                    <th className="py-4 px-6">Project</th>
                    <th className="py-4 px-4">Category</th>
                    <th className="py-4 px-4">Aspect</th>
                    <th className="py-4 px-4">Featured</th>
                    <th className="py-4 px-4">Results</th>
                    <th className="py-4 px-6 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#FF6A00]/15 text-[#B8ACA3]">
                  {filteredProjects.map((proj) => (
                    <tr key={proj.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-4 px-6 flex items-center gap-3">
                        <img src={proj.thumbnail} alt="" className="w-12 h-8 rounded-lg object-cover bg-black shrink-0 border border-white/10" />
                        <div>
                          <p className="font-bold text-[#F5F1EC] text-sm line-clamp-1">{proj.title}</p>
                          <p className="text-[11px] text-[#B8ACA3]/70 line-clamp-1">{proj.description}</p>
                        </div>
                      </td>
                      <td className="py-4 px-4 uppercase font-mono text-[10px] text-[#FFB347]">
                        {proj.category}
                      </td>
                      <td className="py-4 px-4 uppercase font-mono text-[10px] text-[#B8ACA3]">
                        {proj.aspectRatio || 'Auto'}
                      </td>
                      <td className="py-4 px-4">
                        <button
                          onClick={() => handleToggleFeatured(proj)}
                          className={`p-1.5 rounded-lg flex items-center gap-1 transition-colors cursor-pointer ${
                            proj.featured ? 'bg-[#FF6A00]/20 text-[#FFB347]' : 'bg-[#1C100A] text-[#B8ACA3]/50 hover:text-[#B8ACA3]'
                          }`}
                        >
                          <Star className={`w-3.5 h-3.5 ${proj.featured ? 'fill-current' : ''}`} />
                          <span className="text-[10px] font-mono">{proj.featured ? 'Yes' : 'No'}</span>
                        </button>
                      </td>
                      <td className="py-4 px-4 font-mono text-[11px] text-[#B8ACA3]">
                        {proj.results || '—'}
                      </td>
                      <td className="py-4 px-6 text-right space-x-2 whitespace-nowrap">
                        <button
                          onClick={() => setActiveProjectModal(proj)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#1C100A] hover:bg-[#25150E] border border-[#FF6A00]/20 text-[#F5F1EC] cursor-pointer"
                        >
                          Preview
                        </button>
                        <button
                          onClick={() => handleOpenEdit(proj)}
                          className="px-2.5 py-1.5 rounded-lg bg-[#FF6A00]/20 text-[#FFB347] hover:bg-[#FF6A00]/30 font-semibold cursor-pointer"
                        >
                          Edit
                        </button>
                        <button
                          onClick={() => setProjectToDelete({ id: proj.id, title: proj.title })}
                          className="px-2.5 py-1.5 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 font-semibold cursor-pointer"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))}
                  {filteredProjects.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-12 text-center text-[#B8ACA3]/60">
                        No projects match your filter.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. DEMO BOOKINGS TAB */}
      {activeTab === 'bookings' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-xl font-bold text-[#F5F1EC]">
              Free Demo Call Bookings ({demoBookings.length})
            </h3>
            <span className="text-xs text-[#B8ACA3]">
              Agency Direct Phone: <span className="font-mono text-[#FFB347] font-bold">962511181</span>
            </span>
          </div>

          <div className="rounded-3xl border border-[#FF6A00]/25 bg-[#140C08] overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-[#FF6A00]/20 bg-[#1C100A] text-[#B8ACA3] uppercase font-mono tracking-wider">
                    <th className="py-4 px-6">Client Name</th>
                    <th className="py-4 px-4">Email</th>
                    <th className="py-4 px-4">Contact Number</th>
                    <th className="py-4 px-4">Status</th>
                    <th className="py-4 px-6">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#FF6A00]/15 text-[#B8ACA3]">
                  {demoBookings.map((b) => (
                    <tr key={b.id} className="hover:bg-white/[0.02]">
                      <td className="py-4 px-6 font-bold text-[#F5F1EC] text-sm">{b.name}</td>
                      <td className="py-4 px-4 font-mono text-[#B8ACA3]">{b.email}</td>
                      <td className="py-4 px-4 font-mono font-bold text-[#FFB347]">
                        <a href={`tel:${b.contactNumber}`} className="hover:underline flex items-center gap-1">
                          <PhoneCall className="w-3 h-3" />
                          {b.contactNumber}
                        </a>
                      </td>
                      <td className="py-4 px-4">
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                          {b.status || 'Confirmed'}
                        </span>
                      </td>
                      <td className="py-4 px-6 text-[#B8ACA3]/70 font-mono text-[11px]">
                        {new Date(b.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                  {demoBookings.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-[#B8ACA3]/60">
                        No demo bookings logged yet.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. CONTACT INQUIRIES TAB */}
      {activeTab === 'enquiries' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-heading text-xl font-bold text-[#F5F1EC]">
              Project Inquiries ({contactEnquiries.length})
            </h3>
          </div>

          <div className="space-y-4">
            {contactEnquiries.map((enq) => (
              <div
                key={enq.id}
                className="p-6 rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 space-y-3 shadow-lg"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-[#FF6A00]/15 pb-3">
                  <div>
                    <h4 className="font-heading font-bold text-base text-[#F5F1EC] flex items-center gap-2">
                      <span>{enq.name}</span>
                      {enq.companyName && (
                        <span className="text-xs font-normal text-[#B8ACA3]">({enq.companyName})</span>
                      )}
                    </h4>
                    <p className="text-xs text-[#B8ACA3] font-mono mt-0.5">
                      {enq.email} • <span className="text-[#FFB347] font-bold">{enq.phone}</span>
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-3 py-1 rounded-full text-[10px] font-mono bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/30">
                      {enq.service}
                    </span>
                    <span className="text-[11px] font-mono text-[#B8ACA3]/60">
                      {new Date(enq.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-[#B8ACA3] leading-relaxed whitespace-pre-wrap">
                  {enq.message}
                </p>

                <div className="pt-2 flex items-center gap-3">
                  <a
                    href={`tel:${enq.phone}`}
                    className="px-3 py-1.5 rounded-lg bg-[#FF6A00]/20 text-[#FFB347] hover:bg-[#FF6A00]/30 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <PhoneCall className="w-3 h-3" />
                    <span>Call Client ({enq.phone})</span>
                  </a>
                  <a
                    href={`https://wa.me/${enq.phone.replace(/\D/g, '')}?text=Hi%20${encodeURIComponent(enq.name)},%20this%20is%20UPTODATE%20AI%20Creative%20Agency!`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-[#25D366]/20 text-emerald-400 hover:bg-[#25D366]/30 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <span>WhatsApp</span>
                  </a>
                  <a
                    href={`mailto:${enq.email}?subject=UPTODATE%20Project%20Inquiry%20Response`}
                    className="px-3 py-1.5 rounded-lg bg-[#1C100A] text-[#B8ACA3] hover:text-[#F5F1EC] border border-[#FF6A00]/20 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Mail className="w-3 h-3" />
                    <span>Email</span>
                  </a>
                </div>
              </div>
            ))}
            {contactEnquiries.length === 0 && (
              <div className="p-12 text-center text-[#B8ACA3]/60 bg-[#140C08] rounded-3xl border border-[#FF6A00]/20">
                No inquiries received yet.
              </div>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
