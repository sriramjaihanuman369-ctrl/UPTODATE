import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Search, 
  Filter, 
  ArrowUpDown, 
  Sparkles, 
  PlusCircle, 
  Volume2,
  TrendingUp,
  ArrowRight,
  HelpCircle
} from 'lucide-react';
import { ProjectCardVideoPreview } from '../components/ProjectCardVideoPreview';
import { Card3D } from '../components/Card3D';

export const ProjectsView: React.FC = () => {
  const { 
    projects, 
    activeSearchQuery, 
    setActiveSearchQuery, 
    selectedCategory, 
    setSelectedCategory, 
    setActiveProjectModal,
    setCurrentPage,
    isAdmin
  } = useApp();

  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [hoveredId, setHoveredId] = useState<string | null>(null);

  const categories = [
    { label: 'All Projects', value: 'all' },
    { label: 'AI Videos', value: 'ai video' },
    { label: 'Websites', value: 'website' },
    { label: 'Branding', value: 'branding' },
    { label: 'UGC Video', value: 'ugc video' },
    { label: 'Digital Marketing', value: 'digital marketing' }
  ];

  const filteredAndSortedProjects = useMemo(() => {
    let result = [...projects];

    // Filter by category
    if (selectedCategory && selectedCategory !== 'all') {
      result = result.filter(p => p.category.toLowerCase() === selectedCategory.toLowerCase());
    }

    // Filter by search query
    if (activeSearchQuery.trim()) {
      const q = activeSearchQuery.toLowerCase();
      result = result.filter(p => 
        p.title.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        (p.tags && p.tags.some(t => t.toLowerCase().includes(q)))
      );
    }

    // Sort by date
    result.sort((a, b) => {
      const timeA = new Date(a.createdAt).getTime();
      const timeB = new Date(b.createdAt).getTime();
      return sortOrder === 'newest' ? timeB - timeA : timeA - timeB;
    });

    return result;
  }, [projects, selectedCategory, activeSearchQuery, sortOrder]);

  const handleMouseEnter = (id: string) => {
    setHoveredId(id);
  };

  const handleMouseLeave = () => {
    setHoveredId(null);
  };

  return (
    <div id="projects-page-view" className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Top Section */}
      <div className="mb-12 space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-[11px] font-mono font-semibold text-[#FFB347] uppercase tracking-wider mb-3">
              <Sparkles className="w-3 h-3" />
              <span>Agency Portfolio & Case Studies</span>
            </div>
            <h1 className="font-heading text-4xl sm:text-6xl font-extrabold text-[#F5F1EC] tracking-tight">
              Selected Works
            </h1>
            <p className="text-[#B8ACA3] text-sm sm:text-base max-w-2xl mt-2">
              Explore our commercial AI videos, interactive spatial websites, performance campaigns, and transformative brand identities.
            </p>
          </div>

          <div className="flex items-center flex-wrap gap-2.5 self-start md:self-auto">
            {/* Autoplay & Audio Indicator */}
            <div className="px-3 py-1.5 rounded-full bg-[#140C08] border border-[#FF6A00]/30 text-[11px] font-mono text-[#FFB347] flex items-center gap-2 shadow-sm">
              <span className="w-2 h-2 rounded-full bg-[#FF6A00] animate-pulse"></span>
              <span>Autoplay: <strong className="text-[#F5F1EC]">Muted by default</strong></span>
              <Volume2 className="w-3.5 h-3.5 text-[#FF6A00]" />
            </div>

            {isAdmin && (
              <button
                id="projects-page-add-btn"
                onClick={() => setCurrentPage('admin')}
                className="yellow-btn px-5 py-2.5 rounded-full text-xs font-black text-[#0D0704] flex items-center gap-2 cursor-pointer uppercase tracking-wider shadow-md"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Add New Project (Admin)</span>
              </button>
            )}
          </div>
        </div>

        {/* Search, Filter & Sort Controls */}
        <div className="p-4 rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 shadow-xl space-y-4">
          
          <div className="flex flex-col md:flex-row items-center gap-4">
            
            {/* Search Bar */}
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-[#FFB347] absolute left-4 top-1/2 -translate-y-1/2" />
              <input
                id="projects-search-input"
                type="text"
                value={activeSearchQuery}
                onChange={(e) => setActiveSearchQuery(e.target.value)}
                placeholder="Search case studies by title, tag, or keyword..."
                className="w-full pl-11 pr-4 py-3 rounded-2xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] placeholder-[#B8ACA3]/60 text-sm focus:outline-none focus:border-[#FF6A00]"
              />
              {activeSearchQuery && (
                <button
                  id="clear-projects-search-btn"
                  onClick={() => setActiveSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-mono text-[#B8ACA3] hover:text-[#F5F1EC]"
                >
                  CLEAR
                </button>
              )}
            </div>

            {/* Sort Option: Newest / Oldest */}
            <div className="flex items-center gap-2 w-full md:w-auto self-end md:self-auto">
              <span className="text-xs text-[#B8ACA3] flex items-center gap-1 shrink-0 font-mono">
                <ArrowUpDown className="w-3.5 h-3.5" /> Sort:
              </span>
              <div className="flex p-1 bg-[#1C100A] rounded-2xl border border-[#FF6A00]/20 w-full md:w-auto">
                <button
                  id="sort-newest-btn"
                  onClick={() => setSortOrder('newest')}
                  className={`flex-1 md:flex-initial px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    sortOrder === 'newest'
                      ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] shadow'
                      : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
                  }`}
                >
                  Newest
                </button>
                <button
                  id="sort-oldest-btn"
                  onClick={() => setSortOrder('oldest')}
                  className={`flex-1 md:flex-initial px-4 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    sortOrder === 'oldest'
                      ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] shadow'
                      : 'text-[#B8ACA3] hover:text-[#F5F1EC]'
                  }`}
                >
                  Oldest
                </button>
              </div>
            </div>

          </div>

          {/* Filter Option Buttons */}
          <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#FF6A00]/15">
            <span className="text-xs text-[#B8ACA3]/70 font-mono uppercase tracking-wider mr-1 flex items-center gap-1">
              <Filter className="w-3 h-3 text-[#FF6A00]" /> Filter:
            </span>
            {categories.map((cat) => (
              <button
                key={cat.value}
                id={`filter-cat-${cat.value.replace(/\s+/g, '-')}`}
                onClick={() => setSelectedCategory(cat.value)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-all ${
                  selectedCategory === cat.value
                    ? 'bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/60 font-semibold shadow-[0_0_15px_rgba(255,106,0,0.2)]'
                    : 'bg-[#1C100A] text-[#B8ACA3] hover:text-[#F5F1EC] hover:bg-[#25150E] border border-[#FF6A00]/20'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

        </div>
      </div>

      {/* Projects Grid */}
      {filteredAndSortedProjects.length === 0 ? (
        <div id="no-projects-found" className="text-center py-20 bg-[#140C08] rounded-3xl border border-[#FF6A00]/20 p-8 space-y-4">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#1C100A] flex items-center justify-center text-[#B8ACA3]">
            <Search className="w-8 h-8" />
          </div>
          <h3 className="font-heading text-xl font-bold text-[#F5F1EC]">No projects found matching your criteria</h3>
          <p className="text-sm text-[#B8ACA3] max-w-md mx-auto">
            Try resetting your search query or selecting a different category filter.
          </p>
          <button
            id="reset-filters-btn"
            onClick={() => {
              setActiveSearchQuery('');
              setSelectedCategory('all');
            }}
            className="px-6 py-2.5 rounded-full bg-[#1C100A] hover:bg-[#25150E] border border-[#FF6A00]/30 text-xs font-semibold text-[#F5F1EC] transition-colors"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 lg:gap-8 items-start">
          {filteredAndSortedProjects.map((proj, index) => {
            const isHovered = hoveredId === proj.id;
            const isReel = proj.aspectRatio === '9:16' || proj.videoUrl?.includes('/shorts/');
            const isSquare = proj.aspectRatio === '1:1';

            return (
              <Card3D
                key={proj.id}
                delay={(index % 3) * 0.06}
                intensity={8}
                enableGlow={true}
                className="h-full"
              >
                <div
                  id={`project-card-${proj.id}`}
                  onMouseEnter={() => handleMouseEnter(proj.id)}
                  onMouseLeave={() => handleMouseLeave()}
                  onClick={() => setActiveProjectModal(proj)}
                  className="h-full group relative rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 overflow-hidden cursor-pointer hover:border-[#FF6A00]/60 transition-all duration-300 hover:shadow-[0_12px_40px_rgba(255,106,0,0.18)] flex flex-col justify-between"
                >
                  {/* Auto-playing Muted Video Card Preview */}
                  <ProjectCardVideoPreview
                    project={proj}
                    isHovered={isHovered}
                  />

                  {/* Content */}
                  <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                    <div>
                      <h3 className="font-heading font-bold text-lg text-[#F5F1EC] group-hover:text-[#FFB347] transition-colors line-clamp-1 mb-2">
                        {proj.title}
                      </h3>
                      <p className="text-[#B8ACA3] text-xs line-clamp-2 leading-relaxed">
                        {proj.description}
                      </p>
                    </div>

                    {/* Results Metric */}
                    {proj.results && (
                      <div className="p-2.5 rounded-xl bg-[#FF6A00]/10 border border-[#FF6A00]/20 flex items-center gap-2 text-xs">
                        <TrendingUp className="w-3.5 h-3.5 text-[#FF6A00] shrink-0" />
                        <span className="font-mono text-[#FFB347] text-[11px] font-medium truncate">
                          {proj.results}
                        </span>
                      </div>
                    )}

                    {/* Card Footer */}
                    <div className="pt-3 border-t border-[#FF6A00]/15 flex items-center justify-between text-xs">
                      <span className="text-[#B8ACA3]/70 font-mono text-[11px]">
                        {proj.tags && proj.tags.length > 0 ? `#${proj.tags[0]}` : 'Case Study'}
                      </span>
                      <span className="text-[#FFB347] group-hover:text-[#F5F1EC] flex items-center gap-1 font-semibold text-xs transition-colors">
                        View Details <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                      </span>
                    </div>
                  </div>
                </div>
              </Card3D>
            );
          })}
        </div>
      )}

      {/* End with: “Still have questions?” → Contact US */}
      <div id="projects-page-footer-cta" className="mt-20 p-8 sm:p-12 rounded-3xl bg-gradient-to-r from-[#140C08] to-[#1C100A] border border-[#FF6A00]/30 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
        <div className="space-y-1 text-center sm:text-left">
          <div className="flex items-center justify-center sm:justify-start gap-2 text-[#FFB347] text-xs font-mono uppercase tracking-wider font-semibold">
            <HelpCircle className="w-4 h-4" />
            <span>Custom Creative Consultation</span>
          </div>
          <h3 className="font-heading text-2xl sm:text-3xl font-bold text-[#F5F1EC]">
            Still have questions?
          </h3>
          <p className="text-[#B8ACA3] text-sm max-w-md">
            Speak directly with our technology directors to scope your video, website, or rebrand.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            id="projects-contact-us-btn"
            onClick={() => setCurrentPage('contact')}
            className="yellow-btn px-6 py-3 rounded-full text-xs font-black text-[#0D0704] flex items-center gap-2 cursor-pointer uppercase tracking-wider shadow-md"
          >
            <span>Contact Us</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

    </div>
  );
};
