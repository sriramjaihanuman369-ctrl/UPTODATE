import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Clock, 
  Zap, 
  ShieldCheck, 
  TrendingUp, 
  Award, 
  Check, 
  X, 
  Edit3, 
  Save, 
  Plus, 
  Trash2, 
  ArrowRight,
  Sliders,
  DollarSign
} from 'lucide-react';

export const AboutView: React.FC = () => {
  const { aboutData, updateAbout, isAdmin, setDemoModalOpen } = useApp();

  const [isEditing, setIsEditing] = useState(false);
  const [whyWeStarted, setWhyWeStarted] = useState(aboutData.whyWeStarted);
  const [coreValues, setCoreValues] = useState(aboutData.coreValues);
  const [saving, setSaving] = useState(false);

  const handleSaveAbout = async () => {
    try {
      setSaving(true);
      await updateAbout({
        whyWeStarted,
        coreValues
      });
      setSaving(false);
      setIsEditing(false);
    } catch (err) {
      console.error('Error saving about content:', err);
      setSaving(false);
      alert('Failed to save changes.');
    }
  };

  const handleAddCoreValue = () => {
    setCoreValues([
      ...coreValues,
      {
        title: 'New Studio Principle',
        description: 'Detailing how our creative engineers optimize brand outcomes.',
        icon: 'sparkles'
      }
    ]);
  };

  const handleRemoveCoreValue = (index: number) => {
    setCoreValues(coreValues.filter((_, i) => i !== index));
  };

  const handleUpdateCoreValue = (index: number, field: 'title' | 'description', value: string) => {
    const updated = [...coreValues];
    updated[index][field] = value;
    setCoreValues(updated);
  };

  // Visual Comparison Data: AI Production vs Traditional Production
  const comparisonItems = [
    {
      metric: 'Production Time',
      traditional: '4 to 8 Weeks per commercial',
      aiStudio: '48 hrs to 5 days end-to-end',
      winner: 'ai'
    },
    {
      metric: 'Scalability',
      traditional: '1-2 hero videos; costly physical shoots',
      aiStudio: 'Unlimited multi-variant hooks & aspect ratios',
      winner: 'ai'
    },
    {
      metric: 'Revision Speed',
      traditional: 'Days to weeks; re-shoots & overtime fees',
      aiStudio: 'Real-time neural re-rendering in hours',
      winner: 'ai'
    },
    {
      metric: 'Visual Quality',
      traditional: 'Dependent on crew, weather & location constraints',
      aiStudio: 'Unconstrained 4K photorealism & CGI physics',
      winner: 'ai'
    },
    {
      metric: 'Cost / Starting Tier',
      traditional: '$25,000 – $100,000+ per campaign',
      aiStudio: 'To Know the Price contact us (Custom deliverables)',
      winner: 'ai'
    }
  ];

  return (
    <div id="about-page-view" className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-24">
      
      {/* Hero / Header */}
      <div className="space-y-6 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-xs font-mono font-semibold text-[#FFB347] uppercase tracking-wider">
          <Sparkles className="w-3 h-3" />
          <span>About UPTODATE Studio</span>
        </div>

        <h1 className="font-heading text-4xl sm:text-6xl font-extrabold text-[#F5F1EC] tracking-tight leading-[1.1]">
          We Build The Visual Culture of Tomorrow.
        </h1>

        <p className="text-[#B8ACA3] text-base sm:text-lg leading-relaxed">
          UPTODATE is an elite AI creative studio engineering cinematic digital campaigns, spatial websites, and enduring brands at the speed of modern internet culture.
        </p>

        {/* Admin Controls Banner */}
        {isAdmin && (
          <div className="p-4 rounded-2xl bg-[#FF6A00]/10 border border-[#FF6A00]/30 flex items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs font-mono text-[#FFB347]">
              <Sliders className="w-4 h-4" />
              <span>Admin Mode: You can edit or add sections directly on this page.</span>
            </div>
            {isEditing ? (
              <div className="flex items-center gap-2">
                <button
                  id="cancel-edit-about-btn"
                  onClick={() => setIsEditing(false)}
                  className="px-3 py-1.5 rounded-lg bg-[#1C100A] hover:bg-[#25150E] border border-[#FF6A00]/20 text-xs text-[#F5F1EC]"
                >
                  Cancel
                </button>
                <button
                  id="save-edit-about-btn"
                  onClick={handleSaveAbout}
                  disabled={saving}
                  className="yellow-btn px-4 py-1.5 rounded-lg text-xs font-black text-[#0D0704] flex items-center gap-1.5 uppercase tracking-wider shadow-md"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>{saving ? 'Saving...' : 'Save Changes'}</span>
                </button>
              </div>
            ) : (
              <button
                id="edit-about-section-btn"
                onClick={() => setIsEditing(true)}
                className="px-4 py-1.5 rounded-lg bg-[#FF6A00]/20 hover:bg-[#FF6A00]/30 text-[#FFB347] text-xs font-bold border border-[#FF6A00]/40 flex items-center gap-1.5"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit About Sections</span>
              </button>
            )}
          </div>
        )}
      </div>

      {/* 1. WHY WE STARTED */}
      <section id="why-we-started-section" className="relative rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 p-8 sm:p-12 overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#FF6A00]/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="max-w-4xl space-y-6 relative z-10">
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#FFB347] font-bold">
            <span className="w-2 h-2 rounded-full bg-[#FF6A00]"></span>
            <span>Origin Manifesto</span>
          </div>

          <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-[#F5F1EC] tracking-tight">
            Why We Started
          </h2>

          {isEditing ? (
            <textarea
              id="edit-why-we-started"
              rows={6}
              value={whyWeStarted}
              onChange={(e) => setWhyWeStarted(e.target.value)}
              className="w-full p-4 rounded-2xl bg-[#1C100A] border border-[#FF6A00]/50 text-[#F5F1EC] text-sm focus:outline-none focus:ring-1 focus:ring-[#FF6A00]"
            />
          ) : (
            <div className="text-[#B8ACA3] text-sm sm:text-base leading-relaxed space-y-4 whitespace-pre-line font-normal">
              {aboutData.whyWeStarted}
            </div>
          )}

          {/* Quick Metrics Bar */}
          {aboutData.stats && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-6 border-t border-[#FF6A00]/15">
              {aboutData.stats.map((stat, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-[#1C100A] border border-[#FF6A00]/20">
                  <p className="font-heading font-extrabold text-2xl sm:text-3xl text-[#FFB347] font-mono">
                    {stat.value}
                  </p>
                  <p className="text-xs text-[#B8ACA3] mt-1">{stat.label}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 2. CORE VALUES */}
      <section id="core-values-section" className="space-y-10">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-[#FFB347] font-bold mb-2">
              <span className="w-2 h-2 rounded-full bg-[#FF6A00]"></span>
              <span>Our Creative DNA</span>
            </div>
            <h2 className="font-heading text-3xl sm:text-4xl font-extrabold text-[#F5F1EC] tracking-tight">
              Core Values
            </h2>
          </div>

          {isEditing && (
            <button
              id="add-core-value-btn"
              onClick={handleAddCoreValue}
              className="px-4 py-2 rounded-xl bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/40 text-xs font-bold flex items-center gap-1.5 self-start"
            >
              <Plus className="w-4 h-4" />
              <span>Add Core Value</span>
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {(isEditing ? coreValues : aboutData.coreValues).map((val, idx) => (
            <div
              key={idx}
              className="p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 hover:border-[#FF6A00]/60 transition-all duration-300 space-y-3 relative group"
            >
              {isEditing && (
                <button
                  onClick={() => handleRemoveCoreValue(idx)}
                  className="absolute top-4 right-4 p-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30"
                  title="Remove Core Value"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}

              <div className="w-10 h-10 rounded-xl bg-[#FF6A00]/15 border border-[#FF6A00]/30 flex items-center justify-center text-[#FFB347] mb-2">
                <Sparkles className="w-5 h-5" />
              </div>

              {isEditing ? (
                <div className="space-y-2">
                  <input
                    type="text"
                    value={val.title}
                    onChange={(e) => handleUpdateCoreValue(idx, 'title', e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg bg-[#1C100A] border border-[#FF6A00]/40 text-[#F5F1EC] font-bold text-base focus:outline-none"
                  />
                  <textarea
                    rows={3}
                    value={val.description}
                    onChange={(e) => handleUpdateCoreValue(idx, 'description', e.target.value)}
                    className="w-full p-3 rounded-lg bg-[#1C100A] border border-[#FF6A00]/40 text-[#B8ACA3] text-xs focus:outline-none"
                  />
                </div>
              ) : (
                <>
                  <h3 className="font-heading font-bold text-xl text-[#F5F1EC] group-hover:text-[#FFB347] transition-colors">
                    {val.title}
                  </h3>
                  <p className="text-[#B8ACA3] text-sm leading-relaxed">
                    {val.description}
                  </p>
                </>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* 3. VISUAL COMPARISON SECTION */}
      {/* AI Production vs Traditional Production */}
      <section id="comparison-section" className="space-y-10">
        <div className="text-center max-w-2xl mx-auto space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-xs font-mono font-semibold text-[#FFB347] uppercase tracking-wider">
            <Zap className="w-3.5 h-3.5" />
            <span>The Paradigm Shift</span>
          </div>
          <h2 className="font-heading text-3xl sm:text-5xl font-extrabold text-[#F5F1EC] tracking-tight">
            AI Production vs Traditional Production
          </h2>
          <p className="text-[#B8ACA3] text-sm sm:text-base">
            Why leading brands and CMOs are migrating their creative pipelines to UPTODATE's generative AI workflow.
          </p>
        </div>

        {/* Comparison Table */}
        <div className="overflow-hidden rounded-3xl border border-[#FF6A00]/25 bg-[#140C08] shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#FF6A00]/20 bg-[#1C100A]">
                  <th className="py-5 px-6 font-mono text-xs uppercase tracking-widest text-[#B8ACA3]">
                    Dimension
                  </th>
                  <th className="py-5 px-6 font-mono text-xs uppercase tracking-widest text-[#B8ACA3]">
                    Traditional Agency / Shoot
                  </th>
                  <th className="py-5 px-6 font-mono text-xs uppercase tracking-widest text-[#FFB347] bg-[#FF6A00]/10 border-l border-[#FF6A00]/25">
                    UPTODATE (AI Studio)
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#FF6A00]/15 text-sm">
                {comparisonItems.map((row, idx) => (
                  <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                    
                    {/* Dimension */}
                    <td className="py-4 px-6 font-heading font-bold text-[#F5F1EC] whitespace-nowrap">
                      {row.metric}
                    </td>

                    {/* Traditional */}
                    <td className="py-4 px-6 text-[#B8ACA3]">
                      <div className="flex items-center gap-2">
                        <X className="w-4 h-4 text-red-400/80 shrink-0" />
                        <span>{row.traditional}</span>
                      </div>
                    </td>

                    {/* AI Studio (UPTODATE) */}
                    <td className="py-4 px-6 font-medium text-[#F5F1EC] bg-[#FF6A00]/[0.05] border-l border-[#FF6A00]/25">
                      <div className="flex items-center gap-2 text-[#FFB347] font-semibold">
                        <Check className="w-4 h-4 text-[#FF6A00] shrink-0" />
                        <span>{row.aiStudio}</span>
                      </div>
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Bottom Callout */}
        <div className="p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/40 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl">
          <div>
            <h4 className="font-display text-xl font-bold text-[#F5F1EC] uppercase">
              Ready to upgrade your brand's creative output?
            </h4>
            <p className="text-[#B8ACA3] text-xs sm:text-sm mt-1">
              To Know the Price contact us or schedule a pilot consultation call.
            </p>
          </div>
          <button
            id="about-book-demo-btn"
            onClick={() => setDemoModalOpen(true)}
            className="yellow-btn px-6 py-3 rounded-full text-xs font-black text-[#0D0704] shrink-0 flex items-center gap-2 cursor-pointer uppercase tracking-wider shadow-md"
          >
            <span>Book Free Demo (962511181)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </section>

    </div>
  );
};
