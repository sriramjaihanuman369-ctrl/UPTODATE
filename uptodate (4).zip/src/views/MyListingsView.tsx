import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { 
  PlusCircle, 
  Trash2, 
  Edit3, 
  ExternalLink, 
  FolderGit2, 
  Video, 
  Image, 
  Sparkles, 
  Check, 
  X,
  Play,
  User,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { Project } from '../types';
import { ThumbnailFileUploader, VideoFileUploader } from '../components/MediaFileUploader';
import { ProjectCardVideoPreview } from '../components/ProjectCardVideoPreview';

export const MyListingsView: React.FC = () => {
  const { 
    user, 
    isAdmin,
    projects, 
    addProject, 
    editProject, 
    removeProject, 
    setAuthModalOpen,
    setActiveProjectModal 
  } = useApp();

  const [isAdding, setIsAdding] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<'ugc video' | 'website' | 'branding' | 'ai video' | 'digital marketing'>('ugc video');
  const [description, setDescription] = useState('');
  const [thumbnail, setThumbnail] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [videoType, setVideoType] = useState<'mp4' | 'youtube' | 'vimeo' | 'drive'>('mp4');
  const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16' | '1:1' | 'auto'>('auto');
  const [websiteUrl, setWebsiteUrl] = useState('');
  const [tags, setTags] = useState('');
  const [results, setResults] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  // Delete modal state
  const [projectToDelete, setProjectToDelete] = useState<{ id: string; title: string } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const formRef = useRef<HTMLDivElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Not logged in guard
  if (!user) {
    return (
      <div id="my-listings-guest-view" className="min-h-[75vh] flex items-center justify-center px-4 pt-28 pb-16">
        <div className="max-w-md w-full p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/30 text-center space-y-5 shadow-2xl">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-[#FF6A00]/20 border border-[#FF6A00]/40 flex items-center justify-center text-[#FFB347]">
            <User className="w-8 h-8" />
          </div>
          <h2 className="font-heading text-2xl font-bold text-[#F5F1EC]">
            Agency Director & Creator Portal
          </h2>
          <p className="text-xs text-[#B8ACA3] leading-relaxed">
            Please sign in with your director credentials to publish or edit projects.
          </p>
          <button
            id="listings-sign-in-prompt-btn"
            onClick={() => setAuthModalOpen(true)}
            className="yellow-btn w-full py-3.5 rounded-xl text-[#0D0704] font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg"
          >
            <span>Sign In to Access Listings</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // If logged in but NOT admin (customer, client, viewer), restrict editing and creation
  if (!isAdmin) {
    return (
      <div id="my-listings-restricted-view" className="min-h-[75vh] flex items-center justify-center px-4 pt-28 pb-16">
        <div className="max-w-md w-full p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/30 text-center space-y-5 shadow-2xl">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-[#FF6A00]/20 border border-[#FF6A00]/40 flex items-center justify-center text-[#FFB347]">
            <User className="w-8 h-8" />
          </div>
          <h2 className="font-heading text-2xl font-bold text-[#F5F1EC]">
            Client View Access Only
          </h2>
          <p className="text-xs text-[#B8ACA3] leading-relaxed">
            You are signed in as <span className="text-[#F5F1EC] font-mono">{user.email}</span>. Projects are editable only by agency directors (sriramjaihanuman369@gmail.com & jasminnmayl@gmail.com). Customers and viewers have browse-only access.
          </p>
          <div className="p-3.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/20 text-xs text-[#B8ACA3] text-left space-y-1">
            <p className="font-semibold text-[#F5F1EC]">Need a project published or updated?</p>
            <p className="text-[#B8ACA3]/70 text-[11px]">Contact us at jasminnmayl@gmail.com or call 962511181 to discuss customized deliverables.</p>
          </div>
        </div>
      </div>
    );
  }

  // When admin is logged in, show ALL projects so every project can be viewed, edited, and deleted
  const userProjects = isAdmin ? projects : projects.filter(p => p.createdBy === user.uid || p.authorEmail === user.email);

  const handleOpenAdd = () => {
    setTitle('');
    setCategory('ugc video');
    setDescription('');
    setThumbnail('');
    setVideoUrl('');
    setVideoType('mp4');
    setAspectRatio('auto');
    setWebsiteUrl('');
    setTags('UGC Video, Creator Ads');
    setResults('+280% Conversions');
    setEditingProject(null);
    setError('');
    setIsAdding(true);

    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleOpenEdit = (proj: Project) => {
    setTitle(proj.title);
    setCategory(proj.category as any);
    setDescription(proj.description);
    setThumbnail(proj.thumbnail);
    setVideoUrl(proj.videoUrl || '');
    setVideoType(proj.videoType || 'mp4');
    setAspectRatio(proj.aspectRatio || 'auto');
    setWebsiteUrl(proj.websiteUrl || '');
    setTags(proj.tags ? proj.tags.join(', ') : '');
    setResults(proj.results || '');
    setEditingProject(proj);
    setError('');
    setIsAdding(true);

    setTimeout(() => {
      formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 100);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!title.trim()) {
      setError('Please provide a project title.');
      return;
    }

    let finalThumbnail = thumbnail.trim();
    if (!finalThumbnail) {
      finalThumbnail = 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&auto=format&fit=crop&q=80';
    }

    try {
      setSaving(true);
      const tagArray = tags.split(',').map(t => t.trim()).filter(Boolean);

      const projectPayload = {
        title: title.trim(),
        category,
        description: description.trim(),
        thumbnail: finalThumbnail,
        videoUrl: videoUrl.trim(),
        videoType,
        aspectRatio,
        websiteUrl: websiteUrl.trim(),
        tags: tagArray,
        results: results.trim()
      };

      if (editingProject) {
        await editProject(editingProject.id, projectPayload);
        showToast(`Project "${title.trim()}" updated successfully!`);
      } else {
        await addProject({
          ...projectPayload,
          featured: false
        });
        showToast(`Project "${title.trim()}" published live!`);
      }

      setSaving(false);
      setIsAdding(false);
      setEditingProject(null);
    } catch (err: any) {
      console.error('Save project error:', err);
      setSaving(false);
      setError('Failed to save project. Please check network and try again.');
    }
  };

  const handleDeleteConfirm = async () => {
    if (!projectToDelete) return;
    try {
      setIsDeleting(true);
      await removeProject(projectToDelete.id);
      showToast(`Project "${projectToDelete.title}" deleted.`);
      setIsDeleting(false);
      setProjectToDelete(null);
    } catch (err) {
      setIsDeleting(false);
      setError('Failed to delete project.');
    }
  };

  return (
    <div id="my-listings-view" className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-10">
      
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div className="fixed top-24 right-4 sm:right-8 z-50 flex items-center gap-2.5 px-4 py-3 rounded-2xl bg-[#140C08] border border-emerald-500/50 text-[#F5F1EC] shadow-[0_10px_35px_rgba(0,0,0,0.85)] animate-in fade-in slide-in-from-top-4 duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {projectToDelete && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200"
          onClick={() => !isDeleting && setProjectToDelete(null)}
        >
          <div 
            className="relative w-full max-w-md bg-[#140C08] border border-red-500/40 rounded-3xl p-6 sm:p-8 space-y-5 shadow-[0_20px_60px_rgba(0,0,0,0.95)]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-14 h-14 rounded-2xl bg-red-500/15 border border-red-500/30 flex items-center justify-center text-red-400 mx-auto">
              <AlertTriangle className="w-7 h-7" />
            </div>

            <div className="text-center space-y-2">
              <h3 className="font-heading text-xl font-bold text-[#F5F1EC]">
                Delete Project?
              </h3>
              <p className="text-xs text-[#B8ACA3] leading-relaxed">
                Are you sure you want to permanently delete <strong className="text-[#F5F1EC]">"{projectToDelete.title}"</strong>?
              </p>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                type="button"
                disabled={isDeleting}
                onClick={() => setProjectToDelete(null)}
                className="flex-1 py-3 rounded-xl bg-[#1C100A] hover:bg-[#25150E] border border-white/10 text-xs font-semibold text-[#B8ACA3] hover:text-[#F5F1EC] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isDeleting}
                onClick={handleDeleteConfirm}
                className="flex-1 py-3 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-red-950"
              >
                {isDeleting ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#FF6A00]/20 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-[11px] font-mono font-semibold text-[#FFB347] uppercase tracking-wider mb-2">
            <FolderGit2 className="w-3.5 h-3.5" />
            <span>My Listings & Works ({userProjects.length} Projects)</span>
          </div>
          <h1 className="font-heading text-3xl sm:text-5xl font-extrabold text-[#F5F1EC] tracking-tight">
            Manage Agency Projects
          </h1>
          <p className="text-[#B8ACA3] text-xs sm:text-sm mt-1">
            Logged in as director <span className="text-[#F5F1EC] font-mono">{user.email}</span>. Full publishing, editing, and delete permissions enabled.
          </p>
        </div>

        <button
          id="listings-add-new-btn"
          onClick={handleOpenAdd}
          className="yellow-btn px-6 py-3 rounded-full text-xs font-black text-[#0D0704] flex items-center gap-2 self-start sm:self-auto cursor-pointer uppercase tracking-wider shadow-md"
        >
          <PlusCircle className="w-4 h-4" />
          <span>Add New Project</span>
        </button>
      </div>

      {/* Add / Edit Project Modal/Form */}
      {isAdding && (
        <div 
          ref={formRef}
          className="p-6 sm:p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/40 shadow-2xl space-y-6 animate-in fade-in duration-300"
        >
          <div className="flex items-center justify-between border-b border-[#FF6A00]/15 pb-4">
            <div className="flex items-center gap-2">
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-mono font-bold uppercase tracking-wider ${
                editingProject ? 'bg-[#FF6A00]/20 text-[#FFB347] border border-[#FF6A00]/40' : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
              }`}>
                {editingProject ? 'EDITING' : 'NEW LISTING'}
              </span>
              <h3 className="font-heading text-xl font-bold text-[#F5F1EC]">
                {editingProject ? editingProject.title : 'Publish New Project Listing'}
              </h3>
            </div>
            <button 
              onClick={() => { setIsAdding(false); setEditingProject(null); }} 
              className="p-2 text-[#B8ACA3] hover:text-[#F5F1EC] rounded-xl hover:bg-[#1C100A]"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {error && (
            <div className="p-3 rounded-xl bg-red-500/15 border border-red-500/30 text-red-300 text-xs">
              {error}
            </div>
          )}

          <form onSubmit={handleFormSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Project Title *</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Brand UGC Campaign - Summer Launch"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Category *</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as any)}
                  className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                >
                  <option value="ugc video">UGC Video</option>
                  <option value="ai video">AI Video</option>
                  <option value="website">Website</option>
                  <option value="branding">Branding</option>
                  <option value="digital marketing">Digital Marketing</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Website URL (Optional)</label>
                <input
                  type="url"
                  value={websiteUrl}
                  onChange={(e) => setWebsiteUrl(e.target.value)}
                  placeholder="https://brand.com"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Results Metric</label>
                <input
                  type="text"
                  value={results}
                  onChange={(e) => setResults(e.target.value)}
                  placeholder="e.g. +310% CTR"
                  className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
                />
              </div>
            </div>

            {/* Media Section: Thumbnail & Video Upload via File Explorer */}
            <div className="p-4 sm:p-5 rounded-2xl bg-[#0D0704] border border-[#FF6A00]/25 space-y-4">
              <div className="flex items-center justify-between border-b border-[#FF6A00]/15 pb-2.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-[#FF6A00]/20 border border-[#FF6A00]/40 flex items-center justify-center text-[#FFB347]">
                    <FolderGit2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <h4 className="font-heading text-xs sm:text-sm font-bold text-[#F5F1EC] uppercase tracking-wide">
                      Media Assets (Persistent Cloud Upload)
                    </h4>
                    <p className="text-[10px] text-[#B8ACA3]">
                      Upload high-res thumbnails and videos. Full aspect ratios (16:9, 9:16, 1:1) are maintained without cropping.
                    </p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <ThumbnailFileUploader
                  value={thumbnail}
                  onChange={setThumbnail}
                  required
                />

                <VideoFileUploader
                  value={videoUrl}
                  onChange={setVideoUrl}
                  videoType={videoType}
                  onTypeChange={setVideoType}
                  aspectRatio={aspectRatio}
                  onAspectRatioChange={setAspectRatio}
                  posterImage={thumbnail}
                  onThumbnailGenerated={(captured) => {
                    setThumbnail((curr) => curr ? curr : captured);
                  }}
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Tags (comma separated)</label>
              <input
                type="text"
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="UGC Video, TikTok Ads, Viral Hook"
                className="w-full px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#B8ACA3] mb-1">Description *</label>
              <textarea
                rows={3}
                required
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Details of creative production, performance metrics, and deliverables..."
                className="w-full p-3 rounded-xl bg-[#1C100A] border border-[#FF6A00]/25 text-[#F5F1EC] text-xs focus:outline-none focus:border-[#FF6A00]"
              />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-[#FF6A00]/15">
              <button
                type="button"
                onClick={() => { setIsAdding(false); setEditingProject(null); }}
                className="px-4 py-2.5 rounded-xl bg-[#1C100A] border border-[#FF6A00]/20 text-xs text-[#B8ACA3] hover:text-[#F5F1EC] cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="yellow-btn px-6 py-2.5 rounded-xl text-xs font-black text-[#0D0704] uppercase tracking-wider shadow-md flex items-center gap-2 cursor-pointer"
              >
                {saving && <RefreshCw className="w-3.5 h-3.5 animate-spin" />}
                <span>{saving ? 'Saving...' : editingProject ? 'Save Changes' : 'Publish Listing'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {userProjects.map((proj) => (
          <div 
            key={proj.id}
            className="group rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 overflow-hidden flex flex-col justify-between shadow-xl hover:border-[#FF6A00]/50 transition-all duration-300"
          >
            <div>
              {/* Media Preview Box */}
              <div 
                className="relative cursor-pointer overflow-hidden bg-black"
                onClick={() => setActiveProjectModal(proj)}
              >
                <ProjectCardVideoPreview 
                  project={proj} 
                  aspectRatioClass="aspect-video"
                />
              </div>

              {/* Body */}
              <div className="p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/25 text-[#FFB347]">
                    {proj.category}
                  </span>
                  <span className="text-[10px] font-mono text-[#B8ACA3]/60">
                    {new Date(proj.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <div>
                  <h3 className="font-heading text-lg font-bold text-[#F5F1EC] group-hover:text-[#FFB347] transition-colors line-clamp-1">
                    {proj.title}
                  </h3>
                  <p className="text-xs text-[#B8ACA3] line-clamp-2 mt-1">
                    {proj.description}
                  </p>
                </div>
              </div>
            </div>

            {/* Action Bar */}
            <div className="p-4 border-t border-[#FF6A00]/15 flex items-center justify-between gap-2 bg-[#100905]">
              <button
                onClick={() => setActiveProjectModal(proj)}
                className="px-3 py-1.5 rounded-xl bg-[#1C100A] hover:bg-[#25150E] text-[#F5F1EC] text-xs font-medium cursor-pointer border border-white/5"
              >
                Preview
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleOpenEdit(proj)}
                  className="px-3 py-1.5 rounded-xl bg-[#FF6A00]/20 hover:bg-[#FF6A00]/30 text-[#FFB347] text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Edit</span>
                </button>
                <button
                  onClick={() => setProjectToDelete({ id: proj.id, title: proj.title })}
                  className="px-3 py-1.5 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs font-semibold flex items-center gap-1 cursor-pointer transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {userProjects.length === 0 && !isAdding && (
        <div className="text-center py-16 p-8 rounded-3xl bg-[#140C08] border border-[#FF6A00]/20 space-y-4">
          <FolderGit2 className="w-12 h-12 text-[#FFB347] mx-auto opacity-40" />
          <h3 className="text-lg font-bold text-[#F5F1EC]">No Projects Found</h3>
          <p className="text-xs text-[#B8ACA3] max-w-sm mx-auto">
            Click "Add New Project" above to upload commercial AI videos, UGC reels, and websites.
          </p>
          <button
            onClick={handleOpenAdd}
            className="yellow-btn px-6 py-2.5 rounded-full text-xs font-black text-[#0D0704] uppercase tracking-wider inline-flex items-center gap-2 cursor-pointer shadow-md"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create First Project</span>
          </button>
        </div>
      )}

    </div>
  );
};
