import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Sparkles, 
  Video, 
  Megaphone, 
  Globe, 
  Palette, 
  CheckCircle2, 
  ArrowRight, 
  Play, 
  ExternalLink,
  PhoneCall,
  Clock,
  Zap,
  TrendingUp
} from 'lucide-react';

export const ServicesView: React.FC = () => {
  const { setDemoModalOpen, setCurrentPage, setSelectedCategory, setActiveProjectModal, projects } = useApp();
  const [activeFilter, setActiveFilter] = useState<string>('all');

  const services = [
    {
      id: 'ai-videos',
      categoryKey: 'ai video',
      name: 'AI Video Ads & Synthetic Cinema',
      tagline: 'Hyper-realistic digital commercials with zero physical cameras',
      description: 'We script, direct, synthesize, and color-grade ultra-photorealistic video ads using proprietary generative models. Replace multi-million-dollar location shoots and actor coordination with 48-hour neural generation.',
      image: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
      videoPreview: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      deliverables: [
        'AI Ad Videos in 4K resolution (16:9, 9:16, 1:1)',
        'Synthetic human brand ambassadors & avatars',
        '3D fluid dynamics & impossible product shots',
        'AI Optimised Content for high conversion CTR'
      ],
      pricing: 'To Know the Price contact us',
      exampleProjectId: 'proj-1'
    },
    {
      id: 'marketing',
      categoryKey: 'digital marketing',
      name: 'Digital & Influencer Marketing',
      tagline: 'Viral creator pipelines & organic acquisition machines',
      description: 'We orchestrate end-to-end performance marketing campaigns, pairing AI video volume with high-converting creator partnerships across TikTok, Instagram, and YouTube.',
      image: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=80',
      videoPreview: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
      deliverables: [
        'Multi-channel Social Media video production',
        'Performance Influencer Marketing campaigns',
        'Strategic Content Marketing & SEO authority',
        'Real-time conversion tracking & weekly ROAS reports'
      ],
      pricing: 'To Know the Price contact us',
      exampleProjectId: 'proj-4'
    },
    {
      id: 'websites',
      categoryKey: 'website',
      name: 'Website Design & Full-Stack Development',
      tagline: 'Award-grade spatial UI/UX engineering with sub-second speeds',
      description: 'We craft immersive digital flagships and web applications with 3D interactions, fluid responsiveness, and high-conversion purchase funnels. Designed from zero templates.',
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
      videoPreview: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
      deliverables: [
        'Custom Design systems & spatial micro-interactions',
        'Full-Stack Web Development (Next.js / React)',
        'Headless CMS integration & SEO optimization',
        'Sub-800ms global CDN load speeds'
      ],
      pricing: 'To Know the Price contact us',
      exampleProjectId: 'proj-2'
    },
    {
      id: 'branding',
      categoryKey: 'branding',
      name: 'Brand Identity & Corporate Systems',
      tagline: 'Iconic visual marks engineered for the modern digital era',
      description: 'We forge memorable brand identities: vector logo design, color science, typography guidelines, and complete marketing collateral that make your business impossible to ignore.',
      image: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=1200&q=80',
      videoPreview: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
      deliverables: [
        'Logo Design & Vector Iconography',
        'Brand Development & Visual Guidelines',
        'Brand Collateral (Decks, Packaging, Merchandise)',
        'Corporate Identity systems for enterprise scale'
      ],
      pricing: 'To Know the Price contact us',
      exampleProjectId: 'proj-3'
    }
  ];

  const filteredServices = activeFilter === 'all' 
    ? services 
    : services.filter(s => s.categoryKey === activeFilter);

  const handleOpenExample = (projectId: string) => {
    const proj = projects.find(p => p.id === projectId);
    if (proj) {
      setActiveProjectModal(proj);
    } else {
      setSelectedCategory('all');
      setCurrentPage('projects');
    }
  };

  return (
    <div id="services-page-view" className="min-h-screen pt-28 pb-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-16">
      
      {/* Header */}
      <div className="space-y-4 max-w-3xl">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#FF6A00]/10 border border-[#FF6A00]/30 text-xs font-mono font-semibold text-[#FFB347] uppercase tracking-wider">
          <Sparkles className="w-3 h-3" />
          <span>Services & Solutions</span>
        </div>
        <h1 className="font-heading text-4xl sm:text-6xl font-extrabold text-[#F5F1EC] tracking-tight leading-tight">
          Engineered for Category Dominance.
        </h1>
        <p className="text-[#B8ACA3] text-base sm:text-lg">
          Each service combines artistic mastery with algorithmic efficiency, delivering production quality previously reserved for Fortune 500 budgets.
        </p>
      </div>

      {/* Category Filter Pills */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-[#140C08] rounded-2xl border border-[#FF6A00]/20 w-fit">
        {[
          { label: 'All Services', key: 'all' },
          { label: 'AI Videos', key: 'ai video' },
          { label: 'Digital Marketing', key: 'digital marketing' },
          { label: 'Websites', key: 'website' },
          { label: 'Branding', key: 'branding' }
        ].map((f) => (
          <button
            key={f.key}
            id={`filter-service-${f.key.replace(/\s+/g, '-')}`}
            onClick={() => setActiveFilter(f.key)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
              activeFilter === f.key
                ? 'bg-gradient-to-r from-[#FF6A00] to-[#FFB347] text-[#0D0704] shadow-lg shadow-[#FF6A00]/20 font-bold'
                : 'text-[#B8ACA3] hover:text-[#F5F1EC] hover:bg-[#25150E]'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Services List */}
      <div className="space-y-12">
        {filteredServices.map((srv, idx) => (
          <div
            key={srv.id}
            id={`service-detail-${srv.id}`}
            className="rounded-3xl bg-[#140C08] border border-[#FF6A00]/25 overflow-hidden p-6 sm:p-10 lg:p-12 transition-all duration-300 hover:border-[#FF6A00]/60 shadow-2xl"
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
              
              {/* Media Preview Column */}
              <div className="lg:col-span-6 relative aspect-video rounded-2xl overflow-hidden bg-[#0D0704] border border-[#FF6A00]/20 group">
                <img
                  src={srv.image}
                  alt={srv.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-85"
                />
                
                {/* Playable Video Preview */}
                {srv.videoPreview && (
                  <video
                    src={srv.videoPreview}
                    muted
                    loop
                    autoPlay
                    playsInline
                    className="absolute inset-0 w-full h-full object-cover opacity-90"
                  />
                )}

                <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-[#0D0704]/80 backdrop-blur-md border border-[#FF6A00]/30 text-[10px] font-mono font-bold text-[#FFB347] uppercase">
                  {srv.categoryKey}
                </div>
              </div>

              {/* Text / Deliverables Column */}
              <div className="lg:col-span-6 space-y-6">
                <div>
                  <span className="text-xs font-mono uppercase tracking-widest text-[#FFB347] font-bold">
                    Pillar 0{idx + 1}
                  </span>
                  <h2 className="font-heading text-2xl sm:text-3xl font-extrabold text-[#F5F1EC] mt-1">
                    {srv.name}
                  </h2>
                  <p className="text-[#FFB347] text-xs sm:text-sm font-medium mt-1">
                    {srv.tagline}
                  </p>
                </div>

                <p className="text-[#B8ACA3] text-sm leading-relaxed">
                  {srv.description}
                </p>

                {/* Deliverables Checklist */}
                <div className="space-y-2 border-t border-[#FF6A00]/15 pt-4">
                  <p className="text-xs font-mono uppercase tracking-wider text-[#F5F1EC] font-semibold mb-3">
                    Key Deliverables:
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {srv.deliverables.map((item, i) => (
                      <div key={i} className="flex items-start gap-2 text-[#B8ACA3]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#FF6A00] shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Pricing & CTA */}
                <div className="pt-4 border-t border-[#FF6A00]/15 flex flex-wrap items-center justify-between gap-4">
                  <div className="text-xs">
                    <span className="text-[#B8ACA3]/70 block font-mono text-[10px] uppercase">Transparent Investment</span>
                    <span className="font-mono font-bold text-[#FFB347] text-sm">{srv.pricing}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <button
                      id={`example-work-btn-${srv.id}`}
                      onClick={() => handleOpenExample(srv.exampleProjectId)}
                      className="px-4 py-2.5 rounded-xl bg-[#1C100A] hover:bg-[#25150E] border border-[#FF6A00]/30 text-xs font-semibold text-[#F5F1EC] transition-colors flex items-center gap-1.5"
                    >
                      <Play className="w-3 h-3 text-[#FFB347]" />
                      <span>Example Work</span>
                    </button>

                    <button
                      id={`book-service-btn-${srv.id}`}
                      onClick={() => setDemoModalOpen(true)}
                      className="yellow-btn px-5 py-2.5 rounded-xl text-xs font-black text-[#0D0704] flex items-center gap-1.5 cursor-pointer uppercase tracking-wider shadow-md"
                    >
                      <PhoneCall className="w-3.5 h-3.5" />
                      <span>Book a Call (962511181)</span>
                    </button>
                  </div>
                </div>

              </div>

            </div>
          </div>
        ))}
      </div>

    </div>
  );
};
