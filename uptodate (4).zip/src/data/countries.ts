export interface Country {
  name: string;
  code: string; // ISO 3166-1 alpha-2
  dialCode: string; // E.164 dial code e.g. "+44"
  flag: string; // Emoji flag
  format: string; // Placeholder format
  priority?: number;
}

export const COUNTRIES: Country[] = [
  // Quick/Top Picks
  { name: 'United Kingdom', code: 'GB', dialCode: '+44', flag: '🇬🇧', format: '7911 123456', priority: 1 },
  { name: 'India', code: 'IN', dialCode: '+91', flag: '🇮🇳', format: '98765 43210', priority: 1 },
  { name: 'United States', code: 'US', dialCode: '+1', flag: '🇺🇸', format: '(555) 123-4567', priority: 1 },
  { name: 'Canada', code: 'CA', dialCode: '+1', flag: '🇨🇦', format: '(555) 123-4567', priority: 1 },
  { name: 'Australia', code: 'AU', dialCode: '+61', flag: '🇦🇺', format: '412 345 678', priority: 1 },
  { name: 'United Arab Emirates', code: 'AE', dialCode: '+971', flag: '🇦🇪', format: '50 123 4567', priority: 1 },
  { name: 'Saudi Arabia', code: 'SA', dialCode: '+966', flag: '🇸🇦', format: '50 123 4567', priority: 1 },
  { name: 'Germany', code: 'DE', dialCode: '+49', flag: '🇩🇪', format: '151 12345678', priority: 1 },
  { name: 'France', code: 'FR', dialCode: '+33', flag: '🇫🇷', format: '6 12 34 56 78', priority: 1 },
  { name: 'Singapore', code: 'SG', dialCode: '+65', flag: '🇸🇬', format: '8123 4567', priority: 1 },

  // Europe
  { name: 'Austria', code: 'AT', dialCode: '+43', flag: '🇦🇹', format: '664 123456' },
  { name: 'Belgium', code: 'BE', dialCode: '+32', flag: '🇧🇪', format: '470 12 34 56' },
  { name: 'Bulgaria', code: 'BG', dialCode: '+359', flag: '🇧🇬', format: '87 123 4567' },
  { name: 'Croatia', code: 'HR', dialCode: '+385', flag: '🇭🇷', format: '91 123 4567' },
  { name: 'Cyprus', code: 'CY', dialCode: '+357', flag: '🇨🇾', format: '99 123456' },
  { name: 'Czech Republic', code: 'CZ', dialCode: '+420', flag: '🇨🇿', format: '601 123 456' },
  { name: 'Denmark', code: 'DK', dialCode: '+45', flag: '🇩🇰', format: '20 12 34 56' },
  { name: 'Estonia', code: 'EE', dialCode: '+372', flag: '🇪🇪', format: '512 3456' },
  { name: 'Finland', code: 'FI', dialCode: '+358', flag: '🇫🇮', format: '40 1234567' },
  { name: 'Greece', code: 'GR', dialCode: '+30', flag: '🇬🇷', format: '691 234 5678' },
  { name: 'Hungary', code: 'HU', dialCode: '+36', flag: '🇭🇺', format: '20 123 4567' },
  { name: 'Iceland', code: 'IS', dialCode: '+354', flag: '🇮🇸', format: '612 3456' },
  { name: 'Ireland', code: 'IE', dialCode: '+353', flag: '🇮🇪', format: '85 123 4567' },
  { name: 'Italy', code: 'IT', dialCode: '+39', flag: '🇮🇹', format: '312 345 6789' },
  { name: 'Latvia', code: 'LV', dialCode: '+371', flag: '🇱🇻', format: '21 234 567' },
  { name: 'Lithuania', code: 'LT', dialCode: '+370', flag: '🇱🇹', format: '612 34567' },
  { name: 'Luxembourg', code: 'LU', dialCode: '+352', flag: '🇱🇺', format: '621 123 456' },
  { name: 'Malta', code: 'MT', dialCode: '+356', flag: '🇲🇹', format: '9912 3456' },
  { name: 'Monaco', code: 'MC', dialCode: '+377', flag: '🇲🇨', format: '6 12 34 56 78' },
  { name: 'Netherlands', code: 'NL', dialCode: '+31', flag: '🇳🇱', format: '6 12345678' },
  { name: 'Norway', code: 'NO', dialCode: '+47', flag: '🇳🇴', format: '412 34 567' },
  { name: 'Poland', code: 'PL', dialCode: '+48', flag: '🇵🇱', format: '512 345 678' },
  { name: 'Portugal', code: 'PT', dialCode: '+351', flag: '🇵🇹', format: '912 345 678' },
  { name: 'Romania', code: 'RO', dialCode: '+40', flag: '🇷🇴', format: '712 345 678' },
  { name: 'Serbia', code: 'RS', dialCode: '+381', flag: '🇷🇸', format: '60 1234567' },
  { name: 'Slovakia', code: 'SK', dialCode: '+421', flag: '🇸🇰', format: '912 345 678' },
  { name: 'Slovenia', code: 'SI', dialCode: '+386', flag: '🇸🇮', format: '31 123 456' },
  { name: 'Spain', code: 'ES', dialCode: '+34', flag: '🇪🇸', format: '612 34 56 78' },
  { name: 'Sweden', code: 'SE', dialCode: '+46', flag: '🇸🇪', format: '70 123 45 67' },
  { name: 'Switzerland', code: 'CH', dialCode: '+41', flag: '🇨🇭', format: '78 123 45 67' },
  { name: 'Turkey', code: 'TR', dialCode: '+90', flag: '🇹🇷', format: '532 123 45 67' },
  { name: 'Ukraine', code: 'UA', dialCode: '+380', flag: '🇺🇦', format: '50 123 4567' },

  // Asia & Oceania
  { name: 'Bangladesh', code: 'BD', dialCode: '+880', flag: '🇧🇩', format: '1712 345678' },
  { name: 'China', code: 'CN', dialCode: '+86', flag: '🇨🇳', format: '138 1234 5678' },
  { name: 'Hong Kong', code: 'HK', dialCode: '+852', flag: '🇭🇰', format: '5123 4567' },
  { name: 'Indonesia', code: 'ID', dialCode: '+62', flag: '🇮🇩', format: '812 3456 7890' },
  { name: 'Israel', code: 'IL', dialCode: '+972', flag: '🇮🇱', format: '50 123 4567' },
  { name: 'Japan', code: 'JP', dialCode: '+81', flag: '🇯🇵', format: '90 1234 5678' },
  { name: 'Jordan', code: 'JO', dialCode: '+962', flag: '🇯🇴', format: '7 9012 3456' },
  { name: 'Kazakhstan', code: 'KZ', dialCode: '+7', flag: '🇰🇿', format: '701 123 4567' },
  { name: 'Kuwait', code: 'KW', dialCode: '+965', flag: '🇰🇼', format: '5123 4567' },
  { name: 'Lebanon', code: 'LB', dialCode: '+961', flag: '🇱🇧', format: '70 123 456' },
  { name: 'Malaysia', code: 'MY', dialCode: '+60', flag: '🇲🇾', format: '12 345 6789' },
  { name: 'Maldives', code: 'MV', dialCode: '+960', flag: '🇲🇻', format: '791 2345' },
  { name: 'Nepal', code: 'NP', dialCode: '+977', flag: '🇳🇵', format: '984 1234567' },
  { name: 'New Zealand', code: 'NZ', dialCode: '+64', flag: '🇳🇿', format: '21 123 4567' },
  { name: 'Oman', code: 'OM', dialCode: '+968', flag: '🇴🇲', format: '9123 4567' },
  { name: 'Pakistan', code: 'PK', dialCode: '+92', flag: '🇵🇰', format: '301 2345678' },
  { name: 'Philippines', code: 'PH', dialCode: '+63', flag: '🇵🇭', format: '917 123 4567' },
  { name: 'Qatar', code: 'QA', dialCode: '+974', flag: '🇶🇦', format: '3312 3456' },
  { name: 'South Korea', code: 'KR', dialCode: '+82', flag: '🇰🇷', format: '10 1234 5678' },
  { name: 'Sri Lanka', code: 'LK', dialCode: '+94', flag: '🇱🇰', format: '71 234 5678' },
  { name: 'Taiwan', code: 'TW', dialCode: '+886', flag: '🇹🇼', format: '912 345 678' },
  { name: 'Thailand', code: 'TH', dialCode: '+66', flag: '🇹🇭', format: '81 234 5678' },
  { name: 'Vietnam', code: 'VN', dialCode: '+84', flag: '🇻🇳', format: '91 234 5678' },
  { name: 'Bahrain', code: 'BH', dialCode: '+973', flag: '🇧🇭', format: '3600 1234' },

  // Americas
  { name: 'Argentina', code: 'AR', dialCode: '+54', flag: '🇦🇷', format: '9 11 1234 5678' },
  { name: 'Brazil', code: 'BR', dialCode: '+55', flag: '🇧🇷', format: '11 91234 5678' },
  { name: 'Chile', code: 'CL', dialCode: '+56', flag: '🇨🇱', format: '9 1234 5678' },
  { name: 'Colombia', code: 'CO', dialCode: '+57', flag: '🇨🇴', format: '300 123 4567' },
  { name: 'Costa Rica', code: 'CR', dialCode: '+506', flag: '🇨🇷', format: '8312 3456' },
  { name: 'Dominican Republic', code: 'DO', dialCode: '+1-809', flag: '🇩🇴', format: '(809) 234-5678' },
  { name: 'Ecuador', code: 'EC', dialCode: '+593', flag: '🇪🇨', format: '99 123 4567' },
  { name: 'Jamaica', code: 'JM', dialCode: '+1-876', flag: '🇯🇲', format: '(876) 234-5678' },
  { name: 'Mexico', code: 'MX', dialCode: '+52', flag: '🇲🇽', format: '55 1234 5678' },
  { name: 'Panama', code: 'PA', dialCode: '+507', flag: '🇵🇦', format: '6123 4567' },
  { name: 'Peru', code: 'PE', dialCode: '+51', flag: '🇵🇪', format: '912 345 678' },
  { name: 'Uruguay', code: 'UY', dialCode: '+598', flag: '🇺🇾', format: '94 123 456' },

  // Africa
  { name: 'Egypt', code: 'EG', dialCode: '+20', flag: '🇪🇬', format: '100 123 4567' },
  { name: 'Ghana', code: 'GH', dialCode: '+233', flag: '🇬🇭', format: '20 123 4567' },
  { name: 'Kenya', code: 'KE', dialCode: '+254', flag: '🇰🇪', format: '712 345 678' },
  { name: 'Morocco', code: 'MA', dialCode: '+212', flag: '🇲🇦', format: '612 345 678' },
  { name: 'Nigeria', code: 'NG', dialCode: '+234', flag: '🇳🇬', format: '802 123 4567' },
  { name: 'South Africa', code: 'ZA', dialCode: '+27', flag: '🇿🇦', format: '82 123 4567' },
  { name: 'Tanzania', code: 'TZ', dialCode: '+255', flag: '🇹🇿', format: '712 345 678' },
  { name: 'Tunisia', code: 'TN', dialCode: '+216', flag: '🇹🇳', format: '20 123 456' },
  { name: 'Uganda', code: 'UG', dialCode: '+256', flag: '🇺🇬', format: '712 345 678' }
];

export const DEFAULT_COUNTRY = COUNTRIES[0]; // United Kingdom (requested specifically) or India/US
