import { Project, AboutSectionData } from '../types';

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'proj-home-appliance-1',
    title: 'Electro Care: The Ultimate Protector Voltage Stabilizer',
    category: 'ai video',
    description: 'High-octane AI commercial for Electro Care Voltage Stabilizers & Servo Transformers by Electro Control Technologies (By Jom Studio). Features a grand Indian wedding where an unexpected power surge cuts off the DJ concert and dimming chandeliers, until Electro Care Stabilizer restores full power instantly, bringing the bride and guests back into celebration.',
    thumbnail: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?auto=format&fit=crop&w=1000&q=80',
    videoUrl: '/videos/sample-reel-1.mp4',
    videoType: 'mp4',
    aspectRatio: '9:16',
    galleryImages: [
      'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=1000&q=80'
    ],
    websiteUrl: 'https://electrocare-stabilizers.example.com',
    tags: ['AI Video', 'Home Appliances', 'Stabilizer', 'Voltage Protection', 'Commercial Reel', 'Wedding'],
    results: 'By JOM Studio | 100% Surge Defense | 4.8M Viral Views',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'sriramjaihanuman369@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-09-22T08:00:00.000Z'
  },
  {
    id: 'proj-home-appliance-3',
    title: 'Aparna Infrared Cooktop 2200 Watts (Crystal)',
    category: 'ai video',
    description: 'Sleek high-converting product commercial showcasing the Aparna 2200W Crystal Infrared Cooktop for modern kitchens. Highlights fast and even heating performance, digital touch and rotary dial controls, advanced safety shutoffs, and multi-cookware compatibility across aluminium, stainless steel, hard anodized, copper bottom, and non-stick pans.',
    thumbnail: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&w=1000&q=80',
    videoUrl: '/videos/sample-reel-2.mp4',
    videoType: 'mp4',
    aspectRatio: '9:16',
    galleryImages: [
      'https://images.unsplash.com/photo-1588854337236-6889d631faa8?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1556911073-38141963c9e0?auto=format&fit=crop&w=1000&q=80'
    ],
    websiteUrl: 'https://aparna-cooktops.example.com',
    tags: ['AI Video', 'Home Appliances', 'Kitchen Cooktop', 'Infrared 2200W', 'Product Ad'],
    results: '2200 Watts Powerful Heat | All-Cookware Ready | 3.8x ROAS',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'sriramjaihanuman369@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-09-22T07:00:00.000Z'
  },
  {
    id: 'proj-1',
    title: 'AURA: Autonomous AI Fashion Commercial',
    category: 'ai video',
    description: 'A cinematic hyper-stylized AI advertising film created entirely with neural rendering and synthetic cinematography for high-end luxury fashion brand AURA. Shot without physical cameras, delivering photorealistic runway models in surreal digital architecture.',
    thumbnail: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=1200&q=80',
    videoUrl: '/videos/sample-commercial.mp4',
    videoType: 'mp4',
    galleryImages: [
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1000&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1000&q=80'
    ],
    websiteUrl: 'https://aura-couture.example.com',
    tags: ['AI Video', 'CGI', 'Fashion', 'Photorealism', 'Runway'],
    results: '+420% Social Engagement, 8.4M Organic Views',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'jasminnmayl@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-08-15T10:00:00.000Z'
  },
  {
    id: 'proj-2',
    title: 'KRONOS: Next-Gen Fintech Spatial Interface',
    category: 'website',
    description: 'Bespoke web development and 3D web experience for high-frequency digital assets. Engineered with interactive WebGL canvas, micro-animations, ultra-responsive typography, and seamless real-time portfolio dashboards.',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
    videoUrl: '/videos/sample-reel-2.mp4',
    videoType: 'mp4',
    galleryImages: [
      'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1000&q=80'
    ],
    websiteUrl: 'https://kronos-vault.example.com',
    tags: ['WebGL', 'Web Design', 'Full-Stack Dev', 'Fintech', 'Dark UI'],
    results: 'Sub-800ms Load Time, 68% Conversion Boost',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'jasminnmayl@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-08-20T12:30:00.000Z'
  },
  {
    id: 'proj-3',
    title: 'SOLIS: Autonomous Electric Mobility Rebrand',
    category: 'branding',
    description: 'Comprehensive brand identity, logo design system, motion guidelines, and packaging collateral for clean-energy hypercar innovator SOLIS. Crafted with custom geometric typography and radiant orange ambient accents.',
    thumbnail: 'https://images.unsplash.com/photo-1617788138017-80ad40651399?auto=format&fit=crop&w=1200&q=80',
    videoUrl: '/videos/sample-reel-1.mp4',
    videoType: 'mp4',
    galleryImages: [
      'https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=1000&q=80'
    ],
    websiteUrl: 'https://solis-mobility.example.com',
    tags: ['Branding', 'Logo Design', 'Design System', 'Automotive', 'Typography'],
    results: 'Acquired $45M Series A, Red Dot Award Nominee',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'jasminnmayl@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-08-28T09:15:00.000Z'
  },
  {
    id: 'proj-4',
    title: 'VELOCITY: Viral AI UGC Campaign For Drinks',
    category: 'ugc video',
    description: 'Multi-variant AI avatar UGC campaign generating 50 localized creator ads in 3 days. Personalized hooks, high-energy pacing, dynamic captions, and platform-specific audio designed to dominate TikTok and Instagram Reels.',
    thumbnail: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1200&q=80',
    videoUrl: '/videos/sample-commercial.mp4',
    videoType: 'mp4',
    galleryImages: [
      'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=1000&q=80'
    ],
    websiteUrl: 'https://velocity-brew.example.com',
    tags: ['AI UGC', 'TikTok Ads', 'Viral Hooks', 'Performance Marketing'],
    results: '3.4x ROAS, $1.2M Attributed Revenue in 30 Days',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'jasminnmayl@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-09-02T16:45:00.000Z'
  },
  {
    id: 'proj-5',
    title: 'NEXUS: AI-Powered Enterprise SaaS Re-Architecture',
    category: 'website',
    description: 'Complete visual and front-end engineering transformation of enterprise data orchestration software. Designed with custom dark mode hierarchy, blazing fast interactivity, and seamless self-serve customer onboarding.',
    thumbnail: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?auto=format&fit=crop&w=1200&q=80',
    videoUrl: '/videos/sample-reel-2.mp4',
    videoType: 'mp4',
    tags: ['Website Design', 'React / Next', 'Enterprise UI', 'B2B SaaS'],
    results: '+185% Free-Trial Signups, Zero Bounce Regressions',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'jasminnmayl@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-09-08T11:00:00.000Z'
  },
  {
    id: 'proj-6',
    title: 'SYNTHESIS: Global AI Cosmetic Product Launch',
    category: 'ai video',
    description: 'Global multi-territory digital commercial featuring digital AI brand ambassadors, liquid physics simulations, and micro-particle visual effects rendered in 8K resolution without traditional location shoot logistics.',
    thumbnail: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=1200&q=80',
    videoUrl: '/videos/sample-reel-1.mp4',
    videoType: 'mp4',
    tags: ['AI Commercial', '3D Simulation', 'Cosmetics', 'Cinematic Sound'],
    results: '14.2M Impressions across YouTube & Meta Ads',
    featured: true,
    createdBy: 'admin',
    authorEmail: 'jasminnmayl@gmail.com',
    authorName: 'UPTODATE Studio',
    createdAt: '2026-09-14T14:20:00.000Z'
  }
];

export const INITIAL_ABOUT: AboutSectionData = {
  whyWeStarted: `We started with a simple belief: technology should create opportunities, not just efficiencies.

We saw how AI, digital platforms, and the creator economy were changing the way businesses grow — but we also saw how many talented people, especially young women, were still struggling to access those opportunities.

So, we built our agency to bridge that gap.

We bring together AI, branding, website design & development, AI-powered video creation, digital marketing, and influencer marketing to help businesses turn their ideas into brands that people notice, trust, and remember.

But our vision goes beyond building brands.

We want to create a world where more women can build businesses, earn independently, develop their skills, and create their own identity through the digital economy. We believe a girl with an idea should have the tools, technology, and confidence to turn it into something real.

For us, every brand we build is more than a project. It is a step toward creating more opportunities, more independence, and more voices in the digital world.

We’re not just building brands. We’re building possibilities.`,
  coreValues: [
    {
      title: 'Listens',
      description: 'Behind every brand is a person with a vision. We listen, collaborate, and build solutions around real people and real goals.',
      icon: 'sparkles'
    },
    {
      title: 'Empowerment Through Technology',
      description: 'We believe technology should open doors. We aim to help more people, especially women and young creators, build skills, businesses, independence, and confidence in the digital world.',
      icon: 'shield-check'
    },
    {
      title: 'Obsessive Craftsmanship',
      description: 'We never accept generic AI outputs. Every frame, typeface, and layout is curated and polished by veteran design directors.',
      icon: 'sparkles'
    },
    {
      title: 'Measurable Impact',
      description: 'Beauty that converts. Every creative asset is engineered to deliver measurable ROAS, CTR, and brand equity.',
      icon: 'trending-up'
    }
  ],
  stats: [
    { value: '48h - 5d', label: 'Average Production Turnaround' },
    { value: '340%', label: 'Average Client ROAS Uplift' },
    { value: 'Contact Us', label: 'To Know The Price Contact Us' },
    { value: '150+', label: 'AI Campaigns & Websites Shipped' }
  ]
};
