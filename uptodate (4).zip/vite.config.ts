import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import {defineConfig, Plugin} from 'vite';

function mediaUploadPlugin(): Plugin {
  return {
    name: 'media-upload-plugin',
    configureServer(server) {
      // Dynamic video streaming with HTTP 206 Partial Content (essential for mobile & desktop video seeking)
      server.middlewares.use('/videos', (req, res, next) => {
        const cleanUrl = req.url ? req.url.split('?')[0] : '';
        const filePath = path.join(process.cwd(), 'public/videos', cleanUrl);
        if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
          const stat = fs.statSync(filePath);
          const range = req.headers.range;

          if (range) {
            const parts = range.replace(/bytes=/, '').split('-');
            const start = parseInt(parts[0], 10);
            const end = parts[1] ? parseInt(parts[1], 10) : stat.size - 1;
            const chunksize = end - start + 1;
            const file = fs.createReadStream(filePath, { start, end });
            res.writeHead(206, {
              'Content-Range': `bytes ${start}-${end}/${stat.size}`,
              'Accept-Ranges': 'bytes',
              'Content-Length': chunksize,
              'Content-Type': 'video/mp4',
            });
            file.pipe(res);
            return;
          } else {
            res.writeHead(200, {
              'Content-Length': stat.size,
              'Content-Type': 'video/mp4',
              'Accept-Ranges': 'bytes',
            });
            fs.createReadStream(filePath).pipe(res);
            return;
          }
        }
        next();
      });

      server.middlewares.use('/api/upload', (req, res) => {
        if (req.method !== 'POST') {
          res.statusCode = 405;
          return res.end(JSON.stringify({ error: 'Method Not Allowed' }));
        }

        const chunks: Buffer[] = [];
        req.on('data', (chunk) => chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)));
        req.on('end', () => {
          try {
            const buffer = Buffer.concat(chunks);
            const customId = req.headers['x-file-id'] as string;
            const originalName = (req.headers['x-file-name'] as string) || '';
            const contentType = (req.headers['content-type'] as string) || 'video/mp4';

            let ext = '.mp4';
            if (originalName) {
              const matchedExt = path.extname(originalName);
              if (matchedExt) ext = matchedExt;
            } else if (contentType.includes('image/png')) {
              ext = '.png';
            } else if (contentType.includes('image/jpeg')) {
              ext = '.jpg';
            } else if (contentType.includes('image/webp')) {
              ext = '.webp';
            }

            const cleanId = customId ? customId.replace(/[^a-zA-Z0-9_-]/g, '_') : `upload_${Date.now()}`;
            const filename = `${cleanId}${ext}`;
            const targetDir = path.resolve(process.cwd(), 'public/videos');
            if (!fs.existsSync(targetDir)) {
              fs.mkdirSync(targetDir, { recursive: true });
            }

            const filePath = path.join(targetDir, filename);
            fs.writeFileSync(filePath, buffer);

            const distDir = path.resolve(process.cwd(), 'dist/videos');
            if (fs.existsSync(distDir)) {
              fs.copyFileSync(filePath, path.join(distDir, filename));
            }

            res.statusCode = 200;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({
              success: true,
              url: `/videos/${filename}`,
              filename,
              size: buffer.length
            }));
          } catch (err: any) {
            console.error('API Upload error:', err);
            res.statusCode = 500;
            res.setHeader('Content-Type', 'application/json');
            res.end(JSON.stringify({ error: err.message }));
          }
        });
      });
    }
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), mediaUploadPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
